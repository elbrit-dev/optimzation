"use client";;
import {format} from "date-fns";

import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@calendar/components/ui/alert-dialog";
import {formatTime, getColorClass} from "@calendar/components/calendar/helpers";
import {cn} from "@calendar/lib/utils";
import {useCalendar} from "@calendar/components/calendar/contexts/calendar-context";

export function EventDropConfirmationDialog({
    open,
    onOpenChange,
    event,
    newStartDate,
    newEndDate,
    onConfirm,
    onCancel
}) {

    const {use24HourFormat} = useCalendar();

    if (!event || !newStartDate || !newEndDate) {
        return null;
    }

    const originalStart = new Date(event.startDate);

    const formatDate = (date) => {
        return format(date, "MMM dd, yyyy 'at '") + formatTime(date, use24HourFormat);
    };

    const handleConfirm = () => {
        onConfirm();
        onOpenChange(false);
    };

    const handleCancel = () => {
        onCancel();
        onOpenChange(false);
    };

    return (
        <AlertDialog open={open} onOpenChange={onOpenChange}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Event Move</AlertDialogTitle>
                    <AlertDialogDescription>
                        Are you sure you want to move
                        <span className={cn(getColorClass(event.color), "mx-1 py-0.5 px-1 rounded-md")}>
							{event.title}
						</span>
                        event from
                        <strong className="mx-1">{formatDate(originalStart)}</strong> to
                        <strong className="mx-1">{formatDate(newStartDate)}</strong>?
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel onClick={handleCancel}>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleConfirm}>
                        Move Event
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}
