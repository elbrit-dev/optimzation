import { cva } from "class-variance-authority";
import { endOfDay, isSameDay, parseISO, startOfDay } from "date-fns";
import { cn } from "@calendar/lib/utils";
import { useCalendar } from "@calendar/components/calendar/contexts/calendar-context";
import { EventDetailsDialog } from "@calendar/components/calendar/dialogs/event-details-dialog";
import { DraggableEvent } from "@calendar/components/calendar/dnd/draggable-event";
import { formatTime } from "@calendar/components/calendar/helpers";
import {EventBullet} from "@calendar/components/calendar/views/month-view/event-bullet";
import { TAG_IDS } from "../../constants";
import { SyncStatusBadge } from "@calendar/components/calendar/sync/sync-status-badge";

const eventBadgeVariants = cva(
    "mx-1 w-full flex size-auto h-3.5 md:h-6.5 select-none items-center justify-between gap-1.5 truncate whitespace-nowrap rounded-md border px-1 md:px-2 text-xs font-medium shadow-sm cursor-pointer transition-shadow hover:shadow",
    {
		variants: {
			color: {
				// Colored variants
				blue: "border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-950 dark:text-blue-300",
				green:
					"border-green-200 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-950 dark:text-green-300",
				red: "border-red-200 bg-red-50 text-red-700 dark:border-red-800 dark:bg-red-950 dark:text-red-300",
				indigo: "border-indigo-200 bg-indigo-50 text-indigo-700 dark:border-indigo-800 dark:bg-indigo-950 dark:text-indigo-300",
				yellow:
					"border-yellow-200 bg-yellow-50 text-yellow-700 dark:border-yellow-800 dark:bg-yellow-950 dark:text-yellow-300",
				purple:
					"border-purple-200 bg-purple-50 text-purple-700 dark:border-purple-800 dark:bg-purple-950 dark:text-purple-300",
				orange:
					"border-orange-200 bg-orange-50 text-orange-700 dark:border-orange-800 dark:bg-orange-950 dark:text-orange-300",

				// Dot variants
				"blue-dot": "bg-bg-secondary text-t-primary [&_svg]:fill-blue-600",
				"green-dot": "bg-bg-secondary text-t-primary [&_svg]:fill-green-600",
				"red-dot": "bg-bg-secondary text-t-primary [&_svg]:fill-red-600",
				"indigo-dot": "bg-bg-secondary text-t-primary [&_svg]:fill-indigo-600",
				"orange-dot": "bg-bg-secondary text-t-primary [&_svg]:fill-orange-600",
				"purple-dot": "bg-bg-secondary text-t-primary [&_svg]:fill-purple-600",
				"yellow-dot": "bg-bg-secondary text-t-primary [&_svg]:fill-yellow-600",
			},
			multiDayPosition: {
				first:
					"relative z-10 mr-0 rounded-r-none border-r-0 [&>span]:mr-2.5",
				middle:
					"relative z-10 mx-0 w-[calc(100%_+_1px)] rounded-none border-x-0",
				last: "ml-0 rounded-l-none border-l-0",
				none: "",
			},
		},
		defaultVariants: {
			color: "blue-dot",
		},
	}
);

export function MonthEventBadge({
    event,
    cellDate,
    eventCurrentDay,
    eventTotalDays,
    className,
    position: propPosition
}) {
	const { badgeVariant, use24HourFormat } = useCalendar();

	const itemStart = startOfDay(parseISO(event.startDate));
	const itemEnd = endOfDay(parseISO(event.endDate));

	if (cellDate < itemStart || cellDate > itemEnd) return null;

	let position;

	if (propPosition) {
		position = propPosition;
	} else if (eventCurrentDay && eventTotalDays) {
		position = "none";
	} else if (isSameDay(itemStart, itemEnd)) {
		position = "none";
	} else if (isSameDay(cellDate, itemStart)) {
		position = "first";
	} else if (isSameDay(cellDate, itemEnd)) {
		position = "last";
	} else {
		position = "middle";
	}

	const renderBadgeText = true;
	const renderDayProgress =
		Boolean(eventCurrentDay && eventTotalDays) &&
		["first", "none"].includes(position);

	const color = (badgeVariant === "dot" ? `${event.color}-dot` : event.color);

	const eventBadgeClasses = cn(eventBadgeVariants({ color, multiDayPosition: position, className }));

	return (
        <DraggableEvent event={event}>
            <EventDetailsDialog event={event}>
				<div role="button" tabIndex={0} className={eventBadgeClasses}>
					<div className="flex min-w-0 items-center gap-1 md:gap-1 truncate">
						{!["middle", "last"].includes(position) &&
							badgeVariant === "dot" && (
								<EventBullet color={event.color} />
							)}

						{renderBadgeText && (
							<p className="flex-1 truncate font-semibold text-[8px] md:text-[12px]">
								{renderDayProgress && (
									<span className="text-xs">
										Day {eventCurrentDay} of {eventTotalDays} •{" "}
									</span>
								)}
								{event.title || event.tags}
							</p>
						)}
					</div>

					<SyncStatusBadge event={event} className="hidden md:flex text-[10px]" />

					{/* <div className="hidden sm:block">
						{renderBadgeTime && (
							<span>
							{formatTime(new Date(event.startDate), use24HourFormat)}
						</span>
						)}
					</div> */}
				</div>
			</EventDetailsDialog>
        </DraggableEvent>
    );
}
