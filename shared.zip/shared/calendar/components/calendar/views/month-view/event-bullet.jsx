import { cva } from "class-variance-authority";
import { motion } from "framer-motion";
import { cn } from "@calendar/lib/utils";
import { transition } from "@calendar/components/calendar/animations";

const eventBulletVariants = cva("size-1.5 md:size-2 rounded-full", {
	variants: {
		color: {
			blue: "bg-blue-600 dark:bg-blue-500",
			green: "bg-green-600 dark:bg-green-500",
			red: "bg-red-600 dark:bg-red-500",
			indigo: "bg-indigo-600 dark:bg-indigo-500",
			yellow: "bg-yellow-600 dark:bg-yellow-500",
			purple: "bg-purple-600 dark:bg-purple-500",
			orange: "bg-orange-600 dark:bg-orange-500",
			gray: "bg-gray-600 dark:bg-gray-500",
			teal: "bg-teal-500 dark:bg-teal-700"
		},
	},
	defaultVariants: {
		color: "blue",
	},
});

export function EventBullet({
    color,
    className
}) {
	return (
        <motion.div
            className={cn(eventBulletVariants({ color, className }))}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.2 }}
            transition={transition} />
    );
}
