import { z } from "zod";
import { differenceInCalendarDays } from "date-fns";
import { TAG_FORM_CONFIG } from "@calendar/lib/calendar/form-config";
import { TAG_IDS } from "@calendar/components/calendar/constants";

/* =====================================================
   POB ITEM SCHEMA
===================================================== */
const pobItemSchema = z
  .object({
    item__name: z
      .union([
        z.string(),
        z.object({
          value: z.string(),
          label: z.string(),
        }),
      ])
      .transform((v) => (typeof v === "string" ? v : v.value)),

    qty: z.coerce.number().min(1),
    rate: z.coerce.number().min(0),
    amount: z.coerce.number(),
  })
  .superRefine((row, ctx) => {
    const expected = row.qty * row.rate;

    if (row.amount !== expected) {
      ctx.addIssue({
        path: ["amount"],
        message: "Amount must be qty × rate",
        code: z.ZodIssueCode.custom,
      });
    }
  });

/* =====================================================
   EVENT SCHEMA
===================================================== */
export const eventSchema = z
  .object({
    title: z.string().optional().or(z.literal("")),
    tags: z.string(),

    startDate: z.date(),
    endDate: z.date().optional(),
    custom_force_visit_reason :z.string().optional(),
    description: z.string().optional(),
    color: z.string().optional(),
    forceVisit: z.boolean().optional(),
    distanceKm: z.coerce.number().nullable().optional(),
    employees: z.any().optional(),
    doctor: z.any().optional(),
    allocated_to:z.any().optional(),
    shareEmployees: z.any().optional(),
    hqTerritory: z.string().optional(),
    customer: z.string().optional(),
    allDay: z.boolean().optional(),
    enableGoogleMeet: z.boolean().optional(),

    /* ---------- Leave ---------- */
    leaveType: z.string().optional(),
    leavePeriod: z.enum(["Full", "Half"]).optional(),
    medicalAttachment: z.any().optional(),
    halfDayDate: z.date().optional(),
    halfDayPosition: z.enum(["FIRST_DAY", "LAST_DAY"]).optional(),
    approvedBy: z.string().optional(),
    assignedTo:z.any().optional(),
    /* ---------- Todo ---------- */
    status: z.enum(["Open", "Closed", "Cancelled","Completed","Approved","Rejected"]).optional(),
    priority: z.enum(["High", "Medium", "Low"]).optional(),

    /* ---------- Doctor Visit ---------- */
    pob_given: z
      .union([z.literal(1), z.literal(0)])
      .optional(),
    fsl_doctor_item: z.array(pobItemSchema).optional(),
    roleId: z.string().optional(),
    leave_approver:z.string().optional(),
    escalation_approver:z.string().optional(),
    attending: z.enum(["Yes", "No","Maybe",""]).optional(),
    custom_latitude: z.coerce.number().nullable().optional(),
    custom_longitude: z.coerce.number().nullable().optional(),
  })
  .superRefine((data, ctx) => {
    const config = TAG_FORM_CONFIG[data.tags] ?? TAG_FORM_CONFIG.DEFAULT;

    /* ---------------------------------------------
       REQUIRED FIELDS (TAG CONFIG DRIVEN)
    --------------------------------------------- */
    config.required?.forEach((field) => {
      const value = data[field];

      const isEmpty =
        value === undefined ||
        value === null ||
        value === "" ||
        (Array.isArray(value) && value.length === 0);

      if (isEmpty) {
        ctx.addIssue({
          path: [field],
          message: `The ${field} is required`,
          code: z.ZodIssueCode.custom,
        });
      }
    });

    /* ---------------------------------------------
       LEAVE: NO PAST DATES
       Can't apply for a previous day. Today is still allowed
       (difference === 0); only strictly-past start dates are rejected.
    --------------------------------------------- */
    if (
      data.tags === TAG_IDS.LEAVE &&
      data.startDate &&
      differenceInCalendarDays(data.startDate, new Date()) < 0
    ) {
      ctx.addIssue({
        path: ["startDate"],
        message: "Leave can't be applied for a past date",
        code: z.ZodIssueCode.custom,
      });
    }

    /* ---------------------------------------------
       LEAVE: MEDICAL CERTIFICATE RULE
    --------------------------------------------- */
    if (
      data.tags === TAG_IDS.LEAVE &&
      data.leaveType === "Sick Leave" &&
      data.startDate &&
      data.endDate
    ) {
      const threshold =
        TAG_FORM_CONFIG.Leave?.leave?.medicalCertificateAfterDays ?? 2;

      const days =
        differenceInCalendarDays(data.endDate, data.startDate) + 1;

      if (days > threshold && !data.medicalAttachment) {
        ctx.addIssue({
          path: ["medicalAttachment"],
          message: "Medical certificate is required",
          code: z.ZodIssueCode.custom,
        });
      }
    }

    /* ---------------------------------------------
       LEAVE: HALF DAY DATE REQUIRED
    --------------------------------------------- */
    if (
      data.tags === TAG_IDS.LEAVE &&
      data.leavePeriod === "Half" &&
      !data.halfDayPosition
    ) {
      ctx.addIssue({
        path: ["halfDayPosition"],
        message: "Select which day is the half day",
        code: z.ZodIssueCode.custom,
      });
    }

    /* ---------------------------------------------
       DOCTOR VISIT PLAN: POB RULES
    --------------------------------------------- */
    if (
      data.tags === TAG_IDS.DOCTOR_VISIT_PLAN &&
      data.pob_given === 1 &&
      data.customer &&
      (!data.fsl_doctor_item || data.fsl_doctor_item.length === 0)
    ) {
      ctx.addIssue({
        path: ["fsl_doctor_item"],
        message: "At least one item is required",
        code: z.ZodIssueCode.custom,
      });
    }
  });
