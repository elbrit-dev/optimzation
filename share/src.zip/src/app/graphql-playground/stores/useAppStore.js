import { create } from 'zustand';
import { getInitialEndpoint, getEndpointConfigFromUrlKey } from '../constants';

/**
 * Global application store for GraphQL Playground
 * Manages: auth token, endpoint selection, table mode, response data
 */
export const useAppStore = create((set, get) => ({
  // Auth token - initialize with token for initial endpoint
  authToken: (() => {
    const initialEndpoint = getInitialEndpoint();
    const endpointName = initialEndpoint?.name || '';
    return getEndpointConfigFromUrlKey(endpointName)?.authToken || '';
  })(),
  setAuthToken: (token) => set({ authToken: token }),

  // Password visibility
  showPassword: false,
  setShowPassword: (show) => set({ showPassword: show }),
  toggleShowPassword: () => set((state) => ({ showPassword: !state.showPassword })),

  // Endpoint selection
  selectedEndpoint: getInitialEndpoint(),
  endpointUrl: getInitialEndpoint()?.code || '',
  setSelectedEndpoint: (endpoint) => {
    // Automatically set the token based on the selected endpoint
    const endpointName = endpoint?.name || '';
    const token = getEndpointConfigFromUrlKey(endpointName)?.authToken || '';
    
    set({
      selectedEndpoint: endpoint,
      endpointUrl: endpoint?.code || '',
      authToken: token,
      tabData: {}, // Reset all tabs when endpoint changes
    });
  },

  // Query execution state per tab
  // Map of tabIndex -> { 
  //   Query execution state:
  //   hasSuccessfulQuery: boolean, 
  //   transformedData: object | null, 
  //   transformerCode: string,
  //   processedData: object | null,  // Processed/transformed data for this tab
  //   Save control fields:
  //   clientSave: boolean,
  //   selectedKeys: string | null,
  //   expandedKeys: {},
  //   month: Date | null,
  //   monthIndexKeys: string | null,
  //   monthIndexExpandedKeys: {},
  //   searchFields: {},
  //   sortFields: {},
  //   searchFieldsExpandedKeys: {},
  //   sortFieldsExpandedKeys: {},
  // }
  tabData: {}, // { [tabIndex]: { ... } }
  setTabData: (tabIndex, data) => 
    set((state) => ({
      tabData: {
        ...state.tabData,
        [tabIndex]: {
          ...state.tabData[tabIndex],
          ...data,
        },
      },
    })),
  getTabData: (tabIndex) => {
    const state = get();
    const defaultTabData = {
      hasSuccessfulQuery: false,
      transformedData: null,
      transformerCode: '',
      processedData: null,
      // Default save control fields
      clientSave: false,
      selectedKeys: null,
      expandedKeys: {},
      month: null,
      monthIndexKeys: null,
      monthIndexExpandedKeys: {},
      searchFields: {},
      sortFields: {},
      searchFieldsExpandedKeys: {},
      sortFieldsExpandedKeys: {},
    };
    return state.tabData[tabIndex] || defaultTabData;
  },

  // GraphiQL editor state (synced from GraphiQL context)
  graphiQLState: {
    queryString: '',
    variablesString: '',
    activeTabIndex: 0,
    queryEditor: null,
    variableEditor: null,
    actions: null, // GraphiQL actions for programmatic execution
    isExecuting: false, // Track if query is currently executing
  },
  setGraphiQLState: (state) => 
    set((currentState) => ({
      graphiQLState: {
        ...currentState.graphiQLState,
        ...state,
      },
    })),
}));

