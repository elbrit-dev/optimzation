'use client';
import { indexedDBService } from '@/app/datatable/utils/indexedDBService';
import RangePicker from '@/components/RangePicker';
import { DataProvider as PlasmicDataProvider } from "@plasmicapp/loader-nextjs";
import { Switch } from 'antd';
import * as Comlink from 'comlink';
import {
    isFinite as _isFinite,
    isNaN as _isNaN,
    cloneDeep,
    every,
    filter,
    flatMap,
    get,
    head,
    includes,
    isArray,
    isBoolean,
    isEmpty,
    isNil,
    isNumber,
    orderBy,
    some,
    startCase,
    sumBy,
    take,
    toLower,
    toNumber,
    uniq
} from 'lodash';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Checkbox } from 'primereact/checkbox';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Dialog } from 'primereact/dialog';
import { Dropdown } from 'primereact/dropdown';
import { Editor } from 'primereact/editor';
import { InputNumber } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';
import { Sidebar } from 'primereact/sidebar';
import { SplitButton } from 'primereact/splitbutton';
import { TabPanel, TabView } from 'primereact/tabview';
import React, { Fragment, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { TableOperationsContext } from '../contexts/TableOperationsContext';
import { useSelectOptionsCacheStore } from '../stores/useSelectOptionsCacheStore';
import { useDataPipeline } from '../hooks/useDataPipeline';
import { useMultiSlotPipeline } from '../hooks/useMultiSlotPipeline';
import { useQueryExecution } from '../hooks/useQueryExecution';
import { applyEditingBufferToRows, getDataKeys, getDataValue, getStableRowIdentity } from '../utils/dataAccessUtils';
import { applyDerivedColumns, applyDerivedColumnsForRow, getDerivedColumnNames, getExemptFromBreakdownColumnNames, getNonAggregatableColumnNames, getOrderedColumnsWithDerived } from '../utils/derivedColumnsUtils';
import { formatDateValue } from '../utils/dateFormatUtils';
import { applyDateFilter, applyNumericFilter, filterReportRowsByMetricFilters, filterRows, hasActiveTableFilters, parseNumericFilter } from '../utils/filterUtils';
import { getMainOverrides, mergeColumnTypesOverride } from '../utils/columnTypesOverrideUtils';
import {
  buildBulkUpdateVariables,
  coalesceAddedRows,
  coalesceChangedRows,
  diffChildTableArrays,
  getDoctypeFromWriteSchema,
  getSchemaStructure,
  rowToCreateFields,
  rowToUpdateFields,
} from '../utils/formRowToApiPayload';
import {
  cacheWriteSchemaStructure,
  getCachedWriteSchemaStructure,
  tryResolveWriteSchemaFromDoctype,
} from '../utils/deriveWriteSchemaFromDoctype';
import {
  collectSelectPrefetchTargets,
  deepMergeWriteForm,
  deriveSchemaStructureFromWriteForm,
  getWriteFormFieldNode,
  getWriteFormFields,
  getWriteFormLayout,
  gridItemStyleFromFieldLayout,
  materializeWriteFormRuntime,
  normalizeWriteForm,
  sortDrawerFieldItemsByLayout,
} from '../utils/writeFormUtils';
import { isJsonArrayOfObjectsString, parseJsonObject } from '../utils/jsonArrayParser';
import { flattenToLeafRows, formatStringBreakdownForExcel } from '../utils/perSlotPipelineUtils';
import { resolveWritePermissions, computeWriteOpsNeeded, getFirstWritePermissionViolation } from '../utils/writePermissionsUtils';
import { getAllowedForScope } from '../utils/allowedColumnsUtils';
import { alignExportColumnsToUiOrder, getOrderedDisplayColumns } from '../utils/columnOrderUtils';
import { useReportData } from '../utils/providerUtils';
import { transformToReportData } from '../utils/reportUtils';
import { appendReportLevelSheet } from '../utils/reportExportUtils';
import { isDateLike, isNumericValue } from '../utils/typeDetectionUtils';
import { extractStateFromConfig } from '../config/configService';
import { firestoreService } from '@/app/graphql-playground/services/firestoreService';
import { fetchGraphQLRequest } from '@/app/graphql-playground/utils/query-pipeline';
import { getEndpointAndAuthWithTokenOverride } from '../utils/queryEndpointUtils';
import DataTableComponent from './DataTableNew';
import { useSlotId } from './DataSlot';
import FilterSortSidebar from './FilterSortSidebar';
import MultiselectFilter from './MultiselectFilter';
import SingleSelectFilter from './SingleSelectFilter';

/**
 * Match main-table buffer init: deep clone, top-level __editingKey__, then keys on nested object-child arrays.
 */
function mainTableEditingRowsFromLeafData(rows, addEditingKeysToRows) {
  if (!isArray(rows) || isEmpty(rows)) return [];
  const withTopKeys = addEditingKeysToRows(cloneDeep(rows));
  return withTopKeys.map((row) => {
    if (!row || typeof row !== 'object') return row;
    const next = { ...row };
    Object.keys(next).forEach((k) => {
      if (String(k).startsWith('__')) return;
      const v = next[k];
      if (isArray(v) && v.every((item) => item == null || (typeof item === 'object' && !isArray(item)))) {
        next[k] = addEditingKeysToRows(v);
      }
    });
    return next;
  });
}

/** Ref + hash pair used to avoid redundant buffer re-inits from sortedData. */
function sortedDataInitCursor(sortedData) {
  if (!isArray(sortedData) || sortedData.length === 0) {
    return { ref: sortedData, hash: '0_empty' };
  }
  const firstKey = getStableRowIdentity(sortedData[0], 0);
  const lastKey = getStableRowIdentity(sortedData[sortedData.length - 1], sortedData.length - 1);
  return { ref: sortedData, hash: `${sortedData.length}_${firstKey}_${lastKey}` };
}

/** Includes sidebar + column sort so buffer sync does not skip when only order / sig changes. */
function sortedDataRefreshHash(sortedDataSnap, sortConfig, tableSortMeta, sidebarSig) {
  const base = sortedDataInitCursor(sortedDataSnap).hash;
  const sortPart = `${sortConfig?.field ?? ''}|${sortConfig?.direction ?? ''}|${JSON.stringify(tableSortMeta ?? [])}|${sidebarSig ?? ''}`;
  return `${base}|${sortPart}`;
}

// Form Select with async getOptions support - getOptions(ctx) receives ctx with columnName, query (row-independent)
// When cachedOptions is provided, uses it directly to avoid re-fetch on parent re-renders (e.g. cell edit mode changes)
function FormSelectOptionsField({ col, value, label, handleChange, getOptions, ctx, cachedOptions }) {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (cachedOptions !== undefined && Array.isArray(cachedOptions)) {
      setOptions(cachedOptions.map((s) => ({ label: String(s), value: String(s) })));
      setLoading(false);
      return;
    }
    if (!getOptions || typeof getOptions !== 'function') {
      setOptions([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const result = getOptions(ctx);
    if (result && typeof result.then === 'function') {
      result.then((arr) => {
        setOptions(Array.isArray(arr) ? arr.map((s) => ({ label: String(s), value: String(s) })) : []);
      }).catch(() => {
        setOptions([]);
      }).finally(() => setLoading(false));
    } else {
      setOptions(Array.isArray(result) ? result.map((s) => ({ label: String(s), value: String(s) })) : []);
      setLoading(false);
    }
  }, [getOptions, ctx.columnName, cachedOptions]);
  return (
    <div className="flex flex-col gap-1">
      <label className="text-xs font-medium text-gray-700">{label}</label>
      <SingleSelectFilter
        value={value != null ? String(value) : null}
        options={options}
        onChange={handleChange}
        placeholder="Select..."
        loading={loading}
        fieldName={label}
      />
    </div>
  );
}

// Upload is deferred — file is stored via onFilePending and uploaded when the drawer save is confirmed.
function FormUploadField({ fieldId, docname, value, label, onFilePending }) {
  const [pendingFile, setPendingFile] = useState(null);
  const inputRef = useRef(null);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPendingFile(file);
    onFilePending(fieldId, file);
    if (inputRef.current) inputRef.current.value = '';
  };

  const disabled = !docname;

  return (
    <div className="flex flex-col gap-1">
      <label className="text-xs font-medium text-gray-700">{label}</label>
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center gap-2 flex-wrap">
          <input
            ref={inputRef}
            type="file"
            id={`upload-${fieldId}`}
            className="hidden"
            disabled={disabled}
            onChange={handleFileSelect}
          />
          <label
            htmlFor={`upload-${fieldId}`}
            className={`px-3 py-1.5 text-sm border rounded cursor-pointer select-none ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-50'}`}
          >
            {pendingFile ? 'Change File' : 'Choose File'}
          </label>
          {pendingFile && (
            <span className="text-xs text-amber-600 font-medium">⏳ {pendingFile.name} — will upload on save</span>
          )}
          {!docname && (
            <span className="text-xs text-red-400">docname not available</span>
          )}
        </div>
        {value && !pendingFile && (
          <a
            href={value}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-blue-500 hover:underline truncate"
            title={value}
          >
            {value.split('/').pop() || value}
          </a>
        )}
      </div>
    </div>
  );
}

// Quill Editor toolbar for formInputOverride 'Quill' - Headings, font size, formatting, colors, blockquote, code, RTL, link, image, lists, align, indent
const quillFormToolbar = (
  <>
    <span className="ql-formats">
      <select className="ql-header" defaultValue="">
        <option value="1">H1</option>
        <option value="2">H2</option>
        <option value="3">H3</option>
        <option value="4">H4</option>
        <option value="5">H5</option>
        <option value="6">H6</option>
        <option value="">Normal</option>
      </select>
      <select className="ql-size" defaultValue="">
        <option value="small">Small</option>
        <option value="">Normal</option>
        <option value="large">Large</option>
        <option value="huge">Huge</option>
      </select>
    </span>
    <span className="ql-formats">
      <button type="button" className="ql-bold" aria-label="Bold" />
      <button type="button" className="ql-italic" aria-label="Italic" />
      <button type="button" className="ql-underline" aria-label="Underline" />
      <button type="button" className="ql-strike" aria-label="Strike" />
    </span>
    <span className="ql-formats">
      <select className="ql-color" defaultValue="" />
      <select className="ql-background" defaultValue="" />
    </span>
    <span className="ql-formats">
      <button type="button" className="ql-blockquote" aria-label="Blockquote" />
      <button type="button" className="ql-code-block" aria-label="Code block" />
    </span>
    <span className="ql-formats">
      <button type="button" className="ql-direction" value="rtl" aria-label="RTL" />
    </span>
    <span className="ql-formats">
      <button type="button" className="ql-link" aria-label="Link" />
      <button type="button" className="ql-image" aria-label="Image" />
    </span>
    <span className="ql-formats">
      <select className="ql-list" defaultValue="">
        <option value="ordered">Ordered</option>
        <option value="bullet">Bullet</option>
        <option value="check">Check</option>
        <option value="">None</option>
      </select>
    </span>
    <span className="ql-formats">
      <select className="ql-align" defaultValue="" />
    </span>
    <span className="ql-formats">
      <button type="button" className="ql-indent" value="-1" aria-label="Outdent" />
      <button type="button" className="ql-indent" value="+1" aria-label="Indent" />
    </span>
    <span className="ql-formats">
      <button type="button" className="ql-clean" aria-label="Remove formatting" />
    </span>
  </>
);

export default function DataProviderNew({
  config: configProp,
  offlineData,
  onDataChange,
  onError,
  children,
  overrides,
  __internal = {},
}) {
  const {
    skipConfirmDialog = false,
    showProviderHeader = true,
    // Optional caller-supplied header content: { top, left, right }. `top` is a
    // full-width row above the control row (e.g. a search bar); `left`/`right`
    // bracket selectorsJSX inside its existing justify-between row.
    // Null by default, so callers that don't pass it render exactly as before.
    headerSlots = null,
    // Drop the built-in "Filter / Sort" button when the caller supplies its own
    // sort UI. Applied-filter chips are kept either way.
    hideNativeFilterSort = false,
    reportDataOverride = null,
    forceBreakdown = null,
    parentColumnName,
    nestedTableFieldName,
    forceEnableWrite,
    derivedColumnsMode,
    derivedColumnsFieldName,
    parentOriginalNestedTableDataRef,
    parentNestedTableEditingDataRef,
    parentHandleDrawerSaveProp,
    nestedTableTabId,
    fallbackColumns,
    onNestedBufferChange,
    parentHandleAddNestedRowAtZero,
    visibleColumns: visibleColumnsProp = null,
    onTableDataChange,
    onAllowedColumnsChange,
    onVisibleColumnsChange,
  } = __internal;
  // --- Config: only objects accepted; callers must resolve before passing ---
  const resolvedConfig = (typeof configProp === 'object' && configProp !== null) ? configProp : {};
  const configValues = useMemo(() => extractStateFromConfig(resolvedConfig), [resolvedConfig]);

  const {
    enableSort, enableFilter, enableSummation, enableGrouping,
    enableCellEdit, enableDivideBy1Lakh, enableReport,
    textFilterColumns, allowedColumns, percentageColumns,
    derivedColumns, derivedRows, groupFields,
    redFields, greenFields, rowColumnStyles,
    columnTypesOverride: rootColumnTypesOverrideConfig,
    writeForm: rootWriteFormConfig,
    drawerTabs: configDrawerTabs, dateColumn, columnsExemptFromBreakdown,
    chartColumns, chartHeight, showChart, breakdownType: configBreakdownType, columnGroupBy: configColumnGroupBy,
    isAdminMode, salesTeamColumn, salesTeamValues, hqColumn, hqValues,
    dataSource: configDataSource, selectedQueryKey: selectedQueryKeyProp,
    rowsPerPageOptions, defaultRows, tableHeight, scrollable, enableFullscreenDialog,
    slots: configSlots,
    writePermissions: configWritePermissions,
    groupDrawerAccess: configGroupDrawerAccess,
  } = configValues;

  const variableOverrides = useMemo(() => ({
    ...(resolvedConfig.variableOverrides ?? {}),
    ...(overrides?.variables ?? {}),
  }), [resolvedConfig, overrides]);

  const graphqlToken = overrides?.token ?? null;

  // Manage drawer tabs internally (initialized from config, modified dynamically)
  const [internalDrawerTabs, setInternalDrawerTabs] = useState(() => {
    const tabs = configDrawerTabs;
    return tabs?.length > 0 ? tabs : [{ id: `tab-${Date.now()}`, name: '', outerGroup: null, innerGroup: null }];
  });
  const drawerTabs = internalDrawerTabs;
  const onDrawerTabsChange = setInternalDrawerTabs;

  const rootWriteForm = rootWriteFormConfig && typeof rootWriteFormConfig === 'object' ? rootWriteFormConfig : {};
  const rootColumnTypesOverride =
    rootColumnTypesOverrideConfig && typeof rootColumnTypesOverrideConfig === 'object' ? rootColumnTypesOverrideConfig : {};

  // Merge root writeForm + columnTypesOverride into each slot (or single synthetic main slot)
  const slots = useMemo(() => {
    const mergeSlot = (slot) => ({
      ...slot,
      writeForm: deepMergeWriteForm(
        rootWriteForm,
        slot?.writeForm && typeof slot.writeForm === 'object' ? slot.writeForm : {},
      ),
      columnTypesOverride: mergeColumnTypesOverride(
        rootColumnTypesOverride,
        slot?.columnTypesOverride && typeof slot.columnTypesOverride === 'object' ? slot.columnTypesOverride : {},
      ),
    });
    if (configSlots && typeof configSlots === 'object' && Object.keys(configSlots).length > 0) {
      const out = {};
      for (const id of Object.keys(configSlots)) {
        out[id] = mergeSlot(configSlots[id] || {});
      }
      return out;
    }
    return {
      main: mergeSlot({
        enableSort, enableFilter, enableSummation, enableGrouping,
        textFilterColumns, allowedColumns, percentageColumns,
        derivedColumns, derivedRows, groupFields,
        redFields, greenFields, rowColumnStyles,
        enableDivideBy1Lakh,
        enableCellEdit,
        drawerTabs, enableReport, dateColumn, chartColumns, chartHeight,
        writePermissions: configWritePermissions,
        groupDrawerAccess: configGroupDrawerAccess,
      }),
    };
  }, [configSlots, enableSort, enableFilter, enableSummation, enableGrouping, textFilterColumns, allowedColumns, percentageColumns, derivedColumns, derivedRows, groupFields, redFields, greenFields, rowColumnStyles, enableDivideBy1Lakh, enableCellEdit, drawerTabs, enableReport, dateColumn, chartColumns, chartHeight, configWritePermissions, configGroupDrawerAccess, rootWriteForm, rootColumnTypesOverride]);

  const slotIds = useMemo(() => Object.keys(slots), [slots]);
  const mainSlotConfig = useMemo(() => slots[slotIds[0]] || {}, [slots, slotIds]);
  const effectiveMainConfig = useMemo(() => ({
    enableSort: mainSlotConfig.enableSort ?? enableSort,
    enableFilter: mainSlotConfig.enableFilter ?? enableFilter,
    enableSummation: mainSlotConfig.enableSummation ?? enableSummation,
    enableGrouping: mainSlotConfig.enableGrouping ?? enableGrouping,
    textFilterColumns: mainSlotConfig.textFilterColumns ?? textFilterColumns,
    percentageColumns: mainSlotConfig.percentageColumns ?? percentageColumns,
    derivedColumns: mainSlotConfig.derivedColumns ?? derivedColumns,
    derivedRows: mainSlotConfig.derivedRows ?? derivedRows,
    groupFields: mainSlotConfig.groupFields ?? groupFields,
    redFields: mainSlotConfig.redFields ?? redFields,
    greenFields: mainSlotConfig.greenFields ?? greenFields,
    rowColumnStyles: mainSlotConfig.rowColumnStyles ?? rowColumnStyles,
    enableCellEdit: mainSlotConfig.enableCellEdit ?? enableCellEdit,
    writeForm: mainSlotConfig.writeForm ?? rootWriteForm,
    drawerTabs: mainSlotConfig.drawerTabs ?? drawerTabs,
    writePermissions: mainSlotConfig.writePermissions ?? configWritePermissions,
    groupDrawerAccess: mainSlotConfig.groupDrawerAccess ?? configGroupDrawerAccess,
  }), [mainSlotConfig, enableSort, enableFilter, enableSummation, enableGrouping, textFilterColumns, percentageColumns, derivedColumns, derivedRows, groupFields, redFields, greenFields, rowColumnStyles, enableCellEdit, rootWriteForm, drawerTabs, configWritePermissions, configGroupDrawerAccess]);

  const effectiveMainWriteForm = useMemo(
    () => normalizeWriteForm(
      effectiveMainConfig.writeForm && typeof effectiveMainConfig.writeForm === 'object' ? effectiveMainConfig.writeForm : {},
    ),
    [effectiveMainConfig.writeForm],
  );
  const effectiveMainRuntime = useMemo(
    () => materializeWriteFormRuntime(effectiveMainWriteForm),
    [effectiveMainWriteForm],
  );
  const { editableColumns, readOnlyDisplayColumns, formInputOverride } = effectiveMainRuntime;
  const mainColumnTypesOverride = useMemo(
    () =>
      mainSlotConfig.columnTypesOverride && typeof mainSlotConfig.columnTypesOverride === 'object'
        ? mainSlotConfig.columnTypesOverride
        : {},
    [mainSlotConfig.columnTypesOverride],
  );
  const [preFilterValues, setPreFilterValues] = useState({});
  const sidebarActiveFilterSig = useMemo(() => {
    if (!preFilterValues || typeof preFilterValues !== 'object') return '';
    const sortedKeys = Object.keys(preFilterValues).sort();
    const parts = [];
    for (const k of sortedKeys) {
      const v = preFilterValues[k];
      if (!isArray(v) || v.length === 0) continue;
      const vals = [...v].map(String).sort((a, b) => a.localeCompare(b)).join('|');
      parts.push(`${k}:${vals}`);
    }
    return parts.join(';');
  }, [preFilterValues]);
  /** Previous sidebarActiveFilterSig; allows reseed when clearing to empty (would otherwise idle-skip forever). */
  const sidebarFilterSigPrevRef = useRef('');
  const [filterSortSidebarVisible, setFilterSortSidebarVisible] = useState(false);
  // Sort-only presentation of the sidebar (used by the Views variant's compact
  // pill, where the search bar owns filtering). The native button always opens full.
  const [filterSortSidebarSortOnly, setFilterSortSidebarSortOnly] = useState(false);
  const openFilterSortSidebar = useCallback((options) => {
    setFilterSortSidebarSortOnly(options?.sortOnly === true);
    setFilterSortSidebarVisible(true);
  }, []);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState(null);
  const [isApplyingFilterSort, setIsApplyingFilterSort] = useState(false);
  const [columnGroupBy, setColumnGroupBy] = useState(configColumnGroupBy ?? 'values');
  const [breakdownType, setBreakdownType] = useState(configBreakdownType ?? 'month');
  const [enableBreakdown, setEnableBreakdown] = useState(forceBreakdown ?? false);

  const stableOfflineData = useMemo(
    () => (Array.isArray(offlineData) ? offlineData : []),
    [offlineData],
  );

  const queryExecution = useQueryExecution({
    dataSourceProp: configDataSource,
    selectedQueryKeyProp,
    offlineData: stableOfflineData,
    onError,
    onDataChange,
    variableOverrides,
    searchTerm,
    sortConfig,
    graphqlToken,
  });
  const {
    dataSource,
    selectedQueryKey,
    executingQuery,
    loadingFromCache,
    processedData,
    monthRange,
    setMonthRange,
    hasMonthSupport,
    currentQueryDoc,
    lastUpdatedAt,
    indexFreshnessToken,
    offlineDataExecuted,
    runQuery,
    queryFunction,
    checkIndexedDBAndLoadData,
    availableQueryKeys,
    formatLastUpdatedDate,
    workerRef,
    setProcessedData,
  } = queryExecution;

  const enableWriteEffective = useMemo(
    () => forceEnableWrite !== undefined ? forceEnableWrite : (currentQueryDoc?.enableWrite || false),
    [forceEnableWrite, currentQueryDoc?.enableWrite],
  );

  const resolvedWritePermissions = useMemo(() => {
    const partial = effectiveMainConfig.writePermissions ?? resolvedConfig.writePermissions;
    return resolveWritePermissions(enableWriteEffective, partial);
  }, [enableWriteEffective, effectiveMainConfig.writePermissions, resolvedConfig.writePermissions]);

  useEffect(() => {
    const name = currentQueryDoc?.writeDocTypeName ?? currentQueryDoc?.writeDocType;
    const trimmed = name && String(name).trim();
    if (!trimmed || currentQueryDoc?.writeSchema) return;
    let cancelled = false;
    tryResolveWriteSchemaFromDoctype({ writeDocTypeName: trimmed, graphqlToken }).then((s) => {
      if (!cancelled && s) cacheWriteSchemaStructure(trimmed, s);
    });
    const derived = deriveSchemaStructureFromWriteForm(effectiveMainWriteForm);
    if (
      (derived.mainFields?.length || Object.keys(derived.childTables || {}).length) &&
      !getCachedWriteSchemaStructure(trimmed)
    ) {
      cacheWriteSchemaStructure(trimmed, derived);
    }
    return () => {
      cancelled = true;
    };
  }, [
    currentQueryDoc?.writeSchema,
    currentQueryDoc?.writeDocTypeName,
    currentQueryDoc?.writeDocType,
    graphqlToken,
    effectiveMainWriteForm,
  ]);

  // Mobile detection for responsive Switch sizing
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    const checkMobile = () => {
      const windowWidth = window.innerWidth;
      const isMobileNow = windowWidth < 768;
      setIsMobile(isMobileNow);
    };

    // Check immediately
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  // Table operation state (needed before pipeline for hook options)
  // When multi-slot (slotIds.length > 1), use per-slot maps; otherwise flat state for backward compat
  const isMultiSlot = slotIds.length > 1;
  const [tableFilters, setTableFilters] = useState({});
  const [tableSortMeta, setTableSortMeta] = useState([]);
  const [tablePagination, setTablePagination] = useState({ first: 0, rows: 10 });
  const [tableExpandedRows, setTableExpandedRows] = useState(null);
  const [tableVisibleColumns, setTableVisibleColumns] = useState(visibleColumnsProp || []);
  const [tableFiltersBySlot, setTableFiltersBySlot] = useState({});
  const [tableSortMetaBySlot, setTableSortMetaBySlot] = useState({});
  const [tablePaginationBySlot, setTablePaginationBySlot] = useState({});
  const reportDataRef = useRef(null);
  // Pipeline must see current reportData; ref is updated in useEffect so it's one render behind.
  // Sync reportData into state so useDataPipeline re-runs when report is ready (avoids "No data available").
  const [reportDataForPipeline, setReportDataForPipeline] = useState(null);

  const computedFallbackColumns = useMemo(() => {
    if (fallbackColumns && isArray(fallbackColumns) && fallbackColumns.length > 0) return fallbackColumns;
    if (parentColumnName) {
      const nestedCols = editableColumns?.nested?.[parentColumnName];
      if (nestedCols && isArray(nestedCols) && nestedCols.length > 0) return nestedCols;
      return undefined;
    }
    const mainCols = editableColumns?.main;
    const allowed = getAllowedForScope(allowedColumns, 'main');
    if (mainCols?.length) return mainCols;
    if (allowed?.length) return allowed;
    return undefined;
  }, [fallbackColumns, parentColumnName, editableColumns, allowedColumns]);

  const slotStateBySlot = useMemo(() => {
    const bySlot = {};
    for (const sid of slotIds) {
      bySlot[sid] = {
        tableFilters: isMultiSlot ? (tableFiltersBySlot[sid] ?? {}) : tableFilters,
        tableSortMeta: isMultiSlot ? (tableSortMetaBySlot[sid] ?? []) : tableSortMeta,
        tablePagination: isMultiSlot ? (tablePaginationBySlot[sid] ?? { first: 0, rows: 10 }) : tablePagination,
      };
    }
    return bySlot;
  }, [slotIds, isMultiSlot, tableFiltersBySlot, tableSortMetaBySlot, tablePaginationBySlot, tableFilters, tableSortMeta, tablePagination]);

  const pipeline = useMultiSlotPipeline({
    dataSource,
    processedData,
    selectedQueryKey,
    offlineData,
    offlineDataExecuted,
    fallbackColumns: computedFallbackColumns,
    isAdminMode,
    salesTeamColumn,
    salesTeamValues,
    hqColumn,
    hqValues,
    preFilterValues,
    currentQueryDoc,
    searchTerm,
    sortConfig,
    columnTypesOverride: mainColumnTypesOverride,
    tableFilters,
    groupFields: effectiveMainConfig.groupFields,
    tablePagination,
    tableSortMeta,
    enableFilter: effectiveMainConfig.enableFilter,
    enableSort: effectiveMainConfig.enableSort,
    enableBreakdown,
    reportData: reportDataForPipeline,
    allowedColumns: getAllowedForScope(allowedColumns, 'main') ?? (Array.isArray(allowedColumns) ? allowedColumns : []),
    percentageColumns: effectiveMainConfig.percentageColumns,
    derivedColumns: effectiveMainConfig.derivedColumns,
    derivedRows: effectiveMainConfig.derivedRows,
    queryFunction,
    textFilterColumns: effectiveMainConfig.textFilterColumns,
    dateColumn,
    monthRange: monthRange && Array.isArray(monthRange) && monthRange.length === 2 ? monthRange : null,
    derivedColumnsMode: derivedColumnsMode ?? 'main',
    derivedColumnsFieldName: derivedColumnsFieldName ?? null,
    useOfflineDataAsTableDataSource: !!(nestedTableTabId && parentNestedTableEditingDataRef),
    slots,
    slotIds,
    slotStateBySlot,
  });

  const pipelinesBySlot = pipeline.pipelinesBySlot ?? {};
  const mainPipeline = pipelinesBySlot[slotIds[0]] ?? pipeline;
  const {
    rawTableData,
    preFilteredData,
    tableData,
    searchSortSortedData,
    filteredData,
    groupedData,
    sortedData,
    paginatedData,
    addEditingKeysToRows,
    mainTableEditingDataRefEarly,
    setTableDataUpdateTrigger,
    derivedRowsLoading,
    effectiveGroupFields,
    sortFieldType,
    jsonObjectFields,
  } = {
    ...pipeline,
    filteredData: mainPipeline?.filteredData ?? pipeline.filteredData,
    groupedData: mainPipeline?.groupedData ?? pipeline.groupedData,
    sortedData: mainPipeline?.sortedData ?? pipeline.sortedData,
    paginatedData: mainPipeline?.paginatedData ?? pipeline.paginatedData,
    effectiveGroupFields: mainPipeline?.effectiveGroupFields ?? pipeline.effectiveGroupFields,
  };

  // Latest pipeline slice for Filter & Sort re-seed (ref so layout effect does not depend on array identity churn).
  const preFilteredDataForSidebarReseedRef = useRef(preFilteredData);
  preFilteredDataForSidebarReseedRef.current = preFilteredData;

  // runQuery comes from useQueryExecution

  // Sync visibleColumns from prop
  useEffect(() => {
    if (visibleColumnsProp !== null && visibleColumnsProp !== undefined) {
      setTableVisibleColumns(visibleColumnsProp);
    }
  }, [visibleColumnsProp]);

  // Access parent context to get handleDrawerSave for nested drawer tables
  const parentSlotId = useSlotId() ?? 'main';
  const parentContext = useContext(TableOperationsContext);
  const parentSlotData = parentContext?.rawData !== undefined ? parentContext : parentContext?.[parentSlotId];
  const parentHandleDrawerSave = parentHandleDrawerSaveProp || parentSlotData?.handleDrawerSave;

  // Filter/Sort worker state (declared early for use in useMemo hooks)
  const filterSortWorkerRef = useRef(null);
  const filterSortWorkerInstanceRef = useRef(null);
  const filterSortComputationIdRef = useRef(0);
  const [workerComputedData, setWorkerComputedData] = useState(null);

  // Drawer state
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [drawerData, setDrawerData] = useState([]);
  const selectOptionsCache = useSelectOptionsCacheStore((s) => s.cache);
  const [activeDrawerTabIndex, setActiveDrawerTabIndex] = useState(0);
  const [clickedDrawerValues, setClickedDrawerValues] = useState({ outerValue: null, innerValue: null });
  const [drawerHeaderTitle, setDrawerHeaderTitle] = useState(null);
  const [drawerTableOptions, setDrawerTableOptions] = useState(null);
  const [, setDrawerJsonTables] = useState(null); // Store nested JSON tables for drawer
  const drawerCloseTimeoutRef = useRef(null); // For deferring content clear until after hide animation

  // Change tracking for nested tables
  // Map structure: tabId -> { originalData: [...], parentRowData: {...}, nestedTableFieldName: string, parentRowEditingKey: string }
  // Use parent refs if provided (for nested instances), otherwise create own refs
  const originalNestedTableDataRef = parentOriginalNestedTableDataRef || useRef(new Map());
  const nestedTableDataRefsRef = useRef(new Map()); // Store refs to nested DataProviderNew instances to access current data
  const nestedTableEditingDataRef = parentNestedTableEditingDataRef || useRef(new Map()); // Track current editing data per tab (renamed from currentNestedTableDataRef for clarity)

  // Main table buffer state management
  const mainTableOriginalDataRef = useRef([]); // Original buffer (baseline)
  // Use the early ref we created
  const mainTableEditingDataRef = mainTableEditingDataRefEarly; // Editing buffer (working copy)
  const [mainTableEditingData, setMainTableEditingData] = useState([]); // Editing buffer state for reactivity

  // Debounced derived-column recompute for the edited row only
  const derivedRecomputeTimerRef = useRef(null);
  const pendingDerivedRecomputeKeyRef = useRef(null);

  // Parent re-render when nested table buffer is updated (so nested tab gets new tabDataSource)
  const [nestedTableUpdateCounter, setNestedTableUpdateCounter] = useState(0);
  const handleNestedBufferChange = useCallback(() => setNestedTableUpdateCounter((v) => v + 1), []);

  // Selected row in main table (for sidebar form editing) - only used by root provider
  const [selectedRowData, setSelectedRowData] = useState(null);

  // Form buffer (same pattern as nested table): original = baseline, editing = working copy
  const formOriginalRowRef = useRef(null);
  const [formEditingRow, setFormEditingRow] = useState(null);
  const formEditingRowRef = useRef(null);
  formEditingRowRef.current = formEditingRow;
  const pendingUploadsRef = useRef(new Map()); // fieldId → { file, getAuth }

  // Main table save payload dialog (show create/update structure before confirming save)
  const [saveDiffDialogVisible, setSaveDiffDialogVisible] = useState(false);
  const [saveDiffDialogSaving, setSaveDiffDialogSaving] = useState(false);
  const [savePayloadContent, setSavePayloadContent] = useState({
    createPayload: null,
    updatePayload: null,
    removedRows: [],
    doctype: null,
    changedRows: null,
    schemaStructure: null,
    skipKey: null,
    writeOpsNeeded: null,
    bulkUpdateParentField: null,
    bulkUpdateVariablesPreview: null,
  });
  const [savePayloadDisplayQueries, setSavePayloadDisplayQueries] = useState({ bulkCreate: null, bulkUpdate: null });
  const savePayloadElbritRef = useRef(null);

  // Export group selector (when groupFields active, popup to choose which levels to export)
  const [exportGroupSelectorVisible, setExportGroupSelectorVisible] = useState(false);
  const [exportGroupSelectorSelectedLevels, setExportGroupSelectorSelectedLevels] = useState([]);
  /** Group field list shown in export dialog & levels pre-selected — may differ per slot when multi-slot */
  const [exportDialogGroupFields, setExportDialogGroupFields] = useState([]);
  const exportGroupOverridesRef = useRef(null);
  // Bump when we persist so hasMainTableChanges recomputes and Cancel hides
  const [mainTableOriginalVersion, setMainTableOriginalVersion] = useState(0);

  // Sync mainTableEditingData state with the ref for reactivity
  // Also update the early ref so tableData can pick it up
  // NOTE: We don't increment version here because propagateDrawerSaveToMain already does it
  // and we don't want double increments causing excessive recalculations
  useEffect(() => {
    if (mainTableEditingData && isArray(mainTableEditingData) && !isEmpty(mainTableEditingData)) {
      mainTableEditingDataRef.current = mainTableEditingData;
      mainTableEditingDataRefEarly.current = mainTableEditingData;
    } else if (!mainTableEditingData || !isArray(mainTableEditingData) || isEmpty(mainTableEditingData)) {
      // Clear refs if state is empty
      mainTableEditingDataRef.current = [];
      mainTableEditingDataRefEarly.current = [];
    }
  }, [mainTableEditingData]);

  // When dataSource, selectedQueryKey, or monthRange changes, clear editing buffer so tableData falls back to preFilteredData (stale buffer blocks data flow)
  // Only clear when values actually transition (not on initial mount with same values - avoids clearing during offline init)
  const prevDataSourceKeyRef = useRef(null);
  const monthRangeStr = monthRange && Array.isArray(monthRange) && monthRange.length === 2
    ? `${monthRange[0]?.getTime?.() ?? 'null'}_${monthRange[1]?.getTime?.() ?? 'null'}`
    : 'null';
  useEffect(() => {
    const key = `${dataSource}|${selectedQueryKey}|${monthRangeStr}`;
    const prevKey = prevDataSourceKeyRef.current;
    prevDataSourceKeyRef.current = key;
    if (prevKey !== null && prevKey !== key) {
      if (derivedRecomputeTimerRef.current) {
        clearTimeout(derivedRecomputeTimerRef.current);
        derivedRecomputeTimerRef.current = null;
      }
      pendingDerivedRecomputeKeyRef.current = null;
      mainTableEditingDataRefEarly.current = [];
      mainTableEditingDataRef.current = [];
      setMainTableEditingData([]);
      setTableDataUpdateTrigger((t) => t + 1);
    }
  }, [dataSource, selectedQueryKey, monthRangeStr]);

  // When groupFields changes, clear buffer so pipeline re-groups from flat data (enables different grouping levels)
  const prevGroupFieldsRef = useRef(null);
  useEffect(() => {
    const gf = effectiveMainConfig.groupFields;
    const prev = prevGroupFieldsRef.current;
    prevGroupFieldsRef.current = gf;
    if (prev !== null && prev !== gf) {
      const prevStr = isArray(prev) ? prev.join(',') : String(prev);
      const currStr = isArray(gf) ? gf.join(',') : String(gf);
      if (prevStr !== currStr) {
        mainTableEditingDataRefEarly.current = [];
        mainTableEditingDataRef.current = [];
        setMainTableEditingData([]);
        setTableDataUpdateTrigger((t) => t + 1);
      }
    }
  }, [effectiveMainConfig.groupFields]);

  // Ensure at least one tab exists
  useEffect(() => {
    const tabs = effectiveMainConfig.drawerTabs;
    if (!tabs || tabs.length === 0) {
      if (onDrawerTabsChange) {
        onDrawerTabsChange([{ id: `tab-${Date.now()}`, name: '', outerGroup: null, innerGroup: null }]);
      }
    }
  }, [effectiveMainConfig.drawerTabs, onDrawerTabsChange]);

  // Pre-fetch all Select getOptions (main + nested) in parallel when root mounts - before drawer opens
  // Cache is ready for FormSelectOptionsField and InlineSelectCellEditor when user opens drawer
  const selectOptionsPrefetchDoneRef = useRef(false);
  useEffect(() => {
    if (parentColumnName || !enableCellEdit) return;
    if (selectOptionsPrefetchDoneRef.current) return;
    selectOptionsPrefetchDoneRef.current = true;
    const fio = formInputOverride ?? {};
    const query = queryFunction ?? (async () => { throw new Error('Query execution not available'); });
    const toFetch = [];
    const mainOverrides = fio.main ?? {};
    for (const col of Object.keys(mainOverrides)) {
      const ov = mainOverrides[col];
      if (typeof ov === 'object' && ov?.type === 'Select' && (ov.getOptions || ov.getOptionsCode)) toFetch.push({ parentCol: 'main', col });
    }
    const nestedOverrides = fio.nested ?? {};
    for (const parentCol of Object.keys(nestedOverrides)) {
      const cols = nestedOverrides[parentCol];
      if (cols && typeof cols === 'object') {
        for (const col of Object.keys(cols)) {
          const ov = cols[col];
          if (typeof ov === 'object' && ov?.type === 'Select' && (ov.getOptions || ov.getOptionsCode)) toFetch.push({ parentCol, col });
        }
      }
    }
    if (toFetch.length === 0) return;
    let cancelled = false;
    const fetchOne = async ({ parentCol, col }) => {
      const ov = parentCol === 'main' ? (mainOverrides[col]) : (nestedOverrides[parentCol]?.[col]);
      let getOptions = ov?.getOptions;
      if (typeof getOptions !== 'function' && typeof ov?.getOptionsCode === 'string' && ov.getOptionsCode?.trim()) {
        try {
          getOptions = new Function('ctx', 'return (' + ov.getOptionsCode + ')(ctx);');
        } catch (err) {
          console.warn('[FormInputOverride] Invalid getOptionsCode for column', col, err);
          return;
        }
      }
      if (typeof getOptions !== 'function') return;
      const ctx = { columnName: col, query };
      try {
        const result = await Promise.resolve(getOptions(ctx));
        const arr = Array.isArray(result) ? result : [];
        const key = `${parentCol}|${col}`;
        // Always update Zustand store when result arrives - survives effect cancellation
        useSelectOptionsCacheStore.getState().setEntry(key, arr);
      } catch (err) {
        if (!cancelled) {
          console.warn('[FormInputOverride] getOptions failed for', parentCol, col, err);
        }
      }
    };
    toFetch.forEach((entry) => fetchOne(entry));
    return () => { cancelled = true; };
  }, [parentColumnName, enableCellEdit, formInputOverride, queryFunction]);

  // Clear debounced derived recompute timer on unmount
  useEffect(() => {
    return () => {
      if (derivedRecomputeTimerRef.current) {
        clearTimeout(derivedRecomputeTimerRef.current);
        derivedRecomputeTimerRef.current = null;
      }
      pendingDerivedRecomputeKeyRef.current = null;
    };
  }, []);

  const prevRawDataLogicalHashRef = useRef(null);
  const prevTableDataLogicalHashRef = useRef(null);

  // Note: onTableDataChange is called later with final sortedData (line 2904)
  // which includes both searchFields/sortFields sorting and tableSortMeta sorting

  // Sync function that retriggers query execution
  const handleSync = useCallback(async () => {
    if (!dataSource) return; // Skip for offline mode

    // For month-supported queries, require monthRange
    if (hasMonthSupport && (!monthRange || !Array.isArray(monthRange) || monthRange.length !== 2)) {
      return; // Don't execute if month range is required but not set
    }

    // Check IndexedDB first, then API if needed (same logic as initial load)
    if (currentQueryDoc) {
      await checkIndexedDBAndLoadData(dataSource, currentQueryDoc, monthRange);
    } else {
      // Fallback to direct API call if no queryDoc available
      await runQuery(dataSource, true);
    }
  }, [dataSource, hasMonthSupport, monthRange, currentQueryDoc, checkIndexedDBAndLoadData, runQuery]);

  // Pipeline output + in-memory cell edits (buffer is not fed back into tableData).
  const sortedDataWithEdits = useMemo(
    () => applyEditingBufferToRows(sortedData, mainTableEditingData),
    [sortedData, mainTableEditingData],
  );

  const paginatedDataWithEdits = useMemo(() => {
    if (!isArray(sortedDataWithEdits) || isEmpty(sortedDataWithEdits)) return [];
    const first = tablePagination?.first ?? 0;
    const rowsPerPage = tablePagination?.rows ?? 10;
    return sortedDataWithEdits.slice(first, first + rowsPerPage);
  }, [sortedDataWithEdits, tablePagination]);

  const dataForColumnInference = useMemo(() => {
    if (isArray(sortedDataWithEdits) && !isEmpty(sortedDataWithEdits)) return sortedDataWithEdits;
    if (isArray(tableData) && !isEmpty(tableData)) return tableData;
    return [];
  }, [sortedDataWithEdits, tableData]);

  // Column detection and type analysis (moved from DataTable)
  const columns = useMemo(() => {
    if (!dataForColumnInference || !Array.isArray(dataForColumnInference) || isEmpty(dataForColumnInference)) {
      return [];
    }
    // Exclude internal metadata (__nestedTables__, __groupKey__, __groupRows__, etc.) from columns
    const colSet = new Set();
    dataForColumnInference.forEach((item) => {
      if (item && typeof item === 'object') {
        getDataKeys(item).forEach((key) => {
          if (key && typeof key === 'string' && !key.startsWith('__')) colSet.add(key);
        });
      }
    });
    return [...colSet];
  }, [dataForColumnInference]);

  // Compute array fields separately (will be used to filter columns)
  const arrayFieldsForColumnFilter = useMemo(() => {
    // Check both rawTableData and tableData (which includes user edits)
    // This ensures array fields are detected even after save operations
    const dataToCheck = tableData && !isEmpty(tableData) ? tableData : rawTableData;
    if (!isEmpty(dataToCheck) && isArray(dataToCheck)) {
      const sampleData = take(dataToCheck, 10);
      const arrayFields = new Set();
      
      sampleData.forEach((row) => {
        if (!row || typeof row !== 'object') return;
        for (const [fieldName, value] of Object.entries(row)) {
          // Skip special fields
          if (fieldName.startsWith('__')) continue;
          
          // Check if value is an array of objects or JSON array string
          if (isJsonArrayOfObjectsString(value)) {
            arrayFields.add(fieldName);
          }
        }
      });
      
      return arrayFields;
    }
    return new Set();
  }, [rawTableData, tableData]);

  // Filter columns based on allowedColumns (if provided)
  // This ensures only developer-approved columns are available throughout the app
  // Also exclude array fields (they will be shown as nested tables instead)
  const filteredColumns = useMemo(() => {
    let result = columns;
    if (isEmpty(result) && computedFallbackColumns && isArray(computedFallbackColumns) && computedFallbackColumns.length > 0) {
      result = computedFallbackColumns.filter((c) => c && typeof c === 'string' && !String(c).startsWith('__'));
    }
    const allowed = getAllowedForScope(allowedColumns, 'main');
    const derived = effectiveMainConfig.derivedColumns;
    const hasArrayFilter = arrayFieldsForColumnFilter.size > 0;

    if (allowed && allowed.length > 0) {
      // Whitelist from config (e.g. stocktesting allowedColumns.main), not intersection with keys present in
      // the current row sample — avoids fewer columns when cache/editing buffer/sparse rows omit properties.
      result = allowed.filter((col) => {
        if (!col || typeof col !== 'string' || String(col).startsWith('__')) return false;
        if (hasArrayFilter && arrayFieldsForColumnFilter.has(col)) return false;
        return true;
      });
    } else {
      const allowedSet = allowed && allowed.length > 0 ? new Set(allowed) : null;
      result = result.filter((col) => {
        if (allowedSet && !allowedSet.has(col)) return false;
        if (hasArrayFilter && arrayFieldsForColumnFilter.has(col)) return false;
        return true;
      });
    }

    // Include derived columns at their specified position (position = 0-based index; omit to append at end)
    const mode = derivedColumnsMode ?? 'main';
    const fieldName = derivedColumnsFieldName ?? null;
    result = getOrderedColumnsWithDerived(result, derived || [], mode, fieldName);
    return result;
  }, [columns, computedFallbackColumns, allowedColumns, effectiveMainConfig.derivedColumns, arrayFieldsForColumnFilter, derivedColumnsMode, derivedColumnsFieldName]);

  // Stable key for filteredColumns - used by allowedFieldSet and reportDataWithDerived to avoid loops when
  // filteredColumns gets new array reference but same content (pipeline -> columns -> filteredColumns cycle)
  const filteredColumnsKey = useMemo(
    () => (Array.isArray(filteredColumns) ? filteredColumns.join(',') : ''),
    [filteredColumns]
  );

  // Column types computation (NEW FORMAT: { field_name: "boolean" | "number" | "date" | "string" })
  const columnTypes = useMemo(() => {
    const detectedTypes = {};
    if (isEmpty(dataForColumnInference)) {
      return detectedTypes;
    }

    const sampleData = take(dataForColumnInference, 50);

    filteredColumns.forEach((col) => {
      let numericCount = 0;
      let dateCount = 0;
      let booleanCount = 0;
      let binaryCount = 0;
      let nonNullCount = 0;

      sampleData.forEach((row) => {
        const value = getDataValue(row, col);
        if (!isNil(value)) {
          nonNullCount++;
          if (isBoolean(value)) {
            booleanCount++;
          } else if (value === 0 || value === 1 || value === '0' || value === '1') {
            binaryCount++;
          } else if (isDateLike(value)) {
            dateCount++;
          } else if (isNumericValue(value)) {
            numericCount++;
          }
        }
      });

      const isTrueBooleanColumn = nonNullCount > 0 && booleanCount > nonNullCount * 0.7;
      const isBinaryBooleanColumn = nonNullCount > 0 && binaryCount === nonNullCount && binaryCount >= 1;
      const isBooleanColumn = isTrueBooleanColumn || isBinaryBooleanColumn;

      let dateCountWithBinary = dateCount;
      if (!isBooleanColumn && binaryCount > 0) {
        sampleData.forEach((row) => {
          const value = getDataValue(row, col);
          if (!isNil(value) && (value === 0 || value === 1 || value === '0' || value === '1')) {
            if (isDateLike(value)) {
              dateCountWithBinary++;
            }
          }
        });
      }
      const isDateColumn = !isBooleanColumn && nonNullCount > 0 && dateCountWithBinary > nonNullCount * 0.7;

      let numericCountWithBinary = numericCount;
      if (!isBooleanColumn && !isDateColumn && binaryCount > 0) {
        numericCountWithBinary += binaryCount;
      }
      const isNumericColumn = !isBooleanColumn && !isDateColumn && nonNullCount > 0 && numericCountWithBinary > nonNullCount * 0.8;

      let detectedTypeString = "string";
      if (isBooleanColumn) {
        detectedTypeString = "boolean";
      } else if (isDateColumn) {
        detectedTypeString = "date";
      } else if (isNumericColumn) {
        detectedTypeString = "number";
      }

      detectedTypes[col] = detectedTypeString;
    });

    // Merge detected types with overrides and derived column types (overrides take precedence)
    const mainOverrides = getMainOverrides(mainColumnTypesOverride); // shared
    const mergedTypes = { ...detectedTypes, ...mainOverrides };
    (effectiveMainConfig.derivedColumns || []).forEach((dc) => {
      if (dc.columnName && dc.columnType) {
        mergedTypes[dc.columnName] = dc.columnType;
      }
    });
    return mergedTypes;
  }, [dataForColumnInference, filteredColumns, isNumericValue, mainColumnTypesOverride, effectiveMainConfig.derivedColumns]);

  // JSON table columns (columns that have __nestedTables__) - for scalar editable columns filter
  const jsonTableColumns = useMemo(() => {
    if (!tableData || !isArray(tableData) || tableData.length === 0) return {};
    const jsonTableMap = {};
    const sampleForStructure = take(tableData, 100);
    const rowsWithNestedTables = sampleForStructure.filter(row => row && row.__nestedTables__ && isArray(row.__nestedTables__) && row.__nestedTables__.length > 0);
    rowsWithNestedTables.forEach(row => {
      if (row && row.__nestedTables__ && isArray(row.__nestedTables__)) {
        row.__nestedTables__.forEach(nestedTable => {
          const columnName = nestedTable.fieldName;
          if (columnName && !columnName.startsWith('__')) {
            if (!jsonTableMap[columnName]) jsonTableMap[columnName] = { fieldName: columnName, nestedTables: [] };
            let nestedColumns = [];
            if (nestedTable.data && isArray(nestedTable.data) && nestedTable.data.length > 0 && nestedTable.data[0] && typeof nestedTable.data[0] === 'object') {
              nestedColumns = Object.keys(nestedTable.data[0]).filter(key => !key.startsWith('__'));
            }
            const existing = jsonTableMap[columnName].nestedTables.find(nt => nt.fieldName === nestedTable.fieldName);
            if (!existing) {
              jsonTableMap[columnName].nestedTables.push({ fieldName: nestedTable.fieldName, title: nestedTable.title || nestedTable.fieldName, columns: nestedColumns });
            } else if (existing.columns.length === 0 && nestedColumns.length > 0) {
              existing.columns = nestedColumns;
            }
          }
        });
      }
    });
    if (rowsWithNestedTables.length === 0 && columns.length > 0) {
      sampleForStructure.forEach(row => {
        if (!row || typeof row !== 'object') return;
        columns.forEach(columnName => {
          if (columnName.startsWith('__')) return;
          const columnValue = row[columnName];
          if (isArray(columnValue) && columnValue.length > 0) {
            const firstItem = columnValue[0];
            if (firstItem && typeof firstItem === 'object' && !isArray(firstItem)) {
              if (!jsonTableMap[columnName]) jsonTableMap[columnName] = { fieldName: columnName, nestedTables: [] };
              const cols = Object.keys(firstItem).filter(key => !key.startsWith('__'));
              const existing = jsonTableMap[columnName].nestedTables.find(nt => nt.fieldName === columnName);
              if (!existing) {
                jsonTableMap[columnName].nestedTables.push({
                  fieldName: columnName,
                  title: columnName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
                  columns: cols
                });
              } else if (existing.columns.length === 0 && cols.length > 0) {
                existing.columns = cols;
              }
            }
          }
        });
      });
    }
    return jsonTableMap;
  }, [tableData, columns]);

  const editableMain = useMemo(() => Array.isArray(editableColumns) ? editableColumns : (editableColumns?.main || []), [editableColumns]);
  const jsonObjectColumns = useMemo(() => {
    if (!tableData || !isArray(tableData) || tableData.length === 0) return {};
    const objectMap = {};
    const sampleForStructure = take(tableData, 100);
    const objectFieldSet = jsonObjectFields instanceof Set ? jsonObjectFields : new Set();
    const objectFieldCandidates = objectFieldSet.size > 0
      ? Array.from(objectFieldSet)
      : columns.filter((c) => !String(c).startsWith('__'));

    objectFieldCandidates.forEach((columnName) => {
      const keys = new Set();
      const keyTypes = {};
      sampleForStructure.forEach((row) => {
        if (!row || typeof row !== 'object') return;
        const rawValue = row[columnName];
        if (isJsonArrayOfObjectsString(rawValue)) return;
        const parsed = parseJsonObject(rawValue);
        if (parsed && typeof parsed === 'object') {
          Object.entries(parsed)
            .filter(([k]) => !k.startsWith('__'))
            .forEach(([k, v]) => {
              keys.add(k);
              if (isNil(v) || keyTypes[k]) return;
              if (isBoolean(v)) keyTypes[k] = 'boolean';
              else if (isDateLike(v)) keyTypes[k] = 'date';
              else if (isNumericValue(v)) keyTypes[k] = 'number';
              else keyTypes[k] = 'string';
            });
        }
      });
      if (keys.size > 0) {
        objectMap[columnName] = {
          fieldName: columnName,
          keys: Array.from(keys),
          keyTypes,
        };
      }
    });

    return objectMap;
  }, [tableData, columns, jsonObjectFields]);
  const objectEditableMap = useMemo(() => {
    if (editableColumns && typeof editableColumns === 'object' && editableColumns.object && typeof editableColumns.object === 'object') {
      return editableColumns.object;
    }
    return {};
  }, [editableColumns]);
  const formatObjectFieldLabel = useCallback((value) => {
    return startCase(String(value ?? '').split('__').join(' ').split('_').join(' '));
  }, []);
  const objectEditableFields = useMemo(() => {
    const rows = [];
    Object.entries(objectEditableMap).forEach(([columnName, selectedKeys]) => {
      if (!includes(editableMain, columnName)) return;
      if (!Array.isArray(selectedKeys) || selectedKeys.length === 0) return;
      const jsonInfo = jsonObjectColumns[columnName];
      selectedKeys.forEach((key) => {
        if (!key || key.startsWith('__')) return;
        // Trust writeForm-declared subkeys: sampling may omit keys (empty table or API shape mismatch).
        rows.push({
          columnName,
          key,
          formKey: `__obj__::${columnName}::${key}`,
          label: `${formatObjectFieldLabel(columnName)} - ${formatObjectFieldLabel(key)}`,
          resolvedType: jsonInfo?.keyTypes?.[key] || 'string',
        });
      });
    });
    return rows;
  }, [objectEditableMap, editableMain, jsonObjectColumns, formatObjectFieldLabel]);
  const scalarEditableColumns = useMemo(
    () => editableMain.filter(col => !jsonTableColumns[col] && !jsonObjectColumns[col]),
    [editableMain, jsonTableColumns, jsonObjectColumns]
  );
  const scalarReadOnlyDisplayColumns = useMemo(() => {
    const rawMain = readOnlyDisplayColumns?.main;
    if (!Array.isArray(rawMain) || rawMain.length === 0) return [];
    const editableSet = new Set(editableMain);
    return rawMain.filter(
      (col) => !jsonTableColumns[col] && !jsonObjectColumns[col] && !editableSet.has(col),
    );
  }, [readOnlyDisplayColumns, editableMain, jsonTableColumns, jsonObjectColumns]);
  const objectReadOnlyDisplayFields = useMemo(() => {
    const rows = [];
    const roMap =
      readOnlyDisplayColumns &&
      typeof readOnlyDisplayColumns === 'object' &&
      readOnlyDisplayColumns.object &&
      typeof readOnlyDisplayColumns.object === 'object'
        ? readOnlyDisplayColumns.object
        : {};
    Object.entries(roMap).forEach(([columnName, selectedKeys]) => {
      if (!Array.isArray(selectedKeys) || selectedKeys.length === 0) return;
      const jsonInfo = jsonObjectColumns[columnName];
      const editableKeys = new Set(objectEditableMap[columnName] || []);
      selectedKeys.forEach((key) => {
        if (!key || key.startsWith('__')) return;
        if (editableKeys.has(key)) return;
        rows.push({
          columnName,
          key,
          formKey: `__obj_ro__::${columnName}::${key}`,
          label: `${formatObjectFieldLabel(columnName)} - ${formatObjectFieldLabel(key)}`,
          resolvedType: jsonInfo?.keyTypes?.[key] || 'string',
        });
      });
    });
    return rows;
  }, [readOnlyDisplayColumns, objectEditableMap, jsonObjectColumns, formatObjectFieldLabel]);
  const hasDrawerFormFields =
    scalarEditableColumns.length > 0 ||
    objectEditableFields.length > 0 ||
    scalarReadOnlyDisplayColumns.length > 0 ||
    objectReadOnlyDisplayFields.length > 0;

  const hasNestedEditableSchema = useMemo(() => {
    const nest = editableColumns?.nested;
    if (!nest || typeof nest !== 'object') return false;
    return Object.values(nest).some((arr) => Array.isArray(arr) && arr.length > 0);
  }, [editableColumns]);

  // jsonArrayFields comes from useDataPipeline

  // Multiselect columns computation
  const multiselectColumns = useMemo(() => {
    if (!effectiveMainConfig.enableFilter) return [];
    // Get all string columns (non-numeric, non-boolean, non-date)
    const stringColumns = filteredColumns.filter(col => {
      const colType = columnTypes[col] || 'string';
      return colType === 'string';
    });
    // Remove textFilterColumns from string columns to get multiselect columns
    const textFilterSet = new Set(effectiveMainConfig.textFilterColumns);
    return stringColumns.filter(col => !textFilterSet.has(col));
  }, [filteredColumns, columnTypes, effectiveMainConfig.textFilterColumns, effectiveMainConfig.enableFilter]);

  // Percentage column helpers
  const hasPercentageColumns = useMemo(() => {
    const pct = effectiveMainConfig.percentageColumns;
    if (isEmpty(pct) || !isArray(pct)) {
      return false;
    }
    return pct.some(pc => pc.columnName && pc.columnName.trim() !== '');
  }, [effectiveMainConfig.percentageColumns]);

  const percentageColumnNames = useMemo(() => {
    const pct = effectiveMainConfig.percentageColumns;
    return hasPercentageColumns ? (pct || []).map(pc => pc.columnName).filter(Boolean) : [];
  }, [hasPercentageColumns, effectiveMainConfig.percentageColumns]);

  // Stable key for percentageColumnNames - used by allowedFieldSet to avoid report-mode loop
  const percentageColumnNamesKey = useMemo(
    () => (Array.isArray(percentageColumnNames) ? percentageColumnNames.join(',') : ''),
    [percentageColumnNames]
  );

  const isPercentageColumn = useCallback((columnName) => {
    const pct = effectiveMainConfig.percentageColumns;
    return hasPercentageColumns && pct && pct.some(pc => pc.columnName === columnName);
  }, [hasPercentageColumns, effectiveMainConfig.percentageColumns]);

  const getPercentageColumnValue = useCallback((rowData, columnName) => {
    const pct = effectiveMainConfig.percentageColumns;
    const config = pct && pct.find(pc => pc.columnName === columnName);
    if (!config || !config.targetField || !config.valueField) return null;
    const targetValue = getDataValue(rowData, config.targetField);
    const actualValue = getDataValue(rowData, config.valueField);
    const targetNum = isNumber(targetValue) ? targetValue : (isNil(targetValue) ? null : toNumber(targetValue));
    const actualNum = isNumber(actualValue) ? actualValue : (isNil(actualValue) ? null : toNumber(actualValue));
    if (!isNil(targetNum) && !isNil(actualNum) && !_isNaN(targetNum) && !_isNaN(actualNum) && _isFinite(targetNum) && _isFinite(actualNum) && targetNum !== 0) {
      return (actualNum / targetNum) * 100;
    }
    return null;
  }, [effectiveMainConfig.percentageColumns]);

  const getPercentageColumnSortFunction = useCallback((col) => {
    return (rowData1, rowData2) => {
      const val1 = getPercentageColumnValue(rowData1, col);
      const val2 = getPercentageColumnValue(rowData2, col);
      if (isNil(val1) && isNil(val2)) return 0;
      if (isNil(val1)) return 1;
      if (isNil(val2)) return -1;
      const num1 = isNumber(val1) ? val1 : toNumber(val1);
      const num2 = isNumber(val2) ? val2 : toNumber(val2);
      if (_isNaN(num1) && _isNaN(num2)) return 0;
      if (_isNaN(num1)) return 1;
      if (_isNaN(num2)) return -1;
      return num1 - num2;
    };
  }, [getPercentageColumnValue]);

  // Filter options computation
  const optionColumnValues = useMemo(() => {
    if (!effectiveMainConfig.enableFilter || isEmpty(tableData)) return {};
    const values = {};
    filteredColumns.forEach((col) => {
      const filteredForColumn = filter(tableData, (row) => {
        if (!row || typeof row !== 'object') return false;
        return every(filteredColumns, (otherCol) => {
          if (otherCol === col) return true;
          const filterObj = get(tableFilters, otherCol);
          if (!filterObj || isNil(filterObj.value) || filterObj.value === '') return true;
          if (isArray(filterObj.value) && isEmpty(filterObj.value)) return true;
          const cellValue = getDataValue(row, otherCol);
          const filterValue = filterObj.value;
          const colType = columnTypes[otherCol] || 'string';
          const isMultiselectColumn = includes(multiselectColumns, otherCol);
          if (isMultiselectColumn && isArray(filterValue)) {
            return some(filterValue, (v) => {
              if (isNil(v) && isNil(cellValue)) return true;
              if (isNil(v) || isNil(cellValue)) return false;
              return v === cellValue || String(v) === String(cellValue);
            });
          }
          if (colType === 'boolean') {
            const cellIsTruthy = cellValue === true || cellValue === 1 || cellValue === '1';
            const cellIsFalsy = cellValue === false || cellValue === 0 || cellValue === '0';
            if (filterValue === true) {
              return cellIsTruthy;
            } else if (filterValue === false) {
              return cellIsFalsy;
            }
            return true;
          }
          if (colType === 'date') {
            return applyDateFilter(cellValue, filterValue);
          }
          if (colType === 'number') {
            const parsedFilter = parseNumericFilter(filterValue);
            return applyNumericFilter(cellValue, parsedFilter);
          }
          const strCell = toLower(String(cellValue ?? ''));
          const strFilter = toLower(String(filterValue));
          return includes(strCell, strFilter);
        });
      });
      const uniqueVals = [...new Set(filteredForColumn.map((row) => getDataValue(row, col)))];
      const hasNull = some(uniqueVals, val => isNil(val));
      const nonNullVals = filter(uniqueVals, val => !isNil(val));
      const sortedNonNull = orderBy(nonNullVals).slice(0, 500);
      const options = [];
      if (hasNull) {
        options.push({ label: '(null)', value: null });
      }
      sortedNonNull.forEach((val) => {
        options.push({ label: String(val), value: val });
      });
      values[col] = options;
    });
    return values;
  }, [tableData, tableFilters, filteredColumns, columnTypes, multiselectColumns, effectiveMainConfig.enableFilter]);

  // filteredData comes from useDataPipeline

  // Report data computation state (using Web Worker)
  const reportWorkerRef = useRef(null);
  const reportWorkerInstanceRef = useRef(null); // Store actual worker instance for cleanup

  // Sync forced breakdown state if provided
  useEffect(() => {
    if (forceBreakdown === null || forceBreakdown === undefined) {
      return;
    }
    setEnableBreakdown(forceBreakdown);
  }, [forceBreakdown]);

  // Turn off enableBreakdown when enableReport is turned off (unless forced)
  useEffect(() => {
    if (!enableReport && (forceBreakdown === null || forceBreakdown === undefined)) {
      setEnableBreakdown(false);
    }
  }, [enableReport, forceBreakdown]);

  // Initialize filter/sort worker
  useEffect(() => {
    if (typeof window === 'undefined' || typeof Worker === 'undefined') {
      return;
    }

    const initializeFilterSortWorker = async () => {
      try {
        const worker = new Worker(new URL('../workers/filterSortWorker.js', import.meta.url), { type: 'module' });
        filterSortWorkerInstanceRef.current = worker;
        filterSortWorkerRef.current = Comlink.wrap(worker);
      } catch (error) {
        console.error('Failed to initialize filter/sort worker:', error);
        filterSortWorkerRef.current = null;
        filterSortWorkerInstanceRef.current = null;
      }
    };

    initializeFilterSortWorker();

    return () => {
      if (filterSortWorkerInstanceRef.current) {
        try {
          filterSortWorkerInstanceRef.current.terminate();
        } catch (error) {
          // Ignore cleanup errors
        }
        filterSortWorkerInstanceRef.current = null;
      }
      filterSortWorkerRef.current = null;
    };
  }, []);

  // Initialize report worker
  useEffect(() => {
    if (typeof window === 'undefined' || typeof Worker === 'undefined') {
      return;
    }

    const initializeWorker = async () => {
      try {
        const worker = new Worker(new URL('../workers/reportWorker.js', import.meta.url), { type: 'module' });
        reportWorkerInstanceRef.current = worker; // Store for cleanup
        reportWorkerRef.current = Comlink.wrap(worker);
      } catch (error) {
        console.error('Failed to initialize report worker:', error);
        reportWorkerRef.current = null;
        reportWorkerInstanceRef.current = null;
      }
    };

    initializeWorker();

    return () => {
      // Cleanup worker on unmount
      if (reportWorkerInstanceRef.current) {
        try {
          reportWorkerInstanceRef.current.terminate();
        } catch (error) {
          // Ignore cleanup errors
        }
        reportWorkerInstanceRef.current = null;
      }
      reportWorkerRef.current = null;
    };
  }, []);

  // sortFieldType and effectiveGroupFields come from useDataPipeline

  // Effective exempt columns: prop + derived columns with exemptFromBreakdown (must be before allowedFieldSet/alwaysAllowedKeys)
  const effectiveColumnsExemptFromBreakdown = useMemo(() => {
    const fromProp = Array.isArray(columnsExemptFromBreakdown) ? columnsExemptFromBreakdown : [];
    const fromDerived = getExemptFromBreakdownColumnNames(effectiveMainConfig.derivedColumns || []);
    return [...fromProp, ...fromDerived];
  }, [columnsExemptFromBreakdown, effectiveMainConfig.derivedColumns]);

  const allowedFieldSet = useMemo(() => {
    const allowed = getAllowedForScope(allowedColumns, 'report') ?? getAllowedForScope(allowedColumns, 'main');
    const dateCol = dateColumn; // shared
    if (!allowed || allowed.length === 0) {
      return null;
    }

    const set = new Set();

    allowed.forEach((col) => {
      if (col) {
        set.add(col);
      }
    });

    filteredColumns.forEach((col) => {
      if (col) {
        set.add(col);
      }
    });

    effectiveGroupFields.forEach((field) => {
      if (field) {
        set.add(field);
      }
    });

    if (dateCol) {
      set.add(dateCol);
    }

    percentageColumnNames.forEach((col) => {
      if (col) {
        set.add(col);
      }
    });

    effectiveColumnsExemptFromBreakdown.forEach((col) => {
      if (col) set.add(col);
    });

    return set;
  }, [allowedColumns, dateColumn, filteredColumnsKey, effectiveGroupFields, percentageColumnNamesKey, effectiveColumnsExemptFromBreakdown]);

  // Report needs flat leaf rows with date values. When filteredData has group structure (__groupRows__),
  // getDataValue(groupRow, dateColumn) returns wrong values. Flatten to leaf rows before report.
  // Full row data is passed (no stripping) so report can aggregate all metrics; allowedFieldSet filters displayed metrics only.
  const reportInputData = useMemo(() => {
    let dataForReport = filteredData;
    if (dataForReport && isArray(dataForReport) && !isEmpty(dataForReport)) {
      const first = dataForReport[0];
      if (first?.__isGroupRow__ && isArray(first?.__groupRows__)) {
        dataForReport = flattenToLeafRows(dataForReport);
      }
    }
    return dataForReport ?? [];
  }, [filteredData]);

  const drawerReportInputData = useMemo(() => drawerData ?? [], [drawerData]);

  // Main table report data computation using shared hook
  const { reportData: rawReportData, isComputingReport: internalIsComputingReport } = useReportData(
    enableBreakdown,
    reportInputData,
    effectiveGroupFields,
    dateColumn,
    breakdownType,
    columnTypes,
    sortConfig,
    sortFieldType,
    reportWorkerRef,
    effectiveColumnsExemptFromBreakdown
  );

  // Drawer report data computation using shared hook
  // Get active tab's group fields for drawer report computation
  // Use drawerTabsOverride from tableOptions when opened from a slot (multi-slot), else main config
  // When drawerTabsOverride is explicitly provided (including []), use it so scalar-only can show no tabs
  const effectiveDrawerTabs = (drawerTableOptions?.drawerTabsOverride !== undefined && Array.isArray(drawerTableOptions.drawerTabsOverride))
    ? drawerTableOptions.drawerTabsOverride
    : (effectiveMainConfig.drawerTabs || []);
  const activeDrawerTab = effectiveDrawerTabs.length > 0
    ? effectiveDrawerTabs[Math.min(activeDrawerTabIndex, Math.max(0, effectiveDrawerTabs.length - 1))]
    : null;
  // Convert drawer tab to groupFields: if groupFields is set use it, else derive from [outerGroup, innerGroup]
  const drawerGroupFields = useMemo(() => {
    if (!activeDrawerTab) return [];
    if (activeDrawerTab.groupFields && Array.isArray(activeDrawerTab.groupFields)) {
      return activeDrawerTab.groupFields;
    }
    const derived = [];
    if (activeDrawerTab.outerGroup) derived.push(activeDrawerTab.outerGroup);
    if (activeDrawerTab.innerGroup) derived.push(activeDrawerTab.innerGroup);
    return derived;
  }, [activeDrawerTab]);

  const effectiveDrawerAllowedColumns = drawerTableOptions?.allowedColumnsOverride ?? allowedColumns;
  const drawerAllowedFieldSet = useMemo(() => {
    const allowed = getAllowedForScope(effectiveDrawerAllowedColumns, 'report') ?? getAllowedForScope(effectiveDrawerAllowedColumns, 'main');
    const dateCol = dateColumn;
    if (!allowed || allowed.length === 0) {
      return null;
    }
    const set = new Set();
    allowed.forEach((col) => { if (col) set.add(col); });
    filteredColumns.forEach((col) => { if (col) set.add(col); });
    drawerGroupFields.forEach((field) => { if (field) set.add(field); });
    if (dateCol) set.add(dateCol);
    percentageColumnNames.forEach((col) => { if (col) set.add(col); });
    effectiveColumnsExemptFromBreakdown.forEach((col) => { if (col) set.add(col); });
    return set;
  }, [drawerTableOptions, allowedColumns, dateColumn, filteredColumnsKey, drawerGroupFields, percentageColumnNamesKey, effectiveColumnsExemptFromBreakdown]);

  const { reportData: rawDrawerReportData } = useReportData(
    enableBreakdown,
    drawerReportInputData,
    drawerGroupFields,
    dateColumn,
    breakdownType,
    columnTypes,
    sortConfig,
    sortFieldType,
    reportWorkerRef,
    effectiveColumnsExemptFromBreakdown
  );

  const baseReportData = reportDataOverride || rawReportData;

  const reportData = useMemo(() => {
    if (!baseReportData || !allowedFieldSet) {
      return baseReportData;
    }

    if (!Array.isArray(baseReportData.metrics)) {
      return baseReportData;
    }

    const filteredMetrics = baseReportData.metrics.filter(metric => allowedFieldSet.has(metric));

    if (filteredMetrics.length === baseReportData.metrics.length) {
      return baseReportData;
    }

    return {
      ...baseReportData,
      metrics: filteredMetrics
    };
  }, [baseReportData, allowedFieldSet]);

  const reportDataWithDerived = useMemo(() => {
    const derived = effectiveMainConfig.derivedColumns;
    const base = reportData;
    if (!base) return base;

    // Preserve original column order for report mode: exempt columns and breakdown metrics
    // in the order they appear in filteredColumns (which uses getOrderedColumnsWithDerived)
    const exemptSet = new Set(effectiveColumnsExemptFromBreakdown);
    const metricsSet = base.metrics && Array.isArray(base.metrics) ? new Set(base.metrics) : new Set();
    const baseNonGroupColumns = filteredColumns.filter(
      (col) =>
        !effectiveGroupFields.includes(col) &&
        col !== dateColumn &&
        (exemptSet.has(col) || metricsSet.has(col))
    );
    // Include report-enabled derived columns (scope.main: false, scope.report.enabled: true)
    // that are not in filteredColumns, since filteredColumns uses mode 'main'
    const orderedNonGroupColumns = getOrderedColumnsWithDerived(
      baseNonGroupColumns,
      derived || [],
      'report',
      null
    );

    let result = { ...base, orderedNonGroupColumns };
    if (!derived?.length) return result;

    const reportMeta = {
      metrics: base.metrics,
      timePeriods: base.timePeriods,
      dateRange: base.dateRange,
      breakdownType,
      columnGroupBy,
    };
    const reportCtx = { mode: 'report', getDataValue, reportMeta, query: queryFunction };
    const tableDataDerived = base.tableData
      ? applyDerivedColumns(base.tableData, derived, reportCtx)
      : base.tableData;
    const nestedTableDataDerived = base.nestedTableData
      ? Object.fromEntries(
          Object.entries(base.nestedTableData).map(([k, v]) => [
            k,
            applyDerivedColumns(v, derived, reportCtx),
          ])
        )
      : base.nestedTableData;
    return {
      ...result,
      tableData: tableDataDerived,
      nestedTableData: nestedTableDataDerived,
    };
  }, [reportData, effectiveMainConfig.derivedColumns, filteredColumnsKey, effectiveGroupFields, dateColumn, effectiveColumnsExemptFromBreakdown, breakdownType, columnGroupBy, queryFunction]);

  // Per-slot report data when multi-slot + report mode (uses each slot's allowedColumns and filteredData)
  const reportDataBySlot = useMemo(() => {
    if (!isMultiSlot || !enableBreakdown || !pipelinesBySlot || Object.keys(pipelinesBySlot).length === 0) {
      return null;
    }
    const result = {};
    for (const slotId of slotIds) {
      const pSlot = pipelinesBySlot[slotId];
      if (!pSlot) continue;
      const slotConfig = slots[slotId] ?? {};
      const effectiveSlotConfig = { ...effectiveMainConfig, ...slotConfig };
      const slotFilteredData = pSlot.filteredData ?? [];
      let dataForReport = slotFilteredData;
      if (dataForReport && isArray(dataForReport) && !isEmpty(dataForReport)) {
        const first = dataForReport[0];
        if (first?.__isGroupRow__ && isArray(first?.__groupRows__)) {
          dataForReport = flattenToLeafRows(dataForReport);
        }
      }
      const slotGroupFields = pSlot.effectiveGroupFields ?? (effectiveSlotConfig.groupFields ?? []);
      const slotAllowedColumns = effectiveSlotConfig.allowedColumns ?? allowedColumns;
      const slotAllowed = getAllowedForScope(slotAllowedColumns, 'report') ?? getAllowedForScope(slotAllowedColumns, 'main');
      const slotFilteredColumns = pSlot.pipelineColumnMeta?.filteredColumns ?? [];
      const slotPercentageNames = pSlot.pipelineColumnMeta?.percentageColumnNames ?? [];
      const allowedFieldSetForSlot = new Set();
      if (slotAllowed?.length) slotAllowed.forEach((c) => c && allowedFieldSetForSlot.add(c));
      slotFilteredColumns.forEach((c) => c && allowedFieldSetForSlot.add(c));
      slotGroupFields.forEach((f) => f && allowedFieldSetForSlot.add(f));
      if (dateColumn) allowedFieldSetForSlot.add(dateColumn);
      slotPercentageNames.forEach((c) => c && allowedFieldSetForSlot.add(c));
      effectiveColumnsExemptFromBreakdown.forEach((c) => c && allowedFieldSetForSlot.add(c));
      const rawSlotReport = transformToReportData(
        dataForReport,
        slotGroupFields,
        dateColumn,
        breakdownType,
        columnTypes,
        sortConfig,
        sortFieldType,
        effectiveColumnsExemptFromBreakdown
      );
      const filteredMetrics = rawSlotReport?.metrics && Array.isArray(rawSlotReport.metrics)
        ? rawSlotReport.metrics.filter((m) => allowedFieldSetForSlot.has(m))
        : rawSlotReport?.metrics ?? [];
      let baseReport = rawSlotReport
        ? { ...rawSlotReport, metrics: filteredMetrics }
        : rawSlotReport;
      if (!baseReport) {
        result[slotId] = null;
        continue;
      }
      const derived = effectiveSlotConfig.derivedColumns;
      const exemptSet = new Set(effectiveColumnsExemptFromBreakdown);
      const metricsSet = new Set(baseReport.metrics ?? []);
      const baseNonGroupColumns = slotFilteredColumns.filter(
        (col) =>
          !slotGroupFields.includes(col) &&
          col !== dateColumn &&
          (exemptSet.has(col) || metricsSet.has(col))
      );
      const orderedNonGroupColumns = getOrderedColumnsWithDerived(
        baseNonGroupColumns,
        derived || [],
        'report',
        null
      );
      let finalReport = { ...baseReport, orderedNonGroupColumns };
      if (derived?.length) {
        const reportMeta = {
          metrics: baseReport.metrics,
          timePeriods: baseReport.timePeriods,
          dateRange: baseReport.dateRange,
          breakdownType,
          columnGroupBy,
        };
        const reportCtx = { mode: 'report', getDataValue, reportMeta, query: queryFunction };
        finalReport = {
          ...finalReport,
          tableData: baseReport.tableData
            ? applyDerivedColumns(baseReport.tableData, derived, reportCtx)
            : baseReport.tableData,
          nestedTableData: baseReport.nestedTableData
            ? Object.fromEntries(
                Object.entries(baseReport.nestedTableData).map(([k, v]) => [
                  k,
                  applyDerivedColumns(v, derived, reportCtx),
                ])
              )
            : baseReport.nestedTableData,
        };
      }
      result[slotId] = finalReport;
    }
    return Object.keys(result).length > 0 ? result : null;
  }, [
    isMultiSlot,
    enableBreakdown,
    pipelinesBySlot,
    slotIds,
    slots,
    effectiveMainConfig,
    allowedColumns,
    dateColumn,
    breakdownType,
    columnTypes,
    sortConfig,
    sortFieldType,
    effectiveColumnsExemptFromBreakdown,
    columnGroupBy,
  ]);

  useEffect(() => {
    const dataToSet = isMultiSlot && reportDataBySlot && slotIds.length > 0
      ? reportDataBySlot[slotIds[0]] ?? reportDataWithDerived
      : reportDataWithDerived;
    reportDataRef.current = dataToSet;
    setReportDataForPipeline(dataToSet);
  }, [reportDataWithDerived, isMultiSlot, reportDataBySlot, slotIds]);

  const isComputingReport = reportDataOverride ? false : (isMultiSlot && reportDataBySlot ? false : internalIsComputingReport);

  const drawerReportData = useMemo(() => {
    if (!rawDrawerReportData || !drawerAllowedFieldSet) {
      return rawDrawerReportData;
    }

    if (!Array.isArray(rawDrawerReportData.metrics)) {
      return rawDrawerReportData;
    }

    const filteredMetrics = rawDrawerReportData.metrics.filter(metric => drawerAllowedFieldSet.has(metric));

    if (filteredMetrics.length === rawDrawerReportData.metrics.length) {
      return rawDrawerReportData;
    }

    return {
      ...rawDrawerReportData,
      metrics: filteredMetrics
    };
  }, [rawDrawerReportData, drawerAllowedFieldSet]);

  const drawerReportDataWithDerived = useMemo(() => {
    const derived = effectiveMainConfig.derivedColumns;
    const base = drawerReportData;
    if (!base) return base;

    // Preserve original column order for drawer report (same as main report)
    const exemptSet = new Set(effectiveColumnsExemptFromBreakdown);
    const metricsSet = base.metrics && Array.isArray(base.metrics) ? new Set(base.metrics) : new Set();
    const baseNonGroupColumns = filteredColumns.filter(
      (col) =>
        !drawerGroupFields.includes(col) &&
        col !== dateColumn &&
        (exemptSet.has(col) || metricsSet.has(col))
    );
    const orderedNonGroupColumns = getOrderedColumnsWithDerived(
      baseNonGroupColumns,
      derived || [],
      'report',
      null
    );

    let result = { ...base, orderedNonGroupColumns };
    if (!derived?.length) return result;

    const reportMeta = {
      metrics: base.metrics,
      timePeriods: base.timePeriods,
      dateRange: base.dateRange,
      breakdownType,
      columnGroupBy,
    };
    const reportCtx = { mode: 'report', getDataValue, reportMeta, query: queryFunction };
    const tableDataDerived = base.tableData
      ? applyDerivedColumns(base.tableData, derived, reportCtx)
      : base.tableData;
    const nestedTableDataDerived = base.nestedTableData
      ? Object.fromEntries(
          Object.entries(base.nestedTableData).map(([k, v]) => [
            k,
            applyDerivedColumns(v, derived, reportCtx),
          ])
        )
      : base.nestedTableData;
    return {
      ...result,
      tableData: tableDataDerived,
      nestedTableData: nestedTableDataDerived,
    };
  }, [drawerReportData, effectiveMainConfig.derivedColumns, filteredColumns, drawerGroupFields, dateColumn, effectiveColumnsExemptFromBreakdown, breakdownType, columnGroupBy, queryFunction]);

  const shouldShowDrawerReport = enableBreakdown && !!drawerReportDataWithDerived;

  // groupDataRecursive, extractJsonNestedTablesFromData, groupedData, filteredDataWithNestedTables, dataForSorting, sortedData, paginatedData come from useDataPipeline

  // Compute filter/sort/group using worker when applying
  useEffect(() => {
    if (!isApplyingFilterSort) {
      setWorkerComputedData(null);
      return;
    }

    // Only use worker if it's available and we have data
    if (!filterSortWorkerRef.current || !tableData || isEmpty(tableData)) {
      return;
    }

    const computationId = ++filterSortComputationIdRef.current;

    const computeWithWorker = async () => {
      try {
        if (!filterSortWorkerRef.current) {
          // Fallback to synchronous computation
          return;
        }

        // Convert preFilterValues to tableFilters format
        const filtersForWorker = {};
        Object.keys(preFilterValues || {}).forEach(col => {
          filtersForWorker[col] = { value: preFilterValues[col] };
        });

        const result = await filterSortWorkerRef.current.computeFilterSortGrouped(tableData, {
          tableFilters: filtersForWorker,
          columns,
          columnTypes,
          multiselectColumns,
          hasPercentageColumns,
          percentageColumns: effectiveMainConfig.percentageColumns,
          percentageColumnNames,
          enableFilter: effectiveMainConfig.enableFilter,
          searchTerm,
          searchFields: currentQueryDoc?.searchFields || {},
          sortConfig,
          sortFieldType,
          tableSortMeta,
          enableSort: effectiveMainConfig.enableSort,
          effectiveGroupFields,
          derivedColumnNames: getDerivedColumnNames(effectiveMainConfig.derivedColumns || [], 'main'),
          nonAggregatableColumns: getNonAggregatableColumnNames(effectiveMainConfig.derivedColumns || []),
        });

        // Apply derived columns to grouped data (including group summary rows)
        const derivedCols = effectiveMainConfig.derivedColumns;
        const groupedDataWithDerived =
          result.groupedData && derivedCols?.length
            ? applyDerivedColumns(result.groupedData, derivedCols, {
                mode: 'main',
                getDataValue,
                query: queryFunction,
              })
            : result.groupedData;

        // Only update if this is still the latest computation
        if (computationId === filterSortComputationIdRef.current) {
          setWorkerComputedData({
            ...result,
            groupedData: groupedDataWithDerived,
          });
          setIsApplyingFilterSort(false);
        }
      } catch (error) {
        console.error('Filter/sort worker computation error:', error);
        if (computationId === filterSortComputationIdRef.current) {
          setIsApplyingFilterSort(false);
        }
      }
    };

    computeWithWorker();
  }, [isApplyingFilterSort, sortConfig, preFilterValues, tableData, columns, columnTypes, multiselectColumns, hasPercentageColumns, effectiveMainConfig.percentageColumns, percentageColumnNames, effectiveMainConfig.enableFilter, searchTerm, currentQueryDoc, sortFieldType, tableSortMeta, effectiveMainConfig.enableSort, effectiveGroupFields, isPercentageColumn, effectiveMainConfig.derivedColumns]);

  // Track when filter/sort computation is complete - callback-based approach with ref guard
  const hasClearedLoadingRef = useRef(false);

  // Watch sortedData changes and clear loading when ready (fallback for non-worker path)
  useEffect(() => {
    if (isApplyingFilterSort && sortedData && !hasClearedLoadingRef.current && !workerComputedData) {
      // sortedData is ready - clear loading immediately
      hasClearedLoadingRef.current = true;

      // Use requestAnimationFrame for immediate UI update
      requestAnimationFrame(() => {
        setIsApplyingFilterSort(false);
      });
    }

    // Reset guard when not applying
    if (!isApplyingFilterSort) {
      hasClearedLoadingRef.current = false;
    }
  }, [sortedData, isApplyingFilterSort, workerComputedData]);

  // Track previous sortedData to prevent unnecessary re-initialization
  const previousSortedDataRef = useRef(null);
  const previousSortedDataHashRef = useRef(null);
  const prevPreFilteredLenRef = useRef(0);

  // After async derivedRows merge, preFiltered row count jumps — force sortedData buffer resync.
  useEffect(() => {
    const preLen = isArray(preFilteredData) ? preFilteredData.length : 0;
    const prev = prevPreFilteredLenRef.current;
    if (prev > 100 && preLen > 100 && Math.abs(preLen - prev) > Math.max(500, prev * 0.05)) {
      previousSortedDataHashRef.current = null;
      previousSortedDataRef.current = null;
    }
    prevPreFilteredLenRef.current = preLen;
  }, [preFilteredData]);
  // When we add a new row via drawer, sortedData updates from pipeline - skip re-init so original stays unchanged
  const skipNextInitFromSortedDataRef = useRef(false);
  /**
   * After sidebar re-seed, the next passive sortedData effect can still see the *previous* pipeline slice
   * (short buffer) and would overwrite the new buffer. Skip that single stale pass and advance the cursor.
   */
  const skipNextSortedDataBufferInitRef = useRef(false);

  const isNestedDrawerOfflineTable = !!(nestedTableTabId && parentNestedTableEditingDataRef);

  // Filter & Sort Apply: align main editing buffer with preFilteredData; cell edits keep using the buffer path.
  useLayoutEffect(() => {
    const prevSig = sidebarFilterSigPrevRef.current;
    const curSig = sidebarActiveFilterSig;
    const prevEmpty = !prevSig || prevSig.length === 0;
    const curEmpty = !curSig || curSig.length === 0;
    const idleNoSidebarFilters = prevEmpty && curEmpty;

    if (isNestedDrawerOfflineTable || parentColumnName) {
      sidebarFilterSigPrevRef.current = curSig;
      return;
    }
    if (idleNoSidebarFilters) {
      sidebarFilterSigPrevRef.current = curSig;
      return;
    }
    if (enableBreakdown || saveDiffDialogVisible) return;
    if (executingQuery || loadingFromCache) return;

    const pf = isArray(preFilteredDataForSidebarReseedRef.current)
      ? preFilteredDataForSidebarReseedRef.current
      : [];
    const dataWithNestedKeys = mainTableEditingRowsFromLeafData(pf, addEditingKeysToRows);

    mainTableOriginalDataRef.current = cloneDeep(dataWithNestedKeys);
    const editingData = cloneDeep(mainTableOriginalDataRef.current);
    mainTableEditingDataRef.current = editingData;
    mainTableEditingDataRefEarly.current = editingData;
    setMainTableEditingData(editingData);
    setTableDataUpdateTrigger((t) => t + 1);

    previousSortedDataHashRef.current = null;
    previousSortedDataRef.current = null;
    skipNextSortedDataBufferInitRef.current = true;
    sidebarFilterSigPrevRef.current = curSig;
  }, [
    sidebarActiveFilterSig,
    enableBreakdown,
    saveDiffDialogVisible,
    executingQuery,
    loadingFromCache,
    addEditingKeysToRows,
    isNestedDrawerOfflineTable,
    parentColumnName,
    setTableDataUpdateTrigger,
  ]);

  // When index freshness token changes, clear stale editing buffer so table uses fresh upstream data.
  const prevIndexFreshnessTokenRef = useRef(null);
  useEffect(() => {
    const prevToken = prevIndexFreshnessTokenRef.current;
    prevIndexFreshnessTokenRef.current = indexFreshnessToken;
    const hasEditingBuffer = isArray(mainTableEditingDataRef.current) && mainTableEditingDataRef.current.length > 0;
    const shouldResetForFreshData = prevToken !== null && indexFreshnessToken !== null && prevToken !== indexFreshnessToken && hasEditingBuffer;
    if (shouldResetForFreshData) {
      mainTableEditingDataRefEarly.current = [];
      mainTableEditingDataRef.current = [];
      setMainTableEditingData([]);
      setTableDataUpdateTrigger((t) => t + 1);
    }
  }, [indexFreshnessToken]);

  // Main editing buffer:
  // - Default: keep in sync with sortedData (search / sort / column filters / grouping in the pipeline).
  // - Filter & Sort sidebar: layout re-seeds from preFilteredData; the next sortedData effect often still
  //   observes the *old* pipeline slice, so skipNextSortedDataBufferInitRef skips one stale buffer overwrite.
  // - Drawer add-row: skipNextInitFromSortedDataRef skips one init (same cursor advance only).
  useEffect(() => {
    if (executingQuery || loadingFromCache) {
      return;
    }
    if (
      skipNextSortedDataBufferInitRef.current ||
      skipNextInitFromSortedDataRef.current
    ) {
      skipNextSortedDataBufferInitRef.current = false;
      skipNextInitFromSortedDataRef.current = false;
      const cursor = sortedDataInitCursor(sortedData);
      previousSortedDataRef.current = cursor.ref;
      previousSortedDataHashRef.current = sortedDataRefreshHash(
        sortedData,
        sortConfig,
        tableSortMeta,
        sidebarActiveFilterSig,
      );
      return;
    }
    if (saveDiffDialogVisible) return; // Don't re-init while save dialog is open
    if (enableBreakdown) return; // Report mode: sortedData has report structure; keep buffer with original data
    if (!isArray(sortedData)) {
      const currentEditingLength = mainTableEditingDataRef.current.length;
      const currentOriginalLength = mainTableOriginalDataRef.current.length;
      if (currentEditingLength > 0 || currentOriginalLength > 0) {
        mainTableOriginalDataRef.current = [];
        mainTableEditingDataRef.current = [];
        setMainTableEditingData([]);
        previousSortedDataRef.current = null;
        previousSortedDataHashRef.current = null;
      }
      return;
    }

    let dataHash;
    try {
      dataHash = sortedDataRefreshHash(sortedData, sortConfig, tableSortMeta, sidebarActiveFilterSig);
    } catch (e) {
      dataHash = `error_${sortedData.length}`;
    }

    const editingBufferLen = mainTableEditingDataRef.current?.length ?? 0;

    // Only re-initialize if data actually changed (different reference or different hash)
    if (previousSortedDataRef.current === sortedData) {
      // Same reference — still re-seed if the editing buffer was cleared (e.g. during cache refresh)
      if (editingBufferLen > 0 || !sortedData.length) return;
    }

    if (
      previousSortedDataHashRef.current === dataHash
      && sortedData.length === (mainTableOriginalDataRef.current.length || 0)
      && editingBufferLen > 0
      && editingBufferLen === sortedData.length
    ) {
      // Same hash and length with a populated editing buffer — likely no change
      previousSortedDataRef.current = sortedData;
      return;
    }

    const dataWithNestedKeys = mainTableEditingRowsFromLeafData(sortedData, addEditingKeysToRows);
    // Initialize original buffer
    mainTableOriginalDataRef.current = cloneDeep(dataWithNestedKeys);
    // Initialize editing buffer (deep clone from original)
    const editingData = cloneDeep(mainTableOriginalDataRef.current);
    mainTableEditingDataRef.current = editingData;
    setMainTableEditingData(editingData);
    // Force pipeline tableData memo to re-run so it picks up the ref (ref doesn't trigger memo deps)
    setTableDataUpdateTrigger((t) => t + 1);

    // Update tracking refs
    previousSortedDataRef.current = sortedData;
    previousSortedDataHashRef.current = dataHash;
  }, [
    sortedData,
    addEditingKeysToRows,
    setTableDataUpdateTrigger,
    enableBreakdown,
    executingQuery,
    loadingFromCache,
    saveDiffDialogVisible,
    sortConfig,
    tableSortMeta,
    sidebarActiveFilterSig,
  ]);

  // paginatedData comes from useDataPipeline

  // Initialize filters effect
  useEffect(() => {
    if (!effectiveMainConfig.enableFilter) {
      if (!isEmpty(tableFilters)) {
        setTableFilters({});
      }
      return;
    }
    if (isEmpty(columns)) return;
    const newFilters = { ...tableFilters };
    let changed = false;
    columns.forEach((col) => {
      const colType = columnTypes[col] || 'string';
      const isMultiselectColumn = includes(multiselectColumns, col);
      const desiredMatchMode =
        isMultiselectColumn ? 'in'
          : colType === 'boolean' ? 'equals'
            : colType === 'date' ? 'dateRange'
              : 'contains';
      if (!newFilters[col]) {
        newFilters[col] = { value: null, matchMode: desiredMatchMode };
        changed = true;
      } else if (newFilters[col].matchMode !== desiredMatchMode) {
        newFilters[col] = { ...newFilters[col], matchMode: desiredMatchMode };
        changed = true;
      }
    });
    if (hasPercentageColumns) {
      percentageColumnNames.forEach((col) => {
        if (!newFilters[col]) {
          newFilters[col] = { value: null, matchMode: 'contains' };
          changed = true;
        }
      });
    }
    if (changed) {
      setTableFilters(newFilters);
    }
  }, [columns, effectiveMainConfig.enableFilter, columnTypes, multiselectColumns, hasPercentageColumns, percentageColumnNames, tableFilters]);

  // Action handlers
  const updateFilter = useCallback((column, value) => {
    setTableFilters(prev => ({
      ...prev,
      [column]: { ...get(prev, column, {}), value }
    }));
    setTablePagination(prev => ({ ...prev, first: 0 }));
  }, []);

  const updateFilterForSlot = useCallback((slotId, column, value) => {
    setTableFiltersBySlot(prev => {
      const slotFilters = prev[slotId] ?? {};
      return { ...prev, [slotId]: { ...slotFilters, [column]: { ...get(slotFilters, column, {}), value } } };
    });
    setTablePaginationBySlot(prev => {
      const slotPag = prev[slotId] ?? { first: 0, rows: 10 };
      return { ...prev, [slotId]: { ...slotPag, first: 0 } };
    });
  }, []);

  const clearFilter = useCallback((column) => {
    updateFilter(column, null);
  }, [updateFilter]);

  const clearFilterForSlot = useCallback((slotId, column) => {
    updateFilterForSlot(slotId, column, null);
  }, [updateFilterForSlot]);

  const clearAllFiltersForSlot = useCallback((slotId) => {
    const meta = pipelinesBySlot[slotId]?.pipelineColumnMeta;
    const cols = meta?.filteredColumns ?? columns;
    const colTypes = meta?.columnTypes ?? columnTypes;
    const multiselectCols = meta?.multiselectColumns ?? multiselectColumns;
    const pctCols = meta?.percentageColumnNames ?? percentageColumnNames;
    const hasPct = meta?.hasPercentageColumns ?? hasPercentageColumns;
    const clearedFilters = {};
    cols.forEach((col) => {
      const colType = colTypes[col] || 'string';
      const isMultiselectColumn = includes(multiselectCols, col);
      if (isMultiselectColumn) {
        clearedFilters[col] = { value: null, matchMode: 'in' };
      } else if (colType === 'boolean') {
        clearedFilters[col] = { value: null, matchMode: 'equals' };
      } else if (colType === 'date') {
        clearedFilters[col] = { value: null, matchMode: 'dateRange' };
      } else {
        clearedFilters[col] = { value: null, matchMode: 'contains' };
      }
    });
    if (hasPct && pctCols?.length) {
      pctCols.forEach((col) => {
        clearedFilters[col] = { value: null, matchMode: 'contains' };
      });
    }
    setTableFiltersBySlot(prev => ({ ...prev, [slotId]: clearedFilters }));
    setTablePaginationBySlot(prev => ({ ...prev, [slotId]: { ...(prev[slotId] ?? { first: 0, rows: 10 }), first: 0 } }));
  }, [pipelinesBySlot, columns, columnTypes, multiselectColumns, hasPercentageColumns, percentageColumnNames]);

  const clearAllFilters = useCallback(() => {
    const clearedFilters = {};
    columns.forEach((col) => {
      const colType = columnTypes[col] || 'string';
      const isMultiselectColumn = includes(multiselectColumns, col);
      if (isMultiselectColumn) {
        clearedFilters[col] = { value: null, matchMode: 'in' };
      } else if (colType === 'boolean') {
        clearedFilters[col] = { value: null, matchMode: 'equals' };
      } else if (colType === 'date') {
        clearedFilters[col] = { value: null, matchMode: 'dateRange' };
      } else {
        clearedFilters[col] = { value: null, matchMode: 'contains' };
      }
    });
    if (hasPercentageColumns) {
      percentageColumnNames.forEach((col) => {
        clearedFilters[col] = { value: null, matchMode: 'contains' };
      });
    }
    setTableFilters(clearedFilters);
    setTablePagination(prev => ({ ...prev, first: 0 }));
  }, [columns, columnTypes, multiselectColumns, hasPercentageColumns, percentageColumnNames]);

  const resetInMemoryTableState = useCallback(() => {
    setProcessedData(null);
    mainTableEditingDataRefEarly.current = [];
    mainTableEditingDataRef.current = [];
    mainTableOriginalDataRef.current = [];
    setMainTableEditingData([]);
    previousSortedDataRef.current = null;
    previousSortedDataHashRef.current = null;
    setTableDataUpdateTrigger((t) => t + 1);
    clearAllFilters();
    setSearchTerm('');
    setSortConfig(null);
    if (isMultiSlot) {
      setTableFiltersBySlot({});
      setTableSortMetaBySlot({});
      setTablePaginationBySlot({});
    }
  }, [setProcessedData, clearAllFilters, setTableDataUpdateTrigger, isMultiSlot]);

  const handleHardRefresh = useCallback(async () => {
    if (!dataSource) return;

    try {
      await indexedDBService.clearAllClientCaches();
      await workerRef.current?.indexedDBService?.clearAllClientCaches?.();
      resetInMemoryTableState();
      await handleSync();
    } catch (error) {
      console.error('Error during hard refresh:', error);
    }
  }, [dataSource, resetInMemoryTableState, handleSync, workerRef]);

  const syncButtonModel = useMemo(() => [
    {
      label: 'Hard Refresh',
      icon: 'pi pi-sync',
      command: () => {
        handleHardRefresh();
      },
    },
  ], [handleHardRefresh]);

  const updateSort = useCallback((sortMeta) => {
    setTableSortMeta(sortMeta || []);
    setTablePagination(prev => ({ ...prev, first: 0 }));
  }, []);

  const updateSortForSlot = useCallback((slotId, sortMeta) => {
    setTableSortMetaBySlot(prev => ({ ...prev, [slotId]: sortMeta || [] }));
    setTablePaginationBySlot(prev => ({ ...prev, [slotId]: { ...(prev[slotId] ?? { first: 0, rows: 10 }), first: 0 } }));
  }, []);

  const updatePagination = useCallback((first, rows) => {
    setTablePagination({ first, rows });
  }, []);

  const updatePaginationForSlot = useCallback((slotId, first, rows) => {
    setTablePaginationBySlot(prev => ({ ...prev, [slotId]: { first, rows: rows ?? (prev[slotId]?.rows ?? 10) } }));
  }, []);

  const [tableExpandedRowsBySlot, setTableExpandedRowsBySlot] = useState({});
  const [tableVisibleColumnsBySlot, setTableVisibleColumnsBySlot] = useState({});

  const updateExpandedRows = useCallback((rows) => {
    setTableExpandedRows(rows);
  }, []);

  const updateExpandedRowsForSlot = useCallback((slotId, rows) => {
    setTableExpandedRowsBySlot(prev => ({ ...prev, [slotId]: rows }));
  }, []);

  const updateVisibleColumns = useCallback((columns) => {
    setTableVisibleColumns(columns);
    if (onVisibleColumnsChange) {
      onVisibleColumnsChange(columns);
    }
  }, [onVisibleColumnsChange]);

  const updateVisibleColumnsForSlot = useCallback((slotId, columns) => {
    setTableVisibleColumnsBySlot(prev => ({ ...prev, [slotId]: columns }));
  }, []);

  /**
   * Apply filters to data array
   * @param {Array} data - Data array to filter
   * @param {Object} filters - Filters in format { columnKey: [filterValues] }
   * @param {Object} options - Options for filter application
   * @returns {Array} Filtered data array
   */
  const applyFiltersToData = useCallback((data, filters, options = {}) => {
    if (!isArray(data) || isEmpty(data)) return [];
    if (!filters || isEmpty(filters)) return data;

    const internalFilters = {};
    Object.keys(filters).forEach((columnKey) => {
      const filterValues = filters[columnKey];
      if (isNil(filterValues) || filterValues === '') return;
      if (isArray(filterValues) && isEmpty(filterValues)) return;
      internalFilters[columnKey] = { value: filterValues };
    });
    if (isEmpty(internalFilters)) return data;

    const getCellValue = (row, col) => (includes(percentageColumnNames, col) ? getPercentageColumnValue(row, col) : getDataValue(row, col));
    const columnMeta = {
      columns,
      columnTypes,
      multiselectColumns,
      hasPercentageColumns,
      percentageColumnNames,
      getCellValue,
    };
    let dataToFilter = data;
    if (
      hasActiveTableFilters(internalFilters) &&
      data.length > 0 &&
      data[0]?.__isGroupRow__
    ) {
      dataToFilter = flattenToLeafRows(data);
    }
    return filterRows(dataToFilter, { filters: internalFilters, columnMeta });
  }, [columns, columnTypes, multiselectColumns, hasPercentageColumns, percentageColumnNames, getPercentageColumnValue]);

  // Variant 1: getSums(data, filters) - calculates sums on provided data with optional filters
  // Variant 2: getSums(filters) - calculates sums on current filteredData with filters applied
  // Variant 3: getSums() - calculates sums on current filteredData without additional filters
  const getSums = useCallback((dataOrFilters, filters) => {
    let dataToSum;
    let filtersToApply;

    // Detect variant: if no arguments, use current filteredData (Variant 3)
    if (dataOrFilters === undefined && filters === undefined) {
      // Variant 3: getSums()
      dataToSum = filteredData;
      filtersToApply = null;
    } else if (isArray(dataOrFilters)) {
      // Variant 1: getSums(data, filters)
      dataToSum = dataOrFilters;
      filtersToApply = filters || null;
    } else {
      // Variant 2: getSums(filters)
      dataToSum = filteredData; // Use current filteredData
      filtersToApply = dataOrFilters || null;
    }

    // Apply filters if provided
    let dataForSums = dataToSum || [];
    if (filtersToApply && !isEmpty(filtersToApply)) {
      dataForSums = applyFiltersToData(dataToSum, filtersToApply);
    }

    // Calculate sums
    const sums = {};
    if (isEmpty(dataForSums)) return sums;
    columns.forEach((col) => {
      const colType = columnTypes[col] || 'string';
      if (colType === 'date') return;
      const values = filter(
        dataForSums.map((row) => getDataValue(row, col)),
        (val) => !isNil(val)
      );
      if (!isEmpty(values) && isNumericValue(head(values))) {
        sums[col] = sumBy(values, (val) => {
          const numVal = isNumber(val) ? val : toNumber(val);
          return _isNaN(numVal) ? 0 : numVal;
        });
      }
    });

    // Run compute on total row for derived columns (totalRow = sums, each key has column sum)
    const derivedColNames = getDerivedColumnNames(derivedColumns || [], derivedColumnsMode ?? 'main', derivedColumnsFieldName ?? null);
    (derivedColumns || []).forEach((dc) => {
      if (!dc.columnName || !dc.compute || !derivedColNames.includes(dc.columnName)) return;
      try {
        const totalRow = { ...sums };
        const ctx = {
          isTotalRow: true,
          isGroupRow: false,
          getDataValue: (r, k) => (r && typeof r === 'object' ? r[k] : undefined),
          parentRow: null,
          fieldName: derivedColumnsFieldName ?? null,
          rowIndex: -1,
          position: -1,
        };
        const value = typeof dc.compute === 'function' && dc.compute.length >= 2
          ? dc.compute(totalRow, ctx)
          : typeof dc.compute === 'function'
            ? dc.compute(totalRow)
            : null;
        sums[dc.columnName] = value;
      } catch (e) {
        sums[dc.columnName] = null;
      }
    });

    return sums;
  }, [filteredData, applyFiltersToData, columns, columnTypes, isNumericValue, getDataValue, derivedColumns, derivedColumnsMode, derivedColumnsFieldName]);

  // Summation computation
  const calculateSums = useMemo(() => {
    return getSums();
  }, [getSums]);

  // Unified drawer function with two variants:
  // Variant 1: openDrawer(data, filters, title, tableOptions) - applies filters on provided data
  // Variant 2: openDrawer(filters, title, tableOptions) - applies filters on current filteredData
  // Optional title parameter can be provided to set custom drawer header title
  // Optional tableOptions parameter can be provided to override default table configuration
  const openDrawer = useCallback((dataOrFilters, filters, title, tableOptions) => {
    if (drawerCloseTimeoutRef.current) {
      clearTimeout(drawerCloseTimeoutRef.current);
      drawerCloseTimeoutRef.current = null;
    }
    if (enableWriteEffective && !resolvedWritePermissions.update) {
      // Block filter-only drill that opens editable drawer; row/new-row paths guard elsewhere
      if (!isArray(dataOrFilters)) {
        return;
      }
      if (filters && !isEmpty(filters)) {
        return;
      }
    }
    let dataToFilter;
    let filtersToApply;
    let customTitle = title;

    // Detect variant: if first arg is an array, it's variant 1 (with data)
    if (isArray(dataOrFilters)) {
      // Variant 1: openDrawer(data, filters, title, tableOptions)
      dataToFilter = dataOrFilters;
      filtersToApply = filters || null;
    } else {
      // Variant 2: openDrawer(filters, title, tableOptions)
      dataToFilter = filteredData; // Use current filteredData
      filtersToApply = dataOrFilters || null;
    }

    // Flatten grouped data to leaf rows BEFORE filtering (applyFiltersToData expects flat rows with field values)
    const firstRow = dataToFilter?.[0];
    if (firstRow?.__isGroupRow__ && isArray(firstRow?.__groupRows__)) {
      dataToFilter = flattenToLeafRows(dataToFilter);
    }

    // Apply filters if provided
    let filteredResult = dataToFilter || [];
    if (filtersToApply && !isEmpty(filtersToApply)) {
      filteredResult = applyFiltersToData(dataToFilter, filtersToApply);
    }
    // Flatten group rows to leaf rows so nested drawer can re-group (groupDataRecursive skips __isGroupRow__ rows)
    const firstBeforeFlatten = filteredResult?.[0];
    const hadGroupRows = firstBeforeFlatten?.__isGroupRow__ && isArray(firstBeforeFlatten?.__groupRows__);
    if (hadGroupRows) {
      filteredResult = flattenToLeafRows(filteredResult);
    }

    // Extract clickedDrawerValues from filters if group fields are present
    // Support all group fields, not just first two
    const clickedValues = {};
    effectiveGroupFields.forEach((field) => {
      if (filtersToApply && field && filtersToApply[field]) {
        const filterValue = filtersToApply[field];
        clickedValues[field] = isArray(filterValue) ? filterValue[0] : filterValue;
      }
    });

    // For backward compatibility, extract first two as outerValue/innerValue
    const outerValue = clickedValues[effectiveGroupFields[0]] || null;
    const innerValue = clickedValues[effectiveGroupFields[1]] || null;

    // Store filtered data
    setDrawerData(filteredResult);
    setClickedDrawerValues({ outerValue, innerValue, ...clickedValues });

    // Compute title: use custom title if provided, otherwise compute from clickedDrawerValues
    const titleParts = effectiveGroupFields.map(field => clickedValues[field]).filter(Boolean);
    const computedTitle = customTitle || (titleParts.length > 0 ? titleParts.join(' : ') : 'Drawer');
    setDrawerHeaderTitle(computedTitle);

    // Store table options if provided
    setDrawerTableOptions(tableOptions || null);

    setActiveDrawerTabIndex(0);
    setDrawerVisible(true);
  }, [filteredData, applyFiltersToData, effectiveGroupFields, enableWriteEffective, resolvedWritePermissions.update]);

  // Drawer action handlers (legacy - calls unified openDrawer internally)
  const openDrawerWithData = useCallback((data, outerValue = null, innerValue = null, title = null) => {
    // Compute title: use custom title if provided, otherwise compute from values
    const computedTitle = title || (innerValue
      ? `${outerValue} : ${innerValue}`
      : outerValue || 'Drawer');
    // Use unified API: openDrawer(data, null, computedTitle) - no filters
    openDrawer(data, null, computedTitle);
    // Set clickedDrawerValues for display purposes
    setClickedDrawerValues({ outerValue, innerValue });
  }, [openDrawer]);

  const closeDrawer = useCallback(() => {
    if (drawerCloseTimeoutRef.current) {
      clearTimeout(drawerCloseTimeoutRef.current);
      drawerCloseTimeoutRef.current = null;
    }
    setDrawerVisible(false);
    setSelectedRowData(null);
    formOriginalRowRef.current = null;
    setFormEditingRow(null);
    pendingUploadsRef.current.clear();
    // Keep selectOptionsCache - options remain cached for next drawer open
    // Clear change tracking data when drawer closes
    originalNestedTableDataRef.current.clear();
    nestedTableEditingDataRef.current.clear();
    nestedTableDataRefsRef.current.clear();
    // Defer clearing drawer content until after Sidebar hide animation completes,
    // to avoid flashing the other slot's tabs during the close transition
    drawerCloseTimeoutRef.current = setTimeout(() => {
      drawerCloseTimeoutRef.current = null;
      setDrawerHeaderTitle(null);
      setDrawerTableOptions(null);
      setDrawerJsonTables(null);
      setDrawerData([]);
    }, 350);
  }, [effectiveMainConfig.drawerTabs, onDrawerTabsChange]);

  // Wrapper so that when user selects another row in the main table (drawer open), form buffer is re-inited
  const setSelectedRowDataWithFormSync = useCallback((row) => {
    setSelectedRowData(row);
    if (drawerVisible && hasDrawerFormFields && row) {
      formOriginalRowRef.current = cloneDeep(row);
      setFormEditingRow(cloneDeep(row));
    } else if (!row) {
      formOriginalRowRef.current = null;
      setFormEditingRow(null);
    }
  }, [drawerVisible, hasDrawerFormFields]);

  const addDrawerTab = useCallback(() => {
    const newTab = {
      id: `tab-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: '',
      outerGroup: null,
      innerGroup: null
    };
    if (onDrawerTabsChange) {
      onDrawerTabsChange([...effectiveMainConfig.drawerTabs, newTab]);
    }
    setActiveDrawerTabIndex((effectiveMainConfig.drawerTabs || []).length);
  }, [effectiveMainConfig.drawerTabs, onDrawerTabsChange]);

  const removeDrawerTab = useCallback((tabId) => {
    const tabs = effectiveMainConfig.drawerTabs || [];
    if (tabs.length <= 1) return;
    const newTabs = tabs.filter(tab => tab.id !== tabId);
    if (onDrawerTabsChange) {
      onDrawerTabsChange(newTabs);
    }
    if (activeDrawerTabIndex >= newTabs.length) {
      setActiveDrawerTabIndex(newTabs.length - 1);
    }
  }, [effectiveMainConfig.drawerTabs, activeDrawerTabIndex, onDrawerTabsChange]);

  const updateDrawerTab = useCallback((tabId, updates) => {
    if (onDrawerTabsChange) {
      onDrawerTabsChange((effectiveMainConfig.drawerTabs || []).map(tab =>
        tab.id === tabId ? { ...tab, ...updates } : tab
      ));
    }
  }, [effectiveMainConfig.drawerTabs, onDrawerTabsChange]);

  // Drawer filtering functions for group cells (legacy - calls unified openDrawer internally)
  const openDrawerForOuterGroup = useCallback((value) => {
    if (effectiveGroupFields.length === 0) return;
    const firstGroupField = effectiveGroupFields[0];
    // Use unified API: openDrawer({ [firstGroupField]: [value] })
    const filters = { [firstGroupField]: [value] };
    openDrawer(filters);
  }, [effectiveGroupFields, openDrawer]);

  const openDrawerForInnerGroup = useCallback((outerValue, innerValue) => {
    if (effectiveGroupFields.length < 2) return;
    const firstGroupField = effectiveGroupFields[0];
    const secondGroupField = effectiveGroupFields[1];
    // Use unified API: openDrawer({ [firstGroupField]: [outerValue], [secondGroupField]: [innerValue] })
    const filters = {
      [firstGroupField]: [outerValue],
      [secondGroupField]: [innerValue]
    };
    openDrawer(filters);
  }, [effectiveGroupFields, openDrawer]);

  // Callback to update current nested table data for a specific tab
  const updateCurrentNestedTableData = useCallback((tabId, currentData) => {
    if (tabId && isArray(currentData)) {
      // Don't overwrite saved data: if incoming data matches the saved original, preserve the editing buffer
      // This prevents reverting user edits after save
      const trackingData = originalNestedTableDataRef.current.get(tabId);
      const existingData = nestedTableEditingDataRef.current.get(tabId);
      if (trackingData && trackingData.originalData && existingData && existingData.length > 0) {
        // Check if incoming data matches the saved original (which would revert edits)
        const incomingMatchesSavedOriginal = trackingData.originalData.length === currentData.length && 
          JSON.stringify(trackingData.originalData) === JSON.stringify(currentData);
        // Check if existing data matches the saved original (meaning it's the saved state)
        const existingMatchesSavedOriginal = existingData.length === trackingData.originalData.length &&
          JSON.stringify(existingData) === JSON.stringify(trackingData.originalData);
        if (incomingMatchesSavedOriginal && existingMatchesSavedOriginal) {
          // Both match saved original - this is fine, data is already saved
          return; // Skip update - data already matches saved state
        }
        // If incoming matches saved original but existing doesn't, preserve existing (user has new edits)
        if (incomingMatchesSavedOriginal && !existingMatchesSavedOriginal) {
          return; // Skip update to preserve user's new edits
        }
      }
      // Don't overwrite if we already have data (preserve user edits)
      // Only update if existing data is empty or if the new data is significantly different
      if (existingData && existingData.length > 0 && currentData.length === existingData.length) {
        // Check if data is actually different (not just a re-render with same data)
        const isSameData = JSON.stringify(existingData) === JSON.stringify(currentData);
        if (isSameData) {
          return; // Skip update if data hasn't changed
        }
      }
      // Ensure editing keys are preserved when updating
      const dataWithKeys = addEditingKeysToRows(cloneDeep(currentData));
      nestedTableEditingDataRef.current.set(tabId, dataWithKeys);
    }
  }, [addEditingKeysToRows]);

  const DERIVED_RECOMPUTE_DEBOUNCE_MS = 350;

  // Debounced: recompute derived columns for a single row by editingKey; then update buffer and trigger re-render.
  const scheduleDerivedRecomputeForRow = useCallback((editingKey) => {
    if (derivedRecomputeTimerRef.current) {
      clearTimeout(derivedRecomputeTimerRef.current);
      derivedRecomputeTimerRef.current = null;
    }
    pendingDerivedRecomputeKeyRef.current = editingKey;
    derivedRecomputeTimerRef.current = setTimeout(() => {
      derivedRecomputeTimerRef.current = null;
      const keyToRecompute = pendingDerivedRecomputeKeyRef.current;
      pendingDerivedRecomputeKeyRef.current = null;
      if (keyToRecompute == null) return;
      if (!derivedColumns || !isArray(derivedColumns) || isEmpty(derivedColumns)) return;

      const context = {
        mode: derivedColumnsMode ?? 'main',
        fieldName: derivedColumnsFieldName ?? null,
        getDataValue,
        query: queryFunction,
        monthRange: monthRange && Array.isArray(monthRange) && monthRange.length === 2 ? monthRange : null,
      };

      if (nestedTableTabId && parentNestedTableEditingDataRef) {
        const parentEditingData = parentNestedTableEditingDataRef.current.get(nestedTableTabId) || [];
        const rowIndex = parentEditingData.findIndex((row) => row && row.__editingKey__ === keyToRecompute);
        if (rowIndex === -1) return;
        const row = parentEditingData[rowIndex];
        const enrichedRow = applyDerivedColumnsForRow(row, derivedColumns, context);
        const updatedData = [...parentEditingData];
        updatedData[rowIndex] = enrichedRow;
        parentNestedTableEditingDataRef.current.set(nestedTableTabId, updatedData);
        onNestedBufferChange?.();
      } else {
        const editingData = mainTableEditingDataRef.current;
        if (!editingData || !isArray(editingData)) return;
        const rowIndex = editingData.findIndex((row) => row && row.__editingKey__ === keyToRecompute);
        if (rowIndex === -1) return;
        const row = editingData[rowIndex];
        const enrichedRow = applyDerivedColumnsForRow(row, derivedColumns, context);
        const updatedData = [...editingData];
        updatedData[rowIndex] = enrichedRow;
        mainTableEditingDataRef.current = updatedData;
        mainTableEditingDataRefEarly.current = updatedData;
        setMainTableEditingData(updatedData);
        setTableDataUpdateTrigger((t) => t + 1);
      }
    }, DERIVED_RECOMPUTE_DEBOUNCE_MS);
  }, [
    derivedColumns,
    derivedColumnsMode,
    derivedColumnsFieldName,
    getDataValue,
    queryFunction,
    monthRange,
    nestedTableTabId,
    parentNestedTableEditingDataRef,
    onNestedBufferChange,
    setTableDataUpdateTrigger,
  ]);

  // Main table editing buffer update function
  const updateMainTableEditingData = useCallback((editingKey, field, newValue) => {
    // If this is a nested instance, also update parent's nestedTableEditingDataRef
    if (nestedTableTabId && parentNestedTableEditingDataRef) {
      const parentEditingData = parentNestedTableEditingDataRef.current.get(nestedTableTabId) || [];
      const rowIndex = parentEditingData.findIndex(row => row && row.__editingKey__ === editingKey);
      if (rowIndex !== -1) {
        const updatedRow = { ...parentEditingData[rowIndex], [field]: newValue };
        const updatedData = [...parentEditingData];
        updatedData[rowIndex] = updatedRow;
        parentNestedTableEditingDataRef.current.set(nestedTableTabId, updatedData);
        onNestedBufferChange?.(); // Parent re-renders so nested gets updated offlineData
      }
    }
    
    setMainTableEditingData(prevData => {
      const editingData = [...prevData];
      const rowIndex = editingData.findIndex(row => row && row.__editingKey__ === editingKey);
      if (rowIndex !== -1) {
        editingData[rowIndex] = { ...editingData[rowIndex], [field]: newValue };
        mainTableEditingDataRef.current = editingData;
        return editingData;
      }
      return prevData;
    });

    // Schedule debounced derived-column recompute for this row only
    scheduleDerivedRecomputeForRow(editingKey);
  }, [nestedTableTabId, parentNestedTableEditingDataRef, onNestedBufferChange, scheduleDerivedRecomputeForRow]);

  // Helper function to detect changes in nested table data
  // Compares original data with current data and returns array of changed rows
  const detectNestedTableChanges = useCallback((originalData, currentData) => {
    if (!isArray(originalData) || !isArray(currentData)) {
      return [];
    }

    const changes = [];
    const originalMap = new Map();
    
    // Create a map of original rows by a unique identifier
    // Prefer __editingKey__ (stable in editing buffer), then id/key/__id__, else JSON.stringify
    const getRowKey = (r, i) => r?.__editingKey__ ?? r?.id ?? r?.key ?? r?.__id__ ?? `__match_${i}`;
    originalData.forEach((row, index) => {
      const rowKey = getRowKey(row, index);
      originalMap.set(rowKey, { row: cloneDeep(row), index });
    });

    // Check for modified and new rows
    currentData.forEach((currentRow, currentIndex) => {
      const rowKey = getRowKey(currentRow, currentIndex);
      const originalEntry = originalMap.get(rowKey);
      
      if (originalEntry) {
        // Row exists in original - check for changes
        const originalRow = originalEntry.row;
        const changedFields = {};
        let hasChanges = false;

        // Compare all fields
        const allKeys = new Set([...getDataKeys(originalRow), ...getDataKeys(currentRow)]);
        allKeys.forEach(key => {
          const originalValue = getDataValue(originalRow, key);
          const currentValue = getDataValue(currentRow, key);
          
          // Deep comparison (handle objects and arrays)
          if (JSON.stringify(originalValue) !== JSON.stringify(currentValue)) {
            changedFields[key] = {
              oldValue: originalValue,
              newValue: currentValue,
            };
            hasChanges = true;
          }
        });

        if (hasChanges) {
          changes.push({
            type: 'modified',
            rowKey,
            originalRow: originalEntry.row,
            currentRow: cloneDeep(currentRow),
            changedFields,
            index: currentIndex,
          });
        }
        
        // Remove from map to track which original rows are still present
        originalMap.delete(rowKey);
      } else {
        // New row (not in original)
        changes.push({
          type: 'added',
          rowKey,
          originalRow: null,
          currentRow: cloneDeep(currentRow),
          changedFields: {},
          index: currentIndex,
        });
      }
    });

    // Remaining entries in originalMap are deleted rows
    originalMap.forEach(({ row, index }) => {
      const rowKey = getRowKey(row, index);
      changes.push({
        type: 'deleted',
        rowKey,
        originalRow: row,
        currentRow: null,
        changedFields: {},
        index: index,
      });
    });

    return changes;
  }, []);

  // Get changed rows for a specific drawer tab
  const getChangedRowsForTab = useCallback((tabId) => {
    const trackingData = originalNestedTableDataRef.current.get(tabId);
    if (!trackingData) {
      return { tabId, changes: [], parentRowData: null, nestedTableFieldName: null, parentColumnName: null };
    }

    const currentData = nestedTableEditingDataRef.current.get(tabId) || [];
    const changes = detectNestedTableChanges(trackingData.originalData, currentData);
    
    return {
      tabId,
      parentRowData: trackingData.parentRowData,
      nestedTableFieldName: trackingData.nestedTableFieldName,
      parentColumnName: trackingData.parentColumnName,
      changes,
    };
  }, [detectNestedTableChanges]);

  // Get all changed rows across all nested table tabs
  const getAllChangedNestedTableRows = useCallback(() => {
    const allChanges = [];
    
    originalNestedTableDataRef.current.forEach((trackingData, tabId) => {
      const currentData = nestedTableEditingDataRef.current.get(tabId) || [];
      const changes = detectNestedTableChanges(trackingData.originalData, currentData);
      
      if (changes.length > 0) {
        allChanges.push({
          tabId,
          parentRowData: trackingData.parentRowData,
          nestedTableFieldName: trackingData.nestedTableFieldName,
          parentColumnName: trackingData.parentColumnName,
          changes,
        });
      }
    });
    
    return allChanges;
  }, [detectNestedTableChanges]);

  // Helper function to find parent row in editing buffer using editing key
  const findParentRowInEditingBuffer = useCallback((parentRowEditingKey, editingData) => {
    if (!parentRowEditingKey || !isArray(editingData)) {
      return null;
    }
    const rowIndex = editingData.findIndex(row => row && row.__editingKey__ === parentRowEditingKey);
    if (rowIndex === -1) {
      return null;
    }
    return { row: editingData[rowIndex], index: rowIndex };
  }, []);

  // Helper function to propagate drawer save to main table
  // Uses mainTableEditingDataRef so it sees the latest buffer (e.g. after form commit in same save).
  // When parentRowEditingKey is null (new row from openDrawerForNewRow), appends the row instead of updating.
  const propagateDrawerSaveToMain = useCallback((tabId, drawerOriginalData, parentRowEditingKey, nestedTableFieldName) => {
    if (!nestedTableFieldName) {
      console.error('propagateDrawerSaveToMain: Missing nestedTableFieldName');
      return;
    }

    const currentEditingData = mainTableEditingDataRef.current;

    // New row case: parentRowEditingKey is null - prepend form row + all nested tab data to main table at index 0
    if (!parentRowEditingKey) {
      const currentFormRow = formEditingRowRef.current;
      if (!currentFormRow) return;
      const { __nestedTables__, ...rowWithoutNested } = currentFormRow;
      const newRow = { ...rowWithoutNested };
      // Collect nested data from all tabs for this new row (all have parentRowEditingKey null)
      const trackingEntries = Array.from(originalNestedTableDataRef.current.entries());
      trackingEntries.forEach(([tid, tdata]) => {
        if (tdata.parentRowEditingKey === null && tdata.nestedTableFieldName) {
          const nestedData = nestedTableEditingDataRef.current.get(tid) || [];
          newRow[tdata.nestedTableFieldName] = cloneDeep(nestedData);
        }
      });
      const updatedEditingData = [newRow, ...(currentEditingData || [])];
      mainTableEditingDataRef.current = updatedEditingData;
      mainTableEditingDataRefEarly.current = updatedEditingData;
      setMainTableEditingData(updatedEditingData);
      skipNextInitFromSortedDataRef.current = true; // Prevent onTableDataChange from re-initing original
      setTableDataUpdateTrigger(prev => prev + 1);
      return;
    }

    // Existing row case: find and update
    const parentRowInfo = findParentRowInEditingBuffer(parentRowEditingKey, currentEditingData);
    if (!parentRowInfo) {
      console.error('propagateDrawerSaveToMain: Parent row not found with editingKey:', parentRowEditingKey);
      if (onDataChange) {
        onDataChange({
          severity: 'error',
          summary: 'Save Failed',
          detail: 'Could not find parent row in main table. The row may have been deleted.',
          life: 5000,
        });
      }
      return;
    }

    const updatedEditingData = [...currentEditingData];
    const { __nestedTables__, ...rowWithoutNestedTables } = parentRowInfo.row;

    updatedEditingData[parentRowInfo.index] = {
      ...rowWithoutNestedTables,
      [nestedTableFieldName]: cloneDeep(drawerOriginalData),
    };

    mainTableEditingDataRef.current = updatedEditingData;
    mainTableEditingDataRefEarly.current = updatedEditingData;
    setMainTableEditingData(updatedEditingData);
    skipNextInitFromSortedDataRef.current = true; // Prevent buffer re-init from overwriting original
    setTableDataUpdateTrigger(prev => prev + 1);
  }, [findParentRowInEditingBuffer, onDataChange, setTableDataUpdateTrigger]);

  // Handle drawer save - commits form buffer then saves nested table for current active tab
  const handleDrawerSave = useCallback(() => {
    console.log('[handleDrawerSave] called', {
      parentOriginalNestedTableDataRef: !!parentOriginalNestedTableDataRef,
      parentHandleDrawerSave: !!parentHandleDrawerSave,
      effectiveDrawerTabs: effectiveDrawerTabs?.length,
      pendingUploadsSize: pendingUploadsRef.current.size,
    });
    // If we're using parent refs (nested instance), delegate to parent's handleDrawerSave
    if (parentOriginalNestedTableDataRef && parentHandleDrawerSave) {
      console.log('[handleDrawerSave] delegating to parent (parentOriginalNestedTableDataRef)');
      return parentHandleDrawerSave();
    }
    if ((!effectiveDrawerTabs || effectiveDrawerTabs.length === 0) && parentHandleDrawerSave) {
      console.log('[handleDrawerSave] delegating to parent (no tabs)');
      return parentHandleDrawerSave();
    }

    // Pending uploads are flushed in the save confirmation callback, not here
    const hadPendingUploads = pendingUploadsRef.current.size > 0;
    console.log('[handleDrawerSave] hadPendingUploads:', hadPendingUploads);

    // Commit form buffer to main table if form has changes (read latest from ref)
    const currentFormRow = formEditingRowRef.current;
    let hasFormChanges = false;
    if (hasDrawerFormFields && currentFormRow && formOriginalRowRef.current) {
      try {
        hasFormChanges = JSON.stringify(currentFormRow) !== JSON.stringify(formOriginalRowRef.current);
      } catch (e) {}
    }
    if (hasFormChanges) {
      const editingKey = currentFormRow.__editingKey__;
      const editingData = mainTableEditingDataRef.current || [];
      const rowIndex = editingData.findIndex(row => row && row.__editingKey__ === editingKey);
      const rowToSave = cloneDeep(currentFormRow);
      const isNewRow = editingKey && String(editingKey).startsWith('main_row_new_');
      if (rowIndex !== -1) {
        const updatedData = [...editingData];
        if (rowToSave && typeof rowToSave === 'object' && rowToSave.id != null && /^main_row_\d+$/.test(String(rowToSave.id))) {
          const { id: _syntheticId, ...rowWithoutSyntheticId } = rowToSave;
          updatedData[rowIndex] = rowWithoutSyntheticId;
        } else {
          updatedData[rowIndex] = rowToSave;
        }
        setMainTableEditingData(updatedData);
        mainTableEditingDataRef.current = updatedData;
        mainTableEditingDataRefEarly.current = updatedData;
        formOriginalRowRef.current = cloneDeep(currentFormRow);
        skipNextInitFromSortedDataRef.current = true; // Prevent buffer re-init from overwriting original
        setTableDataUpdateTrigger((t) => t + 1);
      } else if (isNewRow) {
        const updatedData = [...editingData, rowToSave];
        setMainTableEditingData(updatedData);
        mainTableEditingDataRef.current = updatedData;
        mainTableEditingDataRefEarly.current = updatedData;
        formOriginalRowRef.current = cloneDeep(currentFormRow);
        skipNextInitFromSortedDataRef.current = true; // Prevent buffer re-init from overwriting original (keep baseline for diff)
        setTableDataUpdateTrigger((t) => t + 1);
      }
    }

    // Resolve tab for nested save
    let tabId = null;
    let activeTab = null;
    console.log('[handleDrawerSave] resolving tab', { effectiveDrawerTabsLen: effectiveDrawerTabs?.length, activeDrawerTabIndex, hasFormChanges, hadPendingUploads });
    if (!effectiveDrawerTabs || effectiveDrawerTabs.length === 0) {
      const trackingEntries = Array.from(originalNestedTableDataRef.current.entries());
      console.log('[handleDrawerSave] no tabs, trackingEntries:', trackingEntries.length);
      if (trackingEntries.length > 0) {
        tabId = trackingEntries[0][0];
      } else {
        if (hasFormChanges || hadPendingUploads || hasMainTableChangesRef.current) {
          openSaveDiffDialog(mainTableEditingDataRef.current);
        }
        return;
      }
    } else {
      activeTab = effectiveDrawerTabs[activeDrawerTabIndex];
      console.log('[handleDrawerSave] activeTab:', activeTab?.id, 'isJsonTable:', activeTab?.isJsonTable);
      if (!activeTab || !activeTab.isJsonTable) {
        if (hasFormChanges || hadPendingUploads || hasMainTableChangesRef.current) {
          openSaveDiffDialog(mainTableEditingDataRef.current);
        }
        return;
      }
      tabId = activeTab.id;
    }
    const trackingData = originalNestedTableDataRef.current.get(tabId);
    console.log('[handleDrawerSave] tabId:', tabId, 'trackingData:', !!trackingData);
    if (!trackingData) {
      if (hasFormChanges || hadPendingUploads || hasMainTableChangesRef.current) {
        openSaveDiffDialog(mainTableEditingDataRef.current);
      }
      return;
    }

    const drawerEditingData = nestedTableEditingDataRef.current.get(tabId) || [];
    let hasNestedChanges = false;
    try {
      if (!isArray(drawerEditingData) || !isArray(trackingData.originalData)) {
        hasNestedChanges = drawerEditingData !== trackingData.originalData;
      } else if (drawerEditingData.length !== trackingData.originalData.length) {
        hasNestedChanges = true;
      } else {
        hasNestedChanges = JSON.stringify(drawerEditingData) !== JSON.stringify(trackingData.originalData);
      }
    } catch (e) {
      hasNestedChanges = true;
    }
    console.log('[handleDrawerSave] hasFormChanges:', hasFormChanges, 'hasNestedChanges:', hasNestedChanges, 'hadPendingUploads:', hadPendingUploads);

    if (!hasFormChanges && !hasNestedChanges && !hadPendingUploads && !hasMainTableChangesRef.current) {
      if (onDataChange) {
        onDataChange({
          severity: 'info',
          summary: 'No Changes',
          detail: 'No changes detected in this nested table.',
          life: 3000,
        });
      }
      return;
    }

    if (hasNestedChanges) {
      // Step 1: Copy drawerEditing → drawerOriginal (save nested table changes)
      const drawerOriginalData = cloneDeep(drawerEditingData);
      trackingData.originalData = drawerOriginalData;
      originalNestedTableDataRef.current.set(tabId, trackingData);
      nestedTableEditingDataRef.current.set(tabId, cloneDeep(drawerOriginalData));

      // Step 2: Propagate drawerOriginal → mainEditing (update main with saved drawer state)
      const { parentRowEditingKey, nestedTableFieldName } = trackingData;
      if (nestedTableFieldName) {
        propagateDrawerSaveToMain(tabId, drawerOriginalData, parentRowEditingKey, nestedTableFieldName);
      } else {
        console.warn('handleDrawerSave: Missing nestedTableFieldName');
      }

      // New row with multiple nested tabs: sync all tabs' tracking so close does not show unsaved
      if (!parentRowEditingKey) {
        originalNestedTableDataRef.current.forEach((tdata, tid) => {
          if (tdata.parentRowEditingKey === null && tdata.nestedTableFieldName) {
            const nestedData = nestedTableEditingDataRef.current.get(tid) || [];
            tdata.originalData = cloneDeep(nestedData);
            originalNestedTableDataRef.current.set(tid, tdata);
            nestedTableEditingDataRef.current.set(tid, cloneDeep(nestedData));
          }
        });
      }
    } else if (hasFormChanges && !trackingData.parentRowEditingKey && trackingData.nestedTableFieldName) {
      // New row with form changes only (no nested changes) - still need to append to main table
      propagateDrawerSaveToMain(tabId, drawerEditingData, null, trackingData.nestedTableFieldName);
    }

    // For new row: sync form "original" so close does not show unsaved (row was just added to main)
    if (!trackingData.parentRowEditingKey && currentFormRow && (hasFormChanges || hasNestedChanges)) {
      formOriginalRowRef.current = cloneDeep(currentFormRow);
    }

    if (hasFormChanges || hasNestedChanges || hadPendingUploads || hasMainTableChangesRef.current) {
      openSaveDiffDialog(mainTableEditingDataRef.current);
    }
  }, [effectiveDrawerTabs, activeDrawerTabIndex, propagateDrawerSaveToMain, onDataChange, parentHandleDrawerSave, parentOriginalNestedTableDataRef, hasDrawerFormFields, setTableDataUpdateTrigger, openSaveDiffDialog]);

  // Persist main table editing buffer to original (used after diff dialog OK or when no diff)
  const persistMainSave = useCallback((editingData) => {
    const data = editingData ?? mainTableEditingData;
    const savedData = cloneDeep(data).map(row => {
      if (row && typeof row === 'object' && '__nestedTables__' in row) {
        const { __nestedTables__, ...rowWithoutNestedTables } = row;
        return rowWithoutNestedTables;
      }
      return row;
    });
    mainTableOriginalDataRef.current = savedData;
    setMainTableOriginalVersion((v) => v + 1);
    if (onDataChange) {
      onDataChange({
        severity: 'success',
        summary: 'Changes Saved',
        detail: 'All changes have been saved.',
        life: 3000,
      });
    }
  }, [mainTableEditingData, onDataChange]);

  // Prepare save diff + payload dialog from current (or provided) editing buffer
  function openSaveDiffDialog(editingDataOverride) {
    const writeSchemaRaw = currentQueryDoc?.writeSchema;
    const explicitDoctype = currentQueryDoc?.writeDocTypeName ?? currentQueryDoc?.writeDocType;
    let doctype = (explicitDoctype && String(explicitDoctype).trim()) || null;
    let schemaStructure = null;

    if (writeSchemaRaw) {
      const writeSchema =
        typeof writeSchemaRaw === 'string'
          ? (() => {
              try {
                return JSON.parse(writeSchemaRaw);
              } catch {
                return writeSchemaRaw;
              }
            })()
          : writeSchemaRaw;
      if (!doctype) doctype = getDoctypeFromWriteSchema(writeSchema);
      schemaStructure = getSchemaStructure(writeSchema);
    } else {
      const cached = explicitDoctype ? getCachedWriteSchemaStructure(String(explicitDoctype).trim()) : undefined;
      schemaStructure = cached || deriveSchemaStructureFromWriteForm(effectiveMainWriteForm);
    }

    const wfStruct = deriveSchemaStructureFromWriteForm(effectiveMainWriteForm);
    if (schemaStructure && wfStruct) {
      const ct = { ...(schemaStructure.childTables || {}) };
      for (const [ck, cols] of Object.entries(wfStruct.childTables || {})) {
        if (!ct[ck]) ct[ck] = cols;
        else ct[ck] = uniq([...(ct[ck] || []), ...(cols || [])]);
      }
      schemaStructure = {
        ...schemaStructure,
        mainFields: uniq([...(schemaStructure.mainFields || []), ...(wfStruct.mainFields || [])]),
        childTables: ct,
      };
    }

    const hasStructure =
      schemaStructure &&
      ((schemaStructure.mainFields && schemaStructure.mainFields.length > 0) ||
        Object.keys(schemaStructure.childTables || {}).length > 0);

    if (!doctype || !hasStructure) {
      if (onDataChange) {
        onDataChange({
          severity: 'warn',
          summary: 'Write schema not configured',
          detail:
            'Set write schema on the query, or add a writeForm (and writeDocTypeName) so save payload structure can be derived.',
          life: 5000,
        });
      }
      return;
    }
    const excludeFromDiff = new Set(
      (derivedColumns || []).filter((dc) => dc.save !== true).map((dc) => dc.columnName).filter(Boolean)
    );
    const skipKey = (k) => String(k).startsWith('__') || excludeFromDiff.has(k);

    const wfLayoutForSave = getWriteFormLayout(effectiveMainWriteForm);
    const rawBulkParent =
      currentQueryDoc?.bulkUpdateParentField ?? wfLayoutForSave?.bulkUpdateParentField;
    const bulkUpdateParentField =
      rawBulkParent != null && String(rawBulkParent).trim() !== ''
        ? String(rawBulkParent).trim()
        : undefined;

    const childTableKeys = new Set(Object.keys(schemaStructure.childTables || {}));

    const getRowKey = (row, origIndex) => {
      if (!row || typeof row !== 'object') return `__match_${origIndex}`;
      return row.__editingKey__ ?? row.id ?? row.key ?? row.__id__ ?? `__match_${origIndex}`;
    };

    const diffFieldValue = (o, e, fieldKey) => {
      const forceChildNested = fieldKey && childTableKeys.has(fieldKey);
      if (forceChildNested) {
        return diffChildTableArrays(o, e, skipKey);
      }
      const isArrayOfObjects = (v) =>
        isArray(v) && v.every((item) => item == null || (typeof item === 'object' && !isArray(item)));
      if (isArrayOfObjects(o) && isArrayOfObjects(e)) {
        return diffChildTableArrays(o, e, skipKey);
      }
      if (JSON.stringify(o) !== JSON.stringify(e)) {
        return { from: o, to: e };
      }
      return null;
    };

    const originalData = mainTableOriginalDataRef.current;
    const editingData = editingDataOverride ?? mainTableEditingDataRef.current ?? [];
    if (isArray(originalData) && isArray(editingData)) {
      const originalMap = new Map();
      originalData.forEach((row, idx) => originalMap.set(getRowKey(row, idx), { row, index: idx }));
      const diff = [];
      editingData.forEach((editRow, editIndex) => {
        const editKey = getRowKey(editRow, editIndex);
        const origEntry = originalMap.get(editKey);
        originalMap.delete(editKey);
        if (!origEntry) {
          diff.push({ index: editIndex, rowKey: editKey, type: 'added', row: editRow });
          return;
        }
        const orig = origEntry.row;
        const keys = uniq([...getDataKeys(orig), ...getDataKeys(editRow)].filter((k) => !skipKey(k)));
        const changes = {};
        keys.forEach((k) => {
          const o = getDataValue(orig, k);
          const e = getDataValue(editRow, k);
          const fieldDiff = diffFieldValue(o, e, k);
          if (fieldDiff) changes[k] = fieldDiff;
        });
        if (Object.keys(changes).length > 0) {
          diff.push({ index: editIndex, rowKey: editKey, type: 'changed', changes, orig, editRow });
        }
      });
      originalMap.forEach(({ row }, key) => diff.push({ index: -1, rowKey: key, type: 'removed', row }));

      if (diff.length > 0) {
        const added = diff.filter((e) => e.type === 'added');
        const changed = diff.filter((e) => e.type === 'changed');
        const removed = diff.filter((e) => e.type === 'removed');

        const addedCoalesced = coalesceAddedRows(added);
        const changedCoalesced = coalesceChangedRows(changed, bulkUpdateParentField);

        const writeOpsNeeded = computeWriteOpsNeeded(addedCoalesced, changedCoalesced, removed);
        const permissionViolation = getFirstWritePermissionViolation(writeOpsNeeded, resolvedWritePermissions);
        if (permissionViolation) {
          if (onDataChange) {
            const detailMsg = permissionViolation === 'create'
              ? 'Creating new rows is not allowed for this configuration.'
              : permissionViolation === 'update'
                ? 'Editing existing rows is not allowed for this configuration.'
                : 'Removing rows is not allowed for this configuration.';
            onDataChange({ severity: 'warn', summary: 'Save not allowed', detail: detailMsg, life: 5000 });
          }
          return;
        }

        const createPayload = addedCoalesced.length > 0
          ? (() => {
              const createSkipKey = (k) => String(k).startsWith('__');
              const fieldsArr = addedCoalesced.map((e) => ({
                fields: rowToCreateFields(e.row, schemaStructure, createSkipKey),
              }));
              return { doctype, fields: fieldsArr };
            })()
          : null;

        const updatePayload =
          changedCoalesced.length > 0
            ? {
                doctype,
                fields: changedCoalesced.map((e) =>
                  rowToUpdateFields(e.editRow, e.changes, schemaStructure, skipKey, bulkUpdateParentField),
                ),
              }
            : null;

        const bulkUpdateVariablesPreview =
          changedCoalesced.length > 0
            ? buildBulkUpdateVariables(
                doctype,
                changedCoalesced,
                schemaStructure,
                skipKey,
                {
                  allowCreate: resolvedWritePermissions.create,
                  allowUpdate: resolvedWritePermissions.update,
                  allowDelete: resolvedWritePermissions.delete,
                  bulkUpdateParentField,
                },
              )
            : null;

        const removedRows = removed.map((e) => e.row);

        setSavePayloadContent({
          createPayload,
          updatePayload,
          bulkUpdateVariablesPreview,
          removedRows,
          doctype,
          changedRows: changedCoalesced,
          schemaStructure,
          skipKey,
          writeOpsNeeded,
          bulkUpdateParentField: bulkUpdateParentField ?? null,
        });
        setSaveDiffDialogVisible(true);
        return;
      }
    }
    // No data diff, but pending file uploads still need to be flushed — open dialog for confirmation
    if (pendingUploadsRef.current.size > 0) {
      setSavePayloadContent({
        createPayload: null,
        updatePayload: null,
        bulkUpdateVariablesPreview: null,
        removedRows: [],
        doctype,
        changedRows: [],
        schemaStructure,
        skipKey: (k) => String(k).startsWith('__'),
        writeOpsNeeded: { needsCreate: false, needsUpdate: false, needsDelete: false },
        bulkUpdateParentField: null,
      });
      setSaveDiffDialogVisible(true);
      return;
    }
    if (onDataChange) {
      onDataChange({
        severity: 'info',
        summary: 'No changes',
        detail: 'No changes to save.',
        life: 3000,
      });
    }
  }

  // Handle main save - shows create/update payload dialog
  const handleMainSave = () => {
    openSaveDiffDialog();
  };

  // Load global functions module when save dialog opens (for display and for Save button)
  useEffect(() => {
    if (!saveDiffDialogVisible) return;
    const hasCreate = savePayloadContent.createPayload?.fields?.length > 0;
    const hasUpdate = savePayloadContent.updatePayload?.fields?.length > 0;
    if (!hasCreate && !hasUpdate) return;

    let cancelled = false;
    let objectUrl = null;

    const load = async () => {
      try {
        const functionsCode = await firestoreService.loadGlobalFunctions();
        if (cancelled || !functionsCode?.trim()) return;

        const blob = new Blob([functionsCode], { type: 'text/javascript' });
        objectUrl = URL.createObjectURL(blob);
        let elbrit = {};
        try {
          elbrit = await import(/* webpackIgnore: true */ objectUrl);
        } finally {
          if (objectUrl) {
            URL.revokeObjectURL(objectUrl);
            objectUrl = null;
          }
        }
        if (cancelled) return;
        savePayloadElbritRef.current = elbrit;
        setSavePayloadDisplayQueries({ bulkCreate: elbrit?.bulkCreate ?? null, bulkUpdate: elbrit?.bulkUpdate ?? null });
      } catch (err) {
        if (!cancelled) {
          setSavePayloadDisplayQueries({ bulkCreate: null, bulkUpdate: null });
        }
      }
    };

    load();
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [saveDiffDialogVisible, savePayloadContent.createPayload?.fields?.length, savePayloadContent.updatePayload?.fields?.length]);

  const handleSaveDiffDialogOk = useCallback(async () => {
    const { createPayload, updatePayload, doctype, writeOpsNeeded } = savePayloadContent;
    const hasCreate = createPayload?.fields?.length > 0;
    const hasUpdate = updatePayload?.fields?.length > 0;
    if (writeOpsNeeded) {
      const permissionViolation = getFirstWritePermissionViolation(writeOpsNeeded, resolvedWritePermissions);
      if (permissionViolation) {
        if (onDataChange) {
          const detailMsg = permissionViolation === 'create'
            ? 'Creating new rows is not allowed for this configuration.'
            : permissionViolation === 'update'
              ? 'Editing existing rows is not allowed for this configuration.'
              : 'Removing rows is not allowed for this configuration.';
          onDataChange({ severity: 'warn', summary: 'Save not allowed', detail: detailMsg, life: 5000 });
        }
        return;
      }
    }
    // Flush pending file uploads (registered when user selected files in the drawer form)
    const flushPendingUploads = async () => {
      if (pendingUploadsRef.current.size === 0) return;
      const entries = Array.from(pendingUploadsRef.current.entries());
      await Promise.all(entries.map(async ([fieldId, { file, getAuth, params, docnameCol }]) => {
        try {
          const { endpointUrl, authToken } = await getAuth();
          const baseUrl = endpointUrl ? new URL(endpointUrl).origin : '';
          const fd = new FormData();
          for (const [k, v] of Object.entries(params || {})) {
            fd.append(k, v == null ? '' : String(v));
          }
          fd.append('file', file);
          fd.append('doctype', currentQueryDoc?.writeDocTypeName ?? currentQueryDoc?.writeDocType ?? '');
          fd.append('docname', String(formEditingRowRef.current?.[docnameCol] ?? ''));
          fd.append('fieldname', fieldId);
          const headers = {};
          if (authToken) headers.Authorization = authToken;
          const res = await fetch(`${baseUrl}/api/method/upload_to_field`, {
            method: 'POST',
            credentials: 'include',
            headers,
            body: fd,
          });
          const data = await res.json();
          console.log('[flushPendingUploads] response', fieldId, data);
        } catch (err) {
          console.error('[flushPendingUploads] failed for', fieldId, err);
        }
      }));
      pendingUploadsRef.current.clear();
    };

    if (!hasCreate && !hasUpdate) {
      await flushPendingUploads();
      persistMainSave(mainTableEditingData);
      setSaveDiffDialogVisible(false);
      return;
    }

    setSaveDiffDialogSaving(true);
    let objectUrl = null;
    try {
      // Use already-loaded module from ref (loaded when dialog opened) or load now
      let elbrit = savePayloadElbritRef.current;
      const needLoad = (hasCreate && !elbrit?.bulkCreate) || (hasUpdate && !elbrit?.bulkUpdate);
      if (needLoad) {
        const functionsCode = await firestoreService.loadGlobalFunctions();
        if (!functionsCode?.trim()) {
          if (onDataChange) {
            onDataChange({ severity: 'error', summary: 'Save Failed', detail: 'Global functions not configured. Add bulkCreate and bulkUpdate to #__GLOBAL__#.functions.', life: 5000 });
          }
          return;
        }

        const blob = new Blob([functionsCode], { type: 'text/javascript' });
        objectUrl = URL.createObjectURL(blob);
        try {
          elbrit = await import(/* webpackIgnore: true */ objectUrl);
        } finally {
          if (objectUrl) {
            URL.revokeObjectURL(objectUrl);
            objectUrl = null;
          }
        }
        savePayloadElbritRef.current = elbrit;
        setSavePayloadDisplayQueries({ bulkCreate: elbrit?.bulkCreate ?? null, bulkUpdate: elbrit?.bulkUpdate ?? null });
      }

      const bulkCreate = elbrit?.bulkCreate;
      const bulkUpdate = elbrit?.bulkUpdate;

      if (hasCreate && !bulkCreate) {
        if (onDataChange) {
          onDataChange({ severity: 'error', summary: 'Save Failed', detail: 'bulkCreate not found in global functions.', life: 5000 });
        }
        return;
      }
      if (hasUpdate && !bulkUpdate) {
        if (onDataChange) {
          onDataChange({ severity: 'error', summary: 'Save Failed', detail: 'bulkUpdate not found in global functions.', life: 5000 });
        }
        return;
      }

      const { endpointUrl, authToken } = await getEndpointAndAuthWithTokenOverride(currentQueryDoc, graphqlToken);
      if (!endpointUrl) {
        if (onDataChange) {
          onDataChange({ severity: 'error', summary: 'Save Failed', detail: 'GraphQL endpoint URL is not set.', life: 5000 });
        }
        return;
      }

      const options = { endpointUrl, authToken };

      await flushPendingUploads();

      if (hasCreate) {
        const res = await fetchGraphQLRequest(bulkCreate, { doctype, fields: createPayload.fields }, options);
        if (!res.ok) {
          const errBody = await res.text();
          let errMsg = errBody;
          try {
            const errJson = JSON.parse(errBody);
            errMsg = errJson?.errors?.[0]?.message || errJson?.message || errBody;
          } catch {}
          throw new Error(errMsg || `HTTP ${res.status}`);
        }
      }
      if (hasUpdate) {
        const { changedRows, schemaStructure, skipKey, bulkUpdateParentField } = savePayloadContent;
        const bulkUpdateVariables = buildBulkUpdateVariables(
          doctype,
          changedRows || [],
          schemaStructure || { mainFields: [], childTables: {} },
          skipKey || (() => false),
          {
            allowCreate: resolvedWritePermissions.create,
            allowUpdate: resolvedWritePermissions.update,
            allowDelete: resolvedWritePermissions.delete,
            bulkUpdateParentField: bulkUpdateParentField || undefined,
          },
        );
        const res = await fetchGraphQLRequest(bulkUpdate, bulkUpdateVariables, options);
        if (!res.ok) {
          const errBody = await res.text();
          let errMsg = errBody;
          try {
            const errJson = JSON.parse(errBody);
            errMsg = errJson?.errors?.[0]?.message || errJson?.message || errBody;
          } catch {}
          throw new Error(errMsg || `HTTP ${res.status}`);
        }
      }

      persistMainSave(mainTableEditingData);
      setSaveDiffDialogVisible(false);
      setSavePayloadDisplayQueries({ bulkCreate: null, bulkUpdate: null });
      savePayloadElbritRef.current = null;
    } catch (err) {
      if (onDataChange) {
        onDataChange({ severity: 'error', summary: 'Save Failed', detail: err?.message || String(err), life: 5000 });
      }
    } finally {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      setSaveDiffDialogSaving(false);
    }
  }, [savePayloadContent, currentQueryDoc, mainTableEditingData, persistMainSave, onDataChange, resolvedWritePermissions, graphqlToken]);

  // Handle main cancel - reverts editing buffer to original buffer
  const handleMainCancel = useCallback(() => {
    // Deep clone originalData → editingData (revert all changes)
    const originalData = mainTableOriginalDataRef.current;
    const editingData = cloneDeep(originalData);
    mainTableEditingDataRef.current = editingData;
    mainTableEditingDataRefEarly.current = editingData;
    setMainTableEditingData(editingData);

    // Reset nested table buffers if needed
    nestedTableEditingDataRef.current.clear();
    originalNestedTableDataRef.current.clear();

    // Force pipeline to recompute tableData from the reverted ref
    setTableDataUpdateTrigger((t) => t + 1);

    // Show notification
    if (onDataChange) {
      onDataChange({
        severity: 'info',
        summary: 'Changes Discarded',
        detail: 'All unsaved changes have been discarded.',
        life: 3000,
      });
    }
  }, [onDataChange, setTableDataUpdateTrigger]);

  // Handle drawer cancel - reverts drawer editing buffer to original buffer
  const handleDrawerCancel = useCallback(() => {
    const hasTabs = effectiveDrawerTabs && effectiveDrawerTabs.length > 0;
    if (!hasTabs) {
      // Scalar-only: revert form buffer
      if (formOriginalRowRef.current) {
        setFormEditingRow(cloneDeep(formOriginalRowRef.current));
      }
      if (onDataChange) {
        onDataChange({
          severity: 'info',
          summary: 'Changes Discarded',
          detail: 'Unsaved changes have been discarded.',
          life: 3000,
        });
      }
      return;
    }

    const activeTab = effectiveDrawerTabs[activeDrawerTabIndex];
    if (!activeTab || !activeTab.isJsonTable) {
      // Group-based tab: revert form buffer if any
      if (formOriginalRowRef.current) {
        setFormEditingRow(cloneDeep(formOriginalRowRef.current));
      }
      return;
    }

    const tabId = activeTab.id;
    const trackingData = originalNestedTableDataRef.current.get(tabId);
    if (!trackingData) {
      return;
    }

    // Deep clone drawer's originalData → drawer's editingData (revert changes for current tab only)
    const drawerOriginalData = trackingData.originalData;
    const drawerEditingData = cloneDeep(drawerOriginalData);
    nestedTableEditingDataRef.current.set(tabId, drawerEditingData);

    // Revert form buffer to last saved/original
    if (formOriginalRowRef.current) {
      setFormEditingRow(cloneDeep(formOriginalRowRef.current));
    }

    // Show notification
    if (onDataChange) {
      onDataChange({
        severity: 'info',
        summary: 'Changes Discarded',
        detail: 'Unsaved changes in this nested table have been discarded.',
        life: 3000,
      });
    }
  }, [effectiveDrawerTabs, activeDrawerTabIndex, onDataChange]);

  // Check if main table has unsaved changes (use ref to avoid recalculating on every render)
  const hasMainTableChangesRef = useRef(false);
  const hasMainTableChanges = useMemo(() => {
    const originalData = mainTableOriginalDataRef.current;
    const editingData = mainTableEditingData;
    if (!isArray(originalData) || !isArray(editingData) || originalData.length !== editingData.length) {
      const hasChanges = originalData.length !== editingData.length;
      hasMainTableChangesRef.current = hasChanges;
      return hasChanges;
    }
    // Strip __nestedTables__ from editing before compare (original has none after save)
    const editingForCompare = editingData.map((row) => {
      if (row && typeof row === 'object' && '__nestedTables__' in row) {
        const { __nestedTables__, ...rest } = row;
        return rest;
      }
      return row;
    });
    try {
      const hasChanges = JSON.stringify(originalData) !== JSON.stringify(editingForCompare);
      hasMainTableChangesRef.current = hasChanges;
      return hasChanges;
    } catch (e) {
      return false;
    }
  }, [mainTableEditingData, mainTableOriginalVersion]);

  // Check if drawer has unsaved changes (nested tab only; form is computed on demand on Save/Close to avoid lag)
  const hasDrawerChangesRef = useRef(false);
  const hasDrawerChanges = useMemo(() => {
    let hasNestedChanges = false;
    if (effectiveDrawerTabs && effectiveDrawerTabs.length > 0) {
      const activeTab = effectiveDrawerTabs[activeDrawerTabIndex];
      if (activeTab?.isJsonTable) {
        const tabId = activeTab.id;
        const trackingData = originalNestedTableDataRef.current.get(tabId);
        if (trackingData) {
          const originalData = trackingData.originalData;
          const editingData = nestedTableEditingDataRef.current.get(tabId) || [];
          if (!isArray(originalData) || !isArray(editingData) || originalData.length !== editingData.length) {
            hasNestedChanges = originalData.length !== editingData.length;
          } else {
            try {
              hasNestedChanges = JSON.stringify(originalData) !== JSON.stringify(editingData);
            } catch (e) {
              hasNestedChanges = false;
            }
          }
        }
      }
    }
    hasDrawerChangesRef.current = hasNestedChanges;
    return hasNestedChanges;
  }, [effectiveDrawerTabs, activeDrawerTabIndex]);

  // On-demand: form or nested has unsaved changes (used only on Close to avoid recomputing on every keystroke)
  const getHasUnsavedDrawerChanges = useCallback(() => {
    let hasFormChanges = false;
    const currentFormRow = formEditingRowRef.current;
    if (hasDrawerFormFields && currentFormRow && formOriginalRowRef.current) {
      try {
        hasFormChanges = JSON.stringify(currentFormRow) !== JSON.stringify(formOriginalRowRef.current);
      } catch (e) {}
    }
    let hasNestedChanges = false;
    if (effectiveDrawerTabs && effectiveDrawerTabs.length > 0) {
      const activeTab = effectiveDrawerTabs[activeDrawerTabIndex];
      if (activeTab?.isJsonTable) {
        const tabId = activeTab.id;
        const trackingData = originalNestedTableDataRef.current.get(tabId);
        if (trackingData) {
          const originalData = trackingData.originalData;
          const editingData = nestedTableEditingDataRef.current.get(tabId) || [];
          if (!isArray(originalData) || !isArray(editingData) || originalData.length !== editingData.length) {
            hasNestedChanges = originalData.length !== editingData.length;
          } else {
            try {
              hasNestedChanges = JSON.stringify(originalData) !== JSON.stringify(editingData);
            } catch (e) {}
          }
        }
      }
    }
    return hasFormChanges || hasNestedChanges;
  }, [effectiveDrawerTabs, activeDrawerTabIndex, hasDrawerFormFields]);

  // Open drawer with nested JSON tables
  // Creates tabs dynamically for each nested table
  const openDrawerWithJsonTables = useCallback((nestedTables, rowData, tableOptions = null) => {
    if (!nestedTables || !isArray(nestedTables) || nestedTables.length === 0) {
      return;
    }
    if (enableWriteEffective && !resolvedWritePermissions.update) {
      if (onDataChange) {
        onDataChange({
          severity: 'warn',
          summary: 'Cannot edit row',
          detail: 'Editing existing rows is not allowed for this configuration.',
          life: 4000,
        });
      }
      return;
    }

    // Store nested tables for drawer rendering
    setDrawerJsonTables(nestedTables);

    // Create drawer tabs dynamically - one per nested table
    // Get the parent column name from the first nested table's fieldName (which is the column name in main table)
    // All nested tables in __nestedTables__ come from the same parent column
    const parentColumnName = nestedTables[0]?.fieldName || null;
    const jsonTableTabs = nestedTables.map((nestedTable, index) => {
      const tabId = `json-table-${Date.now()}-${index}`;
      
      // Extract parent row editing key - CRITICAL: rowData must have __editingKey__ from tableData
      const parentRowEditingKey = rowData?.__editingKey__ || null;

      // Use items from the editing buffer when available. The display pipeline's nestedTable.data
      // comes from raw server data (no __editingKey__ on child items), so addEditingKeysToRows
      // would generate fresh random keys. Those keys won't match the ones in mainTableOriginalDataRef
      // (assigned by mainTableEditingRowsFromLeafData), causing the diff to see every row as
      // removed+added → delete-all + recreate-all on save.
      const parentRowFromBuffer = parentRowEditingKey
        ? (mainTableEditingDataRef.current || []).find(r => r && r.__editingKey__ === parentRowEditingKey)
        : null;
      const itemsFromBuffer = parentRowFromBuffer?.[nestedTable.fieldName];
      const sourceData = isArray(itemsFromBuffer) ? itemsFromBuffer : nestedTable.data;

      const originalData = sourceData && isArray(sourceData)
        ? addEditingKeysToRows(cloneDeep(sourceData))
        : [];
      
      originalNestedTableDataRef.current.set(tabId, {
        originalData,
        parentRowData: cloneDeep(rowData),
        parentRowEditingKey, // Store parent row editing key for lookup
        nestedTableFieldName: nestedTable.fieldName,
        parentColumnName: parentColumnName,
      });
      
      // Initialize editing data with original data (deep clone to preserve editing keys)
      nestedTableEditingDataRef.current.set(tabId, cloneDeep(originalData));
      
      let tabCols = nestedTable.data && isArray(nestedTable.data) && nestedTable.data.length > 0 && nestedTable.data[0]
        ? Object.keys(nestedTable.data[0]).filter(k => !String(k).startsWith('__'))
        : [];
      if (tabCols.length === 0) {
        const jtc = jsonTableColumns[nestedTable.fieldName];
        const nt = jtc?.nestedTables?.find(n => n.fieldName === nestedTable.fieldName);
        if (nt?.columns?.length) tabCols = nt.columns;
      }
      return {
        id: tabId,
        name: nestedTable.title || nestedTable.fieldName || `Table ${index + 1}`,
        data: nestedTable.data,
        fieldName: nestedTable.fieldName, // This is the nested table's fieldName (same as parentColumnName for first-level nested tables)
        parentColumnName: parentColumnName, // Store parent column name for nested editable columns lookup
        nestedTableFieldName: nestedTable.fieldName, // The nested table's own fieldName for lookup in editableColumns.nested
        isJsonTable: true, // Flag to identify JSON table tabs
        columns: tabCols,
      };
    });

    // Use the first nested table's data to open the drawer
    const firstTableData = nestedTables[0]?.data || [];
    
    // Set drawer header title from row data if available
    // Get first column value from rowData keys or use columns array
    let firstColumnValue = null;
    if (rowData && typeof rowData === 'object') {
      // Try to get first column from columns array if available
      if (columns && columns.length > 0) {
        firstColumnValue = getDataValue(rowData, columns[0]);
      } else {
        // Fallback: get first key from rowData (excluding special keys)
        const rowKeys = getDataKeys(rowData).filter(key => !key.startsWith('__'));
        if (rowKeys.length > 0) {
          firstColumnValue = getDataValue(rowData, rowKeys[0]);
        }
      }
    }
    const drawerTitle = firstColumnValue != null ? String(firstColumnValue) : 'Nested Tables';

    // Temporarily set drawer tabs to JSON table tabs
    // We'll need to handle this specially in the drawer rendering
    if (onDrawerTabsChange) {
      onDrawerTabsChange(jsonTableTabs);
    }

    // Pre-select the row we opened from so the scalar edit form has a row without requiring a separate selection
    setSelectedRowData(rowData || null);
    // Init form buffer (drawer not visible yet so wrapper would not run)
    if (rowData && hasDrawerFormFields) {
      formOriginalRowRef.current = cloneDeep(rowData);
      setFormEditingRow(cloneDeep(rowData));
    } else {
      formOriginalRowRef.current = null;
      setFormEditingRow(null);
    }

    // Open drawer with first table's data
    openDrawer(firstTableData, null, drawerTitle, tableOptions);
  }, [columns, onDrawerTabsChange, openDrawer, hasDrawerFormFields, jsonTableColumns, enableWriteEffective, resolvedWritePermissions.update, onDataChange]);

  // Open drawer for a single row in enableWrite mode - works with scalar-only, nested-only, or both
  const openDrawerForRow = useCallback((rowData, tableOptions = null) => {
    if (enableWriteEffective && !resolvedWritePermissions.update) {
      if (onDataChange) {
        onDataChange({
          severity: 'warn',
          summary: 'Cannot edit row',
          detail: 'Editing existing rows is not allowed for this configuration.',
          life: 4000,
        });
      }
      return;
    }
    const nestedTables = rowData?.__nestedTables__;
    const hasNested = nestedTables && isArray(nestedTables) && nestedTables.length > 0;
    const hasScalar = hasDrawerFormFields;

    if (hasNested) {
      openDrawerWithJsonTables(nestedTables, rowData, tableOptions);
      return;
    }

    if (!hasScalar) return;

    // Scalar-only: set empty tabs, init form buffer, open drawer
    if (onDrawerTabsChange) {
      onDrawerTabsChange([]);
    }
    setSelectedRowData(rowData || null);
    formOriginalRowRef.current = rowData ? cloneDeep(rowData) : null;
    setFormEditingRow(rowData ? cloneDeep(rowData) : null);

    let firstColumnValue = null;
    if (rowData && typeof rowData === 'object') {
      if (columns && columns.length > 0) {
        firstColumnValue = getDataValue(rowData, columns[0]);
      } else {
        const rowKeys = getDataKeys(rowData).filter(key => !key.startsWith('__'));
        if (rowKeys.length > 0) {
          firstColumnValue = getDataValue(rowData, rowKeys[0]);
        }
      }
    }
    const drawerTitle = firstColumnValue != null ? String(firstColumnValue) : 'Details';

    const tableOptsWithOverride = { ...(tableOptions || {}), drawerTabsOverride: [] };
    openDrawer([rowData], null, drawerTitle, tableOptsWithOverride);
  }, [columns, onDrawerTabsChange, openDrawer, openDrawerWithJsonTables, hasDrawerFormFields, enableWriteEffective, resolvedWritePermissions.update, onDataChange]);

  // Open drawer for new row (empty form + empty nested tables) - used by blue "+" in main table
  const openDrawerForNewRow = useCallback(() => {
    if (enableWriteEffective && !resolvedWritePermissions.create) {
      if (onDataChange) {
        onDataChange({
          severity: 'warn',
          summary: 'Cannot add row',
          detail: 'Creating new rows is not allowed for this configuration.',
          life: 4000,
        });
      }
      return;
    }
    let nestedTables = [];

    // Build nested table structure from jsonTableColumns (when we have existing data with nested tables)
    const jsonMap = jsonTableColumns;
    if (jsonMap && typeof jsonMap === 'object' && Object.keys(jsonMap).length > 0) {
      Object.values(jsonMap).forEach((jsonInfo) => {
        if (jsonInfo?.nestedTables && isArray(jsonInfo.nestedTables)) {
          jsonInfo.nestedTables.forEach((nt) => {
            nestedTables.push({
              fieldName: nt.fieldName,
              title: nt.title || nt.fieldName,
              data: [],
              columns: nt.columns && isArray(nt.columns) ? nt.columns : [],
            });
          });
        }
      });
    }

    // Block only when scalar/object drawer fields, nested JSON tables, and nested column schema are all absent
    if (nestedTables.length === 0 && !hasDrawerFormFields && !hasNestedEditableSchema) {
      if (onDataChange) {
        onDataChange({
          severity: 'warn',
          summary: 'Cannot add new row',
          detail: 'No editable schema available. Add data first or configure writeForm.',
          life: 5000,
        });
      }
      return;
    }

    setDrawerJsonTables(nestedTables);
    const parentColumnName = nestedTables[0]?.fieldName || null;
    const jsonTableTabs = nestedTables.map((nestedTable, index) => {
      const tabId = `json-table-new-${Date.now()}-${index}`;
      originalNestedTableDataRef.current.set(tabId, {
        originalData: [],
        parentRowData: null,
        parentRowEditingKey: null,
        nestedTableFieldName: nestedTable.fieldName,
        parentColumnName,
      });
      nestedTableEditingDataRef.current.set(tabId, []);

      return {
        id: tabId,
        name: nestedTable.title || nestedTable.fieldName || `Table ${index + 1}`,
        data: [],
        fieldName: nestedTable.fieldName,
        parentColumnName,
        nestedTableFieldName: nestedTable.fieldName,
        isJsonTable: true,
        columns: nestedTable.columns && isArray(nestedTable.columns) ? nestedTable.columns : [],
      };
    });

    const emptyRow = {};
    scalarEditableColumns.forEach((col) => {
      const t = columnTypes[col] || 'string';
      if (t === 'number') emptyRow[col] = null;
      else if (t === 'boolean') emptyRow[col] = false;
      else if (t === 'date') emptyRow[col] = null;
      else emptyRow[col] = '';
    });
    objectEditableFields.forEach(({ columnName, key, resolvedType }) => {
      const objectValue = parseJsonObject(emptyRow[columnName]) || {};
      if (objectValue[key] !== undefined) return;
      if (resolvedType === 'number') objectValue[key] = null;
      else if (resolvedType === 'boolean') objectValue[key] = false;
      else if (resolvedType === 'date') objectValue[key] = null;
      else objectValue[key] = '';
      emptyRow[columnName] = objectValue;
    });
    const newEditingKey = `main_row_new_${Date.now()}`;
    emptyRow.__editingKey__ = newEditingKey;

    if (onDrawerTabsChange) {
      onDrawerTabsChange(jsonTableTabs);
    }
    setSelectedRowData(emptyRow);
    formOriginalRowRef.current = cloneDeep(emptyRow);
    setFormEditingRow(cloneDeep(emptyRow));
    const tableOptions = {
      editableColumns,
      enableCellEdit: true,
      drawerTabsOverride: jsonTableTabs,
    };
    openDrawer([], null, 'New Row', tableOptions);
  }, [
    jsonTableColumns, editableColumns, scalarEditableColumns, objectEditableFields,
    columnTypes, onDrawerTabsChange, openDrawer, onDataChange, hasDrawerFormFields,
    hasNestedEditableSchema,
    effectiveMainWriteForm,
    enableWriteEffective, resolvedWritePermissions.create,
  ]);

  // Insert empty row at index 0 in nested table - used by blue "+" in drawer nested table context
  const handleAddNestedRowAtZero = useCallback((tabId) => {
    if (!tabId) return;
    if (enableWriteEffective && !resolvedWritePermissions.create) {
      if (onDataChange) {
        onDataChange({
          severity: 'warn',
          summary: 'Cannot add row',
          detail: 'Creating new rows is not allowed for this configuration.',
          life: 4000,
        });
      }
      return;
    }
    const tab = (effectiveDrawerTabs || []).find(t => t.id === tabId);
    const cols = tab?.columns && isArray(tab.columns) ? tab.columns : [];
    const colTypes = columnTypes || {};
    const emptyRow = {};
    cols.forEach((col) => {
      const t = colTypes[col] || 'string';
      if (t === 'number') emptyRow[col] = null;
      else if (t === 'boolean') emptyRow[col] = false;
      else if (t === 'date') emptyRow[col] = null;
      else emptyRow[col] = '';
    });
    const withKey = addEditingKeysToRows([emptyRow])[0];
    const current = nestedTableEditingDataRef.current.get(tabId) || [];
    const updated = [withKey, ...current];
    nestedTableEditingDataRef.current.set(tabId, updated);
    onNestedBufferChange?.();
    setNestedTableUpdateCounter(c => c + 1);
  }, [effectiveDrawerTabs, columnTypes, addEditingKeysToRows, onNestedBufferChange, enableWriteEffective, resolvedWritePermissions.create, onDataChange]);

  // Export helper functions
  const formatHeaderName = useCallback((key) => {
    if (!key || key === null || key === undefined) {
      return '';
    }
    const sKey = String(key);
    const percentageConfig = percentageColumns.find((pc) => pc.columnName === key);
    if (percentageConfig) {
      return percentageConfig.columnName;
    }
    const normalized = sKey.split('__').join(' ').split('_').join(' ').trim();
    if (!normalized) {
      return '';
    }
    // lodash startCase drops punctuation-only tokens (e.g. "Inv %" -> "Inv"). Title-case
    // alphanumeric segments only; keep segments that contain symbols as-is.
    return normalized
      .split(/\s+/)
      .map((seg) => {
        if (!seg) return '';
        if (/[^\p{L}\p{N}]/u.test(seg)) {
          return seg;
        }
        return startCase(seg);
      })
      .filter(Boolean)
      .join(' ');
  }, [percentageColumns]);

  const isTruthyBoolean = useCallback((value) => {
    return value === true || value === 1 || value === '1';
  }, []);

  // Helper to convert columnTypes string format to flag format for export
  const getColumnTypeFlags = useCallback((col) => {
    const typeString = columnTypes[col] || 'string';
    return {
      isBoolean: typeString === 'boolean',
      isNumeric: typeString === 'number',
      isDate: typeString === 'date',
      isText: typeString === 'string'
    };
  }, [columnTypes]);

  // Sanitize sheet name for Excel (max 31 chars, exclude \ / * ? [ ])
  const sanitizeSheetName = useCallback((name) => {
    if (!name || typeof name !== 'string') return 'Sheet';
    const sanitized = String(name).replace(/[\\/*?[\]]/g, '_').trim();
    return sanitized ? sanitized.slice(0, 31) : 'Sheet';
  }, []);

  // Collect all summary rows at a given group level from the tree
  const collectSummaryRowsAtLevel = useCallback((data, levelIndex, acc = []) => {
    if (!isArray(data)) return acc;
    data.forEach((row) => {
      if (!row || !row.__isGroupRow__) return;
      const rowLevel = row.__groupLevel__ ?? 0;
      if (rowLevel === levelIndex) {
        acc.push(row);
      } else if (rowLevel < levelIndex && row.__groupRows__) {
        const groupRows = row.__groupRows__.filter((r) => r?.__isGroupRow__);
        collectSummaryRowsAtLevel(groupRows, levelIndex, acc);
      }
    });
    return acc;
  }, []);

  // Export to XLSX: optional overrides use per-slot pipeline data when multi-slot. Grouped export with no level arg opens popup; ref stores overrides for Confirm.
  const runExportToXLSX = useCallback((selectedLevelIndices, overrides) => {
    const ov = overrides && typeof overrides === 'object' ? overrides : null;
    const resolvedReportData = ov && 'reportData' in ov ? ov.reportData : reportDataWithDerived;
    const resolvedSortedData = ov?.sortedData ?? sortedData;
    const resolvedGroupedData = ov?.groupedData ?? groupedData;
    const resolvedGroupFields = Array.isArray(ov?.effectiveGroupFields) ? ov.effectiveGroupFields : effectiveGroupFields;
    const resolvedDerivedColumns = ov?.derivedColumns ?? effectiveMainConfig?.derivedColumns ?? derivedColumns ?? [];
    const resolvedPctColumns = ov?.percentageColumns ?? effectiveMainConfig?.percentageColumns;
    const resolvedHasPct = ov?.hasPercentageColumns ?? hasPercentageColumns;
    const resolvedColumnTypes = ov?.columnTypes ?? columnTypes;
    const resolvedColumns = ov?.columns ?? filteredColumns;
    const resolvedVisibleColumns = ov?.visibleColumns ?? tableVisibleColumns;
    const resolvedAllowedColumns = ov?.allowedColumns ?? allowedColumns;
    const resolvedPctColNames = ov?.percentageColumnNames ?? percentageColumnNames;

    const uiColumnOrder = getOrderedDisplayColumns({
      columns: resolvedColumns,
      visibleColumns: resolvedVisibleColumns,
      effectiveGroupFields: resolvedGroupFields,
      hasPercentageColumns: resolvedHasPct,
      percentageColumns: resolvedPctColumns || [],
      percentageColumnNames: resolvedPctColNames,
      allowedColumns: resolvedAllowedColumns,
    });

    const getColTypeFlagsForExport = (col) => {
      const typeString = resolvedColumnTypes[col] || 'string';
      return {
        isBoolean: typeString === 'boolean',
        isNumeric: typeString === 'number',
        isDate: typeString === 'date',
        isText: typeString === 'string'
      };
    };

    const isPctColumnForExport = (col) =>
      resolvedHasPct && resolvedPctColumns?.some((pc) => pc?.columnName === col);

    const getPctValueForExport = (rowData, columnName) => {
      const config = resolvedPctColumns?.find((pc) => pc.columnName === columnName);
      if (!config || !config.targetField || !config.valueField) return null;
      const targetValue = getDataValue(rowData, config.targetField);
      const actualValue = getDataValue(rowData, config.valueField);
      const targetNum = isNumber(targetValue) ? targetValue : (isNil(targetValue) ? null : toNumber(targetValue));
      const actualNum = isNumber(actualValue) ? actualValue : (isNil(actualValue) ? null : toNumber(actualValue));
      if (!isNil(targetNum) && !isNil(actualNum) && !_isNaN(targetNum) && !_isNaN(actualNum) && _isFinite(targetNum) && _isFinite(actualNum) && targetNum !== 0) {
        return (actualNum / targetNum) * 100;
      }
      return null;
    };

    const getExportCellValue = (row, col) => {
      const breakdown = row?.__stringBreakdown__?.[col];
      if (isArray(breakdown) && breakdown.length > 0) {
        return formatStringBreakdownForExcel(breakdown);
      }
      let value = getDataValue(row, col);
      if (isNil(value) && isPctColumnForExport(col)) {
        value = getPctValueForExport(row, col);
      }
      const colTypeFlags = getColTypeFlagsForExport(col);
      if (isNil(value)) {
        return '';
      }
      if (colTypeFlags.isBoolean) {
        return isTruthyBoolean(value) ? 'Yes' : 'No';
      }
      if (colTypeFlags.isDate) {
        return formatDateValue(value);
      }
      const isPctCol = isPctColumnForExport(col);
      const isNumeric = isPctCol || colTypeFlags.isNumeric || (typeof value === 'number' && Number.isFinite(value));
      if (isNumeric) {
        const numeric = typeof value === 'number' ? value : parseFloat(String(value).replace(/,/g, ''));
        return Number.isFinite(numeric) ? numeric : String(value);
      }
      return String(value);
    };

    const formatRowForExport = (row, cols) => {
      const exportRow = {};
      cols.forEach((col) => {
        exportRow[formatHeaderName(col)] = getExportCellValue(row, col);
      });
      return exportRow;
    };

    const outerReportGroupField = resolvedGroupFields[0] ?? null;
    const allowedForReportExport =
      getAllowedForScope(resolvedAllowedColumns, 'report') ?? getAllowedForScope(resolvedAllowedColumns, 'main');
    const reportIncludeGroupColumn =
      !allowedForReportExport || allowedForReportExport.length === 0
        ? true
        : new Set(allowedForReportExport).has(outerReportGroupField);

    // Report mode — same level-picker UX as grouped export when multiple group fields exist
    if (enableBreakdown && resolvedReportData) {
      const fullGF = resolvedGroupFields;
      if (
        fullGF.length > 0 &&
        (!Array.isArray(selectedLevelIndices) || selectedLevelIndices.length === 0)
      ) {
        exportGroupOverridesRef.current = ov;
        setExportDialogGroupFields(fullGF);
        setExportGroupSelectorSelectedLevels(fullGF.map((_, i) => i));
        setExportGroupSelectorVisible(true);
        return;
      }

      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `export_${dateStr}.xlsx`;
      const wb = XLSX.utils.book_new();

      if (fullGF.length > 0) {
        const indices =
          Array.isArray(selectedLevelIndices) && selectedLevelIndices.length > 0
            ? [...selectedLevelIndices].sort((a, b) => a - b)
            : [Math.max(0, fullGF.length - 1)];
        const usedSheetNames = new Set();
        indices.forEach((levelIndex) => {
          const safeLevel = Math.min(Math.max(0, levelIndex), fullGF.length - 1);
          let sheetName = sanitizeSheetName(formatHeaderName(fullGF[safeLevel]));
          let n = 1;
          while (usedSheetNames.has(sheetName)) {
            const suffix = `_${n}`;
            sheetName = sanitizeSheetName(
              `${formatHeaderName(fullGF[safeLevel])}${suffix}`.slice(0, 31)
            );
            n += 1;
          }
          usedSheetNames.add(sheetName);
          appendReportLevelSheet(
            wb,
            sheetName,
            resolvedReportData,
            columnGroupBy,
            fullGF,
            safeLevel,
            formatHeaderName,
            reportIncludeGroupColumn
          );
        });
      } else {
        appendReportLevelSheet(
          wb,
          'Sheet1',
          resolvedReportData,
          columnGroupBy,
          fullGF,
          0,
          formatHeaderName,
          reportIncludeGroupColumn
        );
      }

      XLSX.writeFile(wb, filename);
      setExportGroupSelectorVisible(false);
      exportGroupOverridesRef.current = null;
      return;
    }

    // Grouped mode: no args = open popup; with args = multi-sheet export
    if (resolvedGroupFields.length > 0 && !isEmpty(resolvedGroupedData)) {
      if (!Array.isArray(selectedLevelIndices) || selectedLevelIndices.length === 0) {
        exportGroupOverridesRef.current = ov;
        setExportDialogGroupFields(resolvedGroupFields);
        setExportGroupSelectorSelectedLevels(resolvedGroupFields.map((_, i) => i));
        setExportGroupSelectorVisible(true);
        return;
      }
      const derivedColNamesMain = getDerivedColumnNames(resolvedDerivedColumns || [], 'main');
      const wb = XLSX.utils.book_new();
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `export_${dateStr}.xlsx`;

      selectedLevelIndices.forEach((levelIndex) => {
        const rows = collectSummaryRowsAtLevel(resolvedGroupedData, levelIndex);
        const fieldName = resolvedGroupFields[levelIndex];
        const allDataColumns = isEmpty(rows) ? [] : uniq(flatMap(rows, (item) =>
          item && typeof item === 'object' ? getDataKeys(item) : []
        ));
        const filtered = allDataColumns.filter((col) => {
          if (col.startsWith('__')) return false;
          if (resolvedGroupFields.includes(col)) {
            const colIndex = resolvedGroupFields.indexOf(col);
            return colIndex <= levelIndex;
          }
          if (isPctColumnForExport(col)) return true;
          if (derivedColNamesMain.includes(col)) return true;
          if (rows.some((r) => isArray(r?.__stringBreakdown__?.[col]) && r.__stringBreakdown__[col].length > 0)) {
            return true;
          }
          const colTypeFlags = getColTypeFlagsForExport(col);
          return colTypeFlags.isNumeric;
        });
        const pivotCols = resolvedGroupFields.slice(0, levelIndex + 1).filter((c) => filtered.includes(c));
        const otherRaw = filtered.filter((c) => !resolvedGroupFields.includes(c));
        const otherCols = alignExportColumnsToUiOrder(uiColumnOrder, new Set(otherRaw));
        const allColumns = [...pivotCols, ...otherCols];
        const exportData = rows.map((row) => formatRowForExport(row, allColumns));
        const sheetName = sanitizeSheetName(formatHeaderName(fieldName));
        const ws = XLSX.utils.json_to_sheet(exportData);
        XLSX.utils.book_append_sheet(wb, ws, sheetName);
      });

      XLSX.writeFile(wb, filename);
      setExportGroupSelectorVisible(false);
      exportGroupOverridesRef.current = null;
      return;
    }

    // Regular export (non-grouped)
    let dataToExport;
    let allColumnsExport;

    if (resolvedHasPct && resolvedPctColumns) {
      dataToExport = resolvedSortedData.map((row) => {
        const rowWithPercentages = { ...row };
        resolvedPctColumns.forEach((pc) => {
          if (pc.columnName && pc.targetField && pc.valueField) {
            const percentageValue = getPctValueForExport(row, pc.columnName);
            rowWithPercentages[pc.columnName] = percentageValue;
          }
        });
        return rowWithPercentages;
      });
    } else {
      dataToExport = resolvedSortedData;
    }

    const dataColSet = new Set();
    if (!isEmpty(dataToExport)) {
      dataToExport.forEach((item) => {
        if (item && typeof item === 'object') {
          getDataKeys(item).forEach((k) => dataColSet.add(k));
        }
      });
    }
    const percentageColNames = resolvedHasPct && resolvedPctColumns
      ? resolvedPctColumns.map((pc) => pc.columnName).filter(Boolean)
      : [];
    const derivedColNames = getDerivedColumnNames(resolvedDerivedColumns || [], 'main');
    const allColSet = new Set([...dataColSet, ...percentageColNames, ...derivedColNames]);
    allColumnsExport = alignExportColumnsToUiOrder(uiColumnOrder, allColSet);

    const exportData = dataToExport.map((row) => {
      const exportRow = {};
      allColumnsExport.forEach((col) => {
        if (typeof col === 'string' && col.startsWith('__')) return;
        exportRow[formatHeaderName(col)] = getExportCellValue(row, col);
      });
      return exportRow;
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `export_${dateStr}.xlsx`;

    XLSX.writeFile(wb, filename);
  }, [
    enableBreakdown, reportDataWithDerived, columnGroupBy, sortedData, groupedData, effectiveGroupFields,
    hasPercentageColumns, percentageColumns, percentageColumnNames, effectiveMainConfig?.derivedColumns, effectiveMainConfig?.percentageColumns,
    derivedColumns, columnTypes, filteredColumns, tableVisibleColumns, allowedColumns,
    formatHeaderName, isTruthyBoolean, formatDateValue, collectSummaryRowsAtLevel, sanitizeSheetName,
    setExportDialogGroupFields, setExportGroupSelectorSelectedLevels, setExportGroupSelectorVisible,
  ]);

  const exportToXLSX = useCallback(
    (selectedLevelIndices) => runExportToXLSX(selectedLevelIndices, null),
    [runExportToXLSX]
  );

  // Create slot-scoped context (flat object for each slot; for single-slot, all slots share same data)
  const slotContextData = useMemo(() => {
    try {
      return {
        rawData: mainTableEditingData, // Use editingData state for reactivity (triggers updates when changed)
        columns: filteredColumns, // Expose filtered columns (respecting allowedColumns)
        columnTypes,
        columnTypesOverride: mainColumnTypesOverride,
        jsonObjectColumns,
        filteredData,
        groupedData,
        sortedData: sortedDataWithEdits,
        paginatedData: paginatedDataWithEdits,
        sums: calculateSums,
        getSums,
        filterOptions: optionColumnValues,
        multiselectColumns,
        hasPercentageColumns,
        percentageColumns: effectiveMainConfig.percentageColumns,
        percentageColumnNames,
        isPercentageColumn,
        derivedColumns: effectiveMainConfig.derivedColumns,
        getPercentageColumnValue,
        getPercentageColumnSortFunction,
        filters: tableFilters,
        sortMeta: tableSortMeta,
        pagination: tablePagination,
        expandedRows: tableExpandedRows,
        visibleColumns: tableVisibleColumns,
        enableSort: effectiveMainConfig.enableSort,
        enableFilter: effectiveMainConfig.enableFilter,
        enableSummation: effectiveMainConfig.enableSummation,
        enableGrouping: effectiveMainConfig.enableGrouping,
        textFilterColumns: effectiveMainConfig.textFilterColumns,
        effectiveGroupFields, // Array of group fields for multi-level nesting
        allowedColumns, // Full object/array for getAllowedForGroupField, getAllowedForScope('nested')
        redFields: effectiveMainConfig.redFields,
        greenFields: effectiveMainConfig.greenFields,
        rowColumnStyles: effectiveMainConfig.rowColumnStyles,
        enableDivideBy1Lakh, // shared
        enableReport, // shared
        enableBreakdown,
        reportData: reportDataWithDerived,
        isComputingReport,
        isApplyingFilterSort,
        chartColumns, // shared
        chartHeight, // shared
        // Unified loading state (includes query cache + async derivedRows merge before table paints)
        isLoading: (() => {
          const offlineComputing = !dataSource && offlineData?.length > 0 && !offlineDataExecuted;
          return (
            isComputingReport ||
            isApplyingFilterSort ||
            offlineComputing ||
            derivedRowsLoading ||
            executingQuery ||
            loadingFromCache
          );
        })(),
        loadingText: (() => {
          if (isComputingReport) return 'Computing report...';
          if (isApplyingFilterSort) return 'Applying Filter and Sort...';
          if (!dataSource && offlineData?.length > 0 && !offlineDataExecuted) return 'Computing groups...';
          if (derivedRowsLoading) return 'Merging related rows...';
          if (executingQuery) return 'Loading data...';
          if (loadingFromCache) return 'Loading from cache...';
          return '';
        })(),
        columnGroupBy,
        updateFilter,
        clearFilter,
        clearAllFilters,
        updateSort,
        updatePagination,
        updateExpandedRows,
        updateVisibleColumns,
        drawerVisible,
        drawerData,
        drawerTabs: effectiveMainConfig.drawerTabs,
        activeDrawerTabIndex,
        clickedDrawerValues,
        openDrawer,
        openDrawerWithData,
        openDrawerForOuterGroup,
        openDrawerForInnerGroup,
        openDrawerWithJsonTables,
        openDrawerForRow,
        openDrawerForNewRow,
        handleAddNestedRowAtZero: parentHandleAddNestedRowAtZero || handleAddNestedRowAtZero,
        closeDrawer,
        addDrawerTab,
        removeDrawerTab,
        updateDrawerTab,
        setActiveDrawerTabIndex,
        selectedRowData,
        setSelectedRowData: setSelectedRowDataWithFormSync,
        formatDateValue,
        formatHeaderName,
        isTruthyBoolean,
        exportToXLSX,
        parseNumericFilter,
        applyNumericFilter,
        applyDateFilter,
        isNumericValue,
        // Search and sort props
        clientSave: currentQueryDoc?.clientSave || false,
        searchFields: currentQueryDoc?.searchFields || null,
        sortFields: currentQueryDoc?.sortFields || null,
        searchTerm,
        setSearchTerm,
        sortConfig,
        setSortConfig,
        // Sync / freshness (exposed for custom header controls, e.g. the Views variant's refresh pill)
        handleSync,
        handleHardRefresh,
        lastUpdatedAt,
        formatLastUpdatedDate,
        // Opens the native Filter/Sort sidebar (the Views variant's compact pill uses this).
        // openFilterSortSidebar({ sortOnly: true }) shows just the Sort pane.
        setFilterSortSidebarVisible,
        openFilterSortSidebar,
        // Enable write flag - use forceEnableWrite if provided (for nested drawer tables), otherwise use currentQueryDoc
        enableWrite: forceEnableWrite !== undefined ? forceEnableWrite : (currentQueryDoc?.enableWrite || false),
        writePermissions: resolvedWritePermissions,
        groupDrawerAccess: effectiveMainConfig.groupDrawerAccess,
        // Nested table context for editable columns lookup
        parentColumnName,
        nestedTableFieldName,
        nestedTableTabId,
        // Change tracking for nested tables
        updateCurrentNestedTableData,
        getChangedRowsForTab,
        getAllChangedNestedTableRows,
        // Use parent's handleDrawerSave if available (for nested drawer tables), otherwise use local one
        handleDrawerSave: parentHandleDrawerSave || handleDrawerSave,
        handleMainSave,
        handleMainCancel,
        handleDrawerCancel,
        hasMainTableChanges,
        hasDrawerChanges,
        // Main table editing buffer update function
        updateMainTableEditingData,
        // Read-only access to original buffer for comparison
        mainTableOriginalData: mainTableOriginalDataRef.current,
        // queryFunction: execute a query and return processed data (similar to transformer). Used by formInputOverride getOptions.
        queryFunction,
        // formInputOverride: per-column override for inline cell editors (Select, Checkbox, etc.)
        formInputOverride: formInputOverride ?? {},
        // selectOptionsCache: pre-fetched options for Select editors (main|col or parentCol|col) - from Zustand store
        selectOptionsCache,
        // Provider-level state (exposed so children/DataTableControls can read from context)
        dataSource,
        selectedQueryKey,
        executingQuery,
        availableQueryKeys,
        resolvedConfig,
        // DataTable display fields (from config, consumed by DataTableNew via context)
        rowsPerPageOptions,
        defaultRows,
        tableHeight,
        scrollable,
        enableFullscreenDialog,
        enableCellEdit: effectiveMainConfig.enableCellEdit,
        editableColumns,
      };
    } catch (error) {
      console.error('DataProviderNew: Error creating slotContextData', error);
      return {};
    }
  }, [
    sortedDataWithEdits, columns, columnTypes, filteredData, groupedData, paginatedDataWithEdits,
    calculateSums, getSums, optionColumnValues, multiselectColumns, hasPercentageColumns, percentageColumnNames,
    isPercentageColumn, getPercentageColumnValue, getPercentageColumnSortFunction, tableFilters, tableSortMeta, tablePagination,
    tableExpandedRows, tableVisibleColumns, effectiveGroupFields,
    updateFilter, clearFilter, clearAllFilters, updateSort, updatePagination, updateExpandedRows,
    updateVisibleColumns, drawerVisible, drawerData, activeDrawerTabIndex, clickedDrawerValues,
    openDrawer, openDrawerWithData, openDrawerForOuterGroup, openDrawerForInnerGroup, openDrawerWithJsonTables, openDrawerForRow, openDrawerForNewRow, handleAddNestedRowAtZero, closeDrawer, addDrawerTab, removeDrawerTab, updateDrawerTab,
    selectedRowData, setSelectedRowDataWithFormSync,
    formatHeaderName, isTruthyBoolean, exportToXLSX, isNumericValue, currentQueryDoc, searchTerm, sortConfig, enableBreakdown, reportData, isComputingReport, isApplyingFilterSort, derivedRowsLoading, executingQuery, loadingFromCache, columnGroupBy, filteredColumns, parentColumnName, nestedTableFieldName, nestedTableTabId,
    updateCurrentNestedTableData, getChangedRowsForTab, getAllChangedNestedTableRows, handleDrawerSave, handleMainSave, handleMainCancel, handleDrawerCancel, hasMainTableChanges, hasDrawerChanges, updateMainTableEditingData, forceEnableWrite, parentHandleDrawerSave, parentHandleAddNestedRowAtZero, addEditingKeysToRows, mainTableEditingData,
    queryFunction, effectiveMainConfig, mainColumnTypesOverride, jsonObjectColumns, enableDivideBy1Lakh, enableReport, chartColumns, chartHeight,
    dataSource, offlineData, offlineDataExecuted, formInputOverride, selectOptionsCache,
    selectedQueryKey, executingQuery, availableQueryKeys, resolvedConfig,
    handleSync, handleHardRefresh, lastUpdatedAt, openFilterSortSidebar,
    rowsPerPageOptions, defaultRows, tableHeight, scrollable, enableFullscreenDialog,
    resolvedWritePermissions,
  ]);

  // When multi-slot, build per-slot context from pipelinesBySlot with slot-scoped handlers
  const slotContextMap = useMemo(() => {
    if (!isMultiSlot || !pipelinesBySlot || Object.keys(pipelinesBySlot).length === 0) return {};
    const map = {};
    for (const slotId of slotIds) {
      const pSlot = pipelinesBySlot[slotId];
      if (!pSlot) continue;
      const slotConfig = slots[slotId] ?? {};
      const slotWriteForm = normalizeWriteForm(slotConfig.writeForm);
      const slotRuntime = materializeWriteFormRuntime(slotWriteForm);
      const effectiveSlotConfig = { ...effectiveMainConfig, ...slotConfig };
      const slotFilters = tableFiltersBySlot[slotId] ?? {};
      const slotSortMeta = tableSortMetaBySlot[slotId] ?? [];
      const slotPagination = tablePaginationBySlot[slotId] ?? { first: 0, rows: 10 };
      const slotExpandedRows = tableExpandedRowsBySlot[slotId] ?? null;
      const slotVisibleColumns = tableVisibleColumnsBySlot[slotId] ?? tableVisibleColumns ?? [];
      const meta = pSlot.pipelineColumnMeta || {};
      const slotFilteredData = pSlot.filteredData ?? [];
      const getSumsForSlot = (dataOrFilters, filters) => {
        if (dataOrFilters === undefined && filters === undefined) return getSums(slotFilteredData);
        if (isArray(dataOrFilters)) return getSums(dataOrFilters, filters);
        return getSums(slotFilteredData, dataOrFilters);
      };
      const slotCalculateSums = getSumsForSlot();
      const slotReportData = reportDataBySlot && reportDataBySlot[slotId];
      let slotGroupedData = pSlot.groupedData;
      let slotSortedData = pSlot.sortedData;
      let slotPaginatedData = pSlot.paginatedData;
      if (slotReportData && slotReportData.tableData && isArray(slotReportData.tableData)) {
        let reportRowsForSlot = slotReportData.tableData;
        reportRowsForSlot = !isEmpty(slotSortMeta) && enableBreakdown
          ? orderBy(
              reportRowsForSlot,
              slotSortMeta.map((s) => s.field),
              slotSortMeta.map((s) => (s.order === 1 ? 'asc' : 'desc'))
            )
          : [...reportRowsForSlot];
        reportRowsForSlot = filterReportRowsByMetricFilters(
          reportRowsForSlot,
          slotFilters,
          slotReportData.metrics,
          getDataValue
        );
        slotGroupedData = reportRowsForSlot;
        slotSortedData = reportRowsForSlot;
        const first = slotPagination?.first ?? 0;
        const rowsPerPage = slotPagination?.rows ?? 10;
        slotPaginatedData = isArray(slotSortedData)
          ? slotSortedData.slice(first, first + rowsPerPage)
          : [];
      }
      map[slotId] = {
        rawData: mainTableEditingData,
        columns: meta.filteredColumns ?? [],
        columnTypes: meta.columnTypes ?? columnTypes,
        columnTypesOverride: slotConfig.columnTypesOverride && typeof slotConfig.columnTypesOverride === 'object'
          ? slotConfig.columnTypesOverride
          : {},
        filteredData: pSlot.filteredData,
        groupedData: slotGroupedData,
        sortedData: slotSortedData,
        paginatedData: slotPaginatedData,
        sums: slotCalculateSums,
        getSums: getSumsForSlot,
        filterOptions: pSlot.optionColumnValues ?? {},
        multiselectColumns: meta.multiselectColumns ?? multiselectColumns,
        hasPercentageColumns: meta.hasPercentageColumns ?? hasPercentageColumns,
        percentageColumns: effectiveSlotConfig.percentageColumns,
        percentageColumnNames: meta.percentageColumnNames ?? percentageColumnNames,
        isPercentageColumn: (col) => (meta.hasPercentageColumns && (effectiveSlotConfig.percentageColumns || []).some((pc) => pc?.columnName === col)),
        derivedColumns: effectiveSlotConfig.derivedColumns,
        getPercentageColumnValue,
        getPercentageColumnSortFunction,
        filters: slotFilters,
        sortMeta: slotSortMeta,
        pagination: slotPagination,
        expandedRows: slotExpandedRows,
        visibleColumns: slotVisibleColumns,
        enableSort: effectiveSlotConfig.enableSort,
        enableFilter: effectiveSlotConfig.enableFilter,
        enableSummation: effectiveSlotConfig.enableSummation,
        enableGrouping: effectiveSlotConfig.enableGrouping,
        textFilterColumns: effectiveSlotConfig.textFilterColumns,
        effectiveGroupFields: pSlot.effectiveGroupFields ?? [],
        allowedColumns: effectiveSlotConfig.allowedColumns ?? allowedColumns,
        redFields: effectiveSlotConfig.redFields,
        greenFields: effectiveSlotConfig.greenFields,
        rowColumnStyles: effectiveSlotConfig.rowColumnStyles,
        enableDivideBy1Lakh,
        enableReport,
        enableBreakdown,
        reportData: slotReportData ?? reportDataWithDerived,
        isComputingReport,
        isApplyingFilterSort,
        chartColumns,
        chartHeight,
        isLoading: (() => {
          const offlineComputing = !dataSource && offlineData?.length > 0 && !offlineDataExecuted;
          return (
            isComputingReport ||
            isApplyingFilterSort ||
            offlineComputing ||
            derivedRowsLoading ||
            executingQuery ||
            loadingFromCache
          );
        })(),
        loadingText: (() => {
          if (isComputingReport) return 'Computing report...';
          if (isApplyingFilterSort) return 'Applying Filter and Sort...';
          if (!dataSource && offlineData?.length > 0 && !offlineDataExecuted) return 'Computing groups...';
          if (derivedRowsLoading) return 'Merging related rows...';
          if (executingQuery) return 'Loading data...';
          if (loadingFromCache) return 'Loading from cache...';
          return '';
        })(),
        columnGroupBy,
        updateFilter: (col, val) => updateFilterForSlot(slotId, col, val),
        clearFilter: (col) => clearFilterForSlot(slotId, col),
        clearAllFilters: () => clearAllFiltersForSlot(slotId),
        updateSort: (sortMeta) => updateSortForSlot(slotId, sortMeta),
        updatePagination: (first, rows) => updatePaginationForSlot(slotId, first, rows),
        updateExpandedRows: (rows) => updateExpandedRowsForSlot(slotId, rows),
        updateVisibleColumns: (cols) => updateVisibleColumnsForSlot(slotId, cols),
        drawerVisible,
        drawerData,
        drawerTabs: effectiveSlotConfig.drawerTabs,
        activeDrawerTabIndex,
        clickedDrawerValues,
        openDrawer,
        openDrawerWithData,
        openDrawerForOuterGroup,
        openDrawerForInnerGroup,
        openDrawerWithJsonTables,
        openDrawerForRow,
        openDrawerForNewRow,
        handleAddNestedRowAtZero: parentHandleAddNestedRowAtZero || handleAddNestedRowAtZero,
        closeDrawer,
        addDrawerTab,
        removeDrawerTab,
        updateDrawerTab,
        setActiveDrawerTabIndex,
        selectedRowData,
        setSelectedRowData: setSelectedRowDataWithFormSync,
        formatDateValue,
        formatHeaderName,
        isTruthyBoolean,
        exportToXLSX: (selectedLevelIndices) => runExportToXLSX(selectedLevelIndices, {
          reportData: slotReportData ?? reportDataWithDerived,
          sortedData: slotSortedData,
          groupedData: slotGroupedData,
          effectiveGroupFields: pSlot.effectiveGroupFields ?? [],
          derivedColumns: effectiveSlotConfig.derivedColumns,
          percentageColumns: effectiveSlotConfig.percentageColumns,
          hasPercentageColumns: meta.hasPercentageColumns ?? hasPercentageColumns,
          columnTypes: meta.columnTypes ?? columnTypes,
          columns: meta.filteredColumns ?? [],
          visibleColumns: slotVisibleColumns,
          allowedColumns: effectiveSlotConfig.allowedColumns ?? allowedColumns,
          percentageColumnNames: meta.percentageColumnNames ?? percentageColumnNames,
        }),
        parseNumericFilter,
        applyNumericFilter,
        applyDateFilter,
        isNumericValue,
        clientSave: currentQueryDoc?.clientSave || false,
        searchFields: currentQueryDoc?.searchFields || null,
        sortFields: currentQueryDoc?.sortFields || null,
        searchTerm,
        setSearchTerm,
        sortConfig,
        setSortConfig,
        handleSync,
        handleHardRefresh,
        lastUpdatedAt,
        formatLastUpdatedDate,
        setFilterSortSidebarVisible,
        openFilterSortSidebar,
        enableWrite: forceEnableWrite !== undefined ? forceEnableWrite : (currentQueryDoc?.enableWrite || false),
        writePermissions: resolveWritePermissions(enableWriteEffective, effectiveSlotConfig.writePermissions ?? resolvedConfig.writePermissions),
        groupDrawerAccess: effectiveSlotConfig.groupDrawerAccess,
        parentColumnName,
        nestedTableFieldName,
        nestedTableTabId,
        updateCurrentNestedTableData,
        getChangedRowsForTab,
        getAllChangedNestedTableRows,
        handleDrawerSave: parentHandleDrawerSave || handleDrawerSave,
        handleMainSave,
        handleMainCancel,
        handleDrawerCancel,
        hasMainTableChanges,
        hasDrawerChanges,
        updateMainTableEditingData,
        mainTableOriginalData: mainTableOriginalDataRef.current,
        queryFunction,
        formInputOverride: slotRuntime.formInputOverride,
        selectOptionsCache,
        dataSource,
        selectedQueryKey,
        executingQuery,
        availableQueryKeys,
        resolvedConfig,
        rowsPerPageOptions,
        defaultRows,
        tableHeight,
        scrollable,
        enableFullscreenDialog,
        enableCellEdit: effectiveSlotConfig.enableCellEdit,
        editableColumns: slotRuntime.editableColumns,
      };
    }
    return map;
  }, [
    isMultiSlot, slotIds, pipelinesBySlot, slots, effectiveMainConfig, allowedColumns, reportDataBySlot, reportDataWithDerived,
    tableFiltersBySlot, tableSortMetaBySlot, tablePaginationBySlot, tableExpandedRowsBySlot, tableVisibleColumnsBySlot, tableVisibleColumns,
    updateFilterForSlot, clearFilterForSlot, clearAllFiltersForSlot, updateSortForSlot, updatePaginationForSlot, updateExpandedRowsForSlot, updateVisibleColumnsForSlot,
    getSums, mainTableEditingData, columnTypes, multiselectColumns, hasPercentageColumns, percentageColumnNames, getPercentageColumnValue, getPercentageColumnSortFunction,
    reportDataWithDerived, isComputingReport, isApplyingFilterSort, derivedRowsLoading, executingQuery, loadingFromCache, chartColumns, chartHeight, columnGroupBy,
    drawerVisible, drawerData, activeDrawerTabIndex, clickedDrawerValues,
    openDrawer, openDrawerWithData, openDrawerForOuterGroup, openDrawerForInnerGroup, openDrawerWithJsonTables, openDrawerForRow, openDrawerForNewRow,
    parentHandleAddNestedRowAtZero, selectedRowData, setSelectedRowDataWithFormSync,
    formatDateValue, formatHeaderName, isTruthyBoolean, runExportToXLSX, isNumericValue,
    currentQueryDoc, searchTerm, sortConfig, forceEnableWrite, parentColumnName, nestedTableFieldName, nestedTableTabId,
    updateCurrentNestedTableData, getChangedRowsForTab, getAllChangedNestedTableRows, parentHandleDrawerSave,
    handleMainSave, handleMainCancel, handleDrawerCancel, hasMainTableChanges, hasDrawerChanges, updateMainTableEditingData,
    queryFunction, formInputOverride,
    dataSource, offlineData, offlineDataExecuted,
    selectOptionsCache,
    selectedQueryKey, executingQuery, availableQueryKeys, resolvedConfig,
    handleSync, handleHardRefresh, lastUpdatedAt, openFilterSortSidebar,
    rowsPerPageOptions, defaultRows, tableHeight, scrollable, enableFullscreenDialog,
    enableWriteEffective, resolvedWritePermissions,
  ]);

  // Build single context as slot map: { main: {...}, salesTeamHq: {...}, ... }
  const contextValue = useMemo(() => {
    const singleData = slotContextData || {};
    const multiMap = slotContextMap || {};
    if (isMultiSlot && Object.keys(multiMap).length > 0) {
      return multiMap;
    }
    return { main: singleData };
  }, [slotContextData, slotContextMap, isMultiSlot]);

  // Memoize field display names to avoid recalculating on every render
  const fieldDisplayNames = useMemo(() => {
    const names = {};
    const searchFields = currentQueryDoc?.searchFields || {};
    for (const topLevelKey of Object.keys(searchFields)) {
      const nestedPaths = searchFields[topLevelKey];
      if (Array.isArray(nestedPaths)) {
        for (const nestedPath of nestedPaths) {
          const key = nestedPath || topLevelKey;
          // Use only the last path segment for the label — a multi-level
          // nested path (e.g. a field inside a list field) shouldn't render
          // its full dotted string.
          const lastSegment = nestedPath ? nestedPath.split('.').pop() : topLevelKey;
          names[key] = startCase(lastSegment);
        }
      }
    }
    return names;
  }, [currentQueryDoc?.searchFields]);

  // Determine picker mode based on enableBreakdown, breakdownType, and columnGroupBy
  const getPickerMode = () => {
    if (!enableBreakdown) return 'month'; // Keep current behavior when breakdown is off
    if (columnGroupBy === 'period-over-period') return 'year'; // Override for period-over-period
    // Map breakdownType to mode
    switch (breakdownType) {
      case 'month': return 'month';
      case 'week': return 'week';
      case 'day': return 'date';
      case 'quarter': return 'quarter';
      case 'annual': return 'year';
      default: return 'month';
    }
  };

  const pickerMode = getPickerMode();

  // Get placeholder based on mode
  const getPickerPlaceholder = () => {
    switch (pickerMode) {
      case 'month': return ['Start month', 'End month'];
      case 'week': return ['Start week', 'End week'];
      case 'date': return ['Start date', 'End date'];
      case 'quarter': return ['Start quarter', 'End quarter'];
      case 'year': return ['Start year', 'End year'];
      default: return ['Start month', 'End month'];
    }
  };

  // Conditional rendering helpers
  const isValidMonthRange = monthRange && Array.isArray(monthRange) && monthRange.length === 2;
  const headerEnabled = showProviderHeader !== false;

  const handleMonthRangeChange = useCallback((dates) => {
    const applyChange = () => {
      if (dates && dates[0] && dates[1]) {
        setMonthRange([dates[0], dates[1]]);
      } else {
        setMonthRange(null);
      }
    };
    if (hasMainTableChanges) {
      confirmDialog({
        header: 'Unsaved changes',
        message: 'You have unsaved changes. Reload data for the new date range? Your changes will be discarded.',
        acceptLabel: 'Reload',
        rejectLabel: 'Cancel',
        acceptClassName: 'p-button-warning',
        accept: applyChange,
      });
    } else {
      applyChange();
    }
  }, [hasMainTableChanges, setMonthRange]);
  const showMonthRangePicker = headerEnabled && dataSource && hasMonthSupport;
  const showBreakdownToggle = headerEnabled && enableReport;
  const showBreakdownControls = headerEnabled && enableBreakdown && dateColumn;
  const showSyncButton = headerEnabled && dataSource; // Show sync button for all query data sources (not offline)
  const isSyncDisabled = executingQuery || (hasMonthSupport && !isValidMonthRange);
  const syncIconClass = executingQuery ? 'pi pi-spin pi-spinner' : 'pi pi-refresh';
  const lastUpdatedText = lastUpdatedAt ? formatLastUpdatedDate(lastUpdatedAt) : 'N/A';

  // Check if header should be shown (if any selectors are visible)
  const hasHeaderContent = headerEnabled && (showMonthRangePicker || showBreakdownToggle || showBreakdownControls ||
    showSyncButton);

  // Caller-supplied header content (see the headerSlots prop).
  const headerSlotTop = headerSlots?.top ?? null;
  const headerSlotLeft = headerSlots?.left ?? null;
  const headerSlotRight = headerSlots?.right ?? null;

  // Render selectors JSX with enhanced responsive classes
  const selectorsJSX = (
    <>
      <div className="flex flex-wrap items-center gap-2 sm:gap-3 md:gap-4 w-full min-w-0">
        {/* Breakdown Toggle - Only show when report is enabled */}
        {showBreakdownToggle && (
          <div className="flex items-center gap-2">
            <label className="block text-xs sm:text-sm font-medium text-gray-700 whitespace-nowrap">
              Report
            </label>
            <Switch
              checked={enableBreakdown}
              onChange={(checked) => {
                setEnableBreakdown(checked);
              }}
              size={isMobile ? 'small' : 'default'}
              disabled={isComputingReport}
            />
          </div>
        )}

        {/* Breakdown By - Only show when report is enabled, breakdown toggle is on, and date column is set */}
        {showBreakdownControls && (
          <div className="w-auto min-w-[120px]">
            <Dropdown
              value={breakdownType}
              onChange={(e) => setBreakdownType(e.value)}
              options={[
                { label: 'Month', value: 'month' },
                { label: 'Week', value: 'week' },
                { label: 'Day', value: 'day' },
                { label: 'Quarter', value: 'quarter' },
                { label: 'Year', value: 'annual' }
              ]}
              optionLabel="label"
              optionValue="value"
              className="w-full items-center"
              disabled={executingQuery}
              style={{
                fontSize: '0.875rem',
                height: '2rem',
              }}
            />
          </div>
        )}

        {/* Column Group By - Only show when report is enabled and date column is set */}
        {showBreakdownControls && (
          <div className="w-auto min-w-[120px]">
            <Dropdown
              value={columnGroupBy}
              onChange={(e) => setColumnGroupBy(e.value)}
              options={[
                { label: 'Values', value: 'values' },
                { label: startCase(dateColumn.split('__').join(' ').split('_').join(' ')), value: dateColumn },
                { label: 'Period-over-Period', value: 'period-over-period' }
              ]}
              optionLabel="label"
              optionValue="value"
              className="w-full items-center"
              disabled={executingQuery}
              style={{
                fontSize: '0.875rem',
                height: '2rem',
              }}
            />
          </div>
        )}

        {/* Filter and Sort button + applied filter buttons */}
        {currentQueryDoc?.clientSave === true &&
          (Object.keys(currentQueryDoc?.searchFields || {}).length > 0 || currentQueryDoc?.sortFields) && (
            <>
              {!hideNativeFilterSort && (
              <Button
                icon="pi pi-sliders-h"
                label="Filter / Sort"
                onClick={() => {
                  setFilterSortSidebarSortOnly(false);
                  setFilterSortSidebarVisible(true);
                }}
                className="p-button-outlined shrink-0 whitespace-nowrap"
                severity="secondary"
                style={{ height: '2rem', fontSize: '0.875rem' }}
              >
                {(() => {
                  // Calculate active filter count
                  let count = 0;
                  if (sortConfig && sortConfig.field) count += 1;
                  Object.values(preFilterValues).forEach(vals => {
                    if (Array.isArray(vals) && vals.length > 0) {
                      count += vals.length;
                    }
                  });
                  return count > 0 ? <span className="ml-2 px-2 py-0.5 bg-blue-600 text-white text-xs rounded-full">{count}</span> : null;
                })()}
              </Button>
              )}

              {/* Applied Sort Button */}
              {sortConfig && sortConfig.field && (() => {
                const fieldName = sortConfig.field.split('.').pop();
                const displayName = startCase(fieldName);
                const fieldType = columnTypes[fieldName] || 'string';
                let directionLabel = '';
                if (fieldType === 'date') {
                  directionLabel = sortConfig.direction === 'asc' ? 'Oldest to Latest' : 'Latest to Oldest';
                } else if (fieldType === 'number') {
                  directionLabel = sortConfig.direction === 'asc' ? 'Low to High' : 'High to Low';
                } else {
                  directionLabel = sortConfig.direction === 'asc' ? 'A to Z' : 'Z to A';
                }
                return (
                  <button
                    type="button"
                    onClick={() => {
                      setIsApplyingFilterSort(true);
                      setSortConfig(null);
                    }}
                    className="inline-flex items-center gap-2 px-3 py-1.5 text-xs rounded-md hover:opacity-80 transition-opacity border"
                    style={{
                      height: '2rem',
                      backgroundColor: '#db2d27',
                      color: 'white',
                      borderColor: '#db2d27'
                    }}
                    title="Remove sort"
                  >
                    <i className="pi pi-sort text-xs"></i>
                    <span>{displayName} - {directionLabel}</span>
                    <i className="pi pi-times text-xs"></i>
                  </button>
                );
              })()}

              {/* Applied Filter Value Buttons */}
              {Object.entries(preFilterValues).map(([fieldKey, values]) => {
                if (!Array.isArray(values) || values.length === 0) return null;

                // Get display name for field (use memoized map or fallback to startCase)
                const fieldDisplayName = fieldDisplayNames[fieldKey] || startCase(fieldKey);

                return values.map((value, idx) => (
                  <button
                    key={`${fieldKey}-${value}-${idx}`}
                    type="button"
                    onClick={() => {
                      setIsApplyingFilterSort(true);
                      setPreFilterValues(prev => {
                        const newValues = { ...prev };
                        if (newValues[fieldKey]) {
                          newValues[fieldKey] = newValues[fieldKey].filter(v => v !== value);
                          if (newValues[fieldKey].length === 0) {
                            delete newValues[fieldKey];
                          }
                        }
                        return newValues;
                      });
                    }}
                    className="inline-flex items-center gap-2 px-3 py-1.5 text-xs rounded-md hover:opacity-80 transition-opacity border"
                    style={{
                      height: '2rem',
                      backgroundColor: '#db2d27',
                      color: 'white',
                      borderColor: '#db2d27'
                    }}
                    title="Remove filter"
                  >
                    <i className="pi pi-filter text-xs"></i>
                    <span>{fieldDisplayName}: {value}</span>
                    <i className="pi pi-times text-xs"></i>
                  </button>
                ));
              })}
            </>
          )}

        {/* Range Picker - Only show when using saved query that supports month filtering */}
        {showMonthRangePicker && (
          <div className="flex-1 min-w-[160px] max-w-full sm:flex-none sm:w-64 md:w-72 lg:w-80">
            <RangePicker
              key={`${dataSource}-${pickerMode}`} // Force re-render when data source or mode changes
              value={monthRange}
              onChange={handleMonthRangeChange}
              placeholder={getPickerPlaceholder()}
              format="MM/YY"
              mode={pickerMode}
              disabled={executingQuery}
              className="w-full"
              style={{
                width: '100%',
                fontSize: '0.875rem',
                height: '2rem',
              }}
            />
          </div>
        )}

        {/* Last Updated at with Sync button - Show when using saved query */}
        {showSyncButton && (
          <div className="flex-1 min-w-[140px] max-w-full sm:flex-none sm:w-auto">
            <SplitButton
              outlined
              severity="secondary"
              label={<span style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{lastUpdatedText}</span>}
              icon={syncIconClass}
              onClick={handleSync}
              model={syncButtonModel}
              disabled={isSyncDisabled}
              style={{ height: '2rem', minWidth: 'fit-content' }}
            />
          </div>
        )}
      </div>
    </>
  );

  useEffect(() => {
    if (!onTableDataChange) return;
    const len = sortedData?.length ?? 0;
    const logicalHash = len === 0 ? '0_empty' : `${len}_${sortedData[0]?.__editingKey__ ?? sortedData[0]?.id ?? 'n'}_${sortedData[len - 1]?.__editingKey__ ?? sortedData[len - 1]?.id ?? 'n'}`;
    if (prevTableDataLogicalHashRef.current === logicalHash) return;
    prevTableDataLogicalHashRef.current = logicalHash;
    // Pass full sortedData including __nestedTables__ so Column Type Overrides (and similar UIs) can show nested array structure
    onTableDataChange(sortedData);
  }, [sortedData, onTableDataChange]);


  // Drawer sidebar helpers
  const hasDrawerTabs = effectiveDrawerTabs && effectiveDrawerTabs.length > 0;
  const hasJsonTabs = effectiveDrawerTabs?.some(t => t?.isJsonTable) ?? false;
  const enableWriteForDrawer = forceEnableWrite !== undefined ? forceEnableWrite : (currentQueryDoc?.enableWrite || false);
  const shouldShowDrawer = hasDrawerTabs || (enableWriteForDrawer && drawerVisible && (hasDrawerFormFields || hasJsonTabs));
  const hasDrawerData = drawerData && drawerData.length > 0;
  const drawerActiveIndex = hasDrawerTabs
    ? Math.min(activeDrawerTabIndex, Math.max(0, effectiveDrawerTabs.length - 1))
    : 0;

  // Empty state component for drawer
  const DrawerEmptyState = ({ icon, title, subtitle }) => (
    <div className="flex flex-col items-center justify-center h-full text-center">
      <i className={`pi ${icon} text-4xl text-gray-400 mb-4`}></i>
      <p className="text-gray-600 font-medium">{title}</p>
      <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
    </div>
  );

  const renderDrawerFormField = useCallback((fieldConfig) => {
    const {
      fieldId,
      value,
      label,
      resolvedType,
      override,
      handleChange,
      readOnly = false,
      isObjectField = false,
      gridItemStyle,
      drawerGridColumnCount,
    } = fieldConfig;
    const overrideType = typeof override === 'object' && override?.type
      ? override.type
      : (typeof override === 'string' ? override : null);

    const wrapShell = (inner) =>
      gridItemStyle ? (
        <div key={fieldId} style={gridItemStyle} className="min-w-0">
          {inner}
        </div>
      ) : (
        <Fragment key={fieldId}>{inner}</Fragment>
      );

    if (readOnly) {
      const displayText = (() => {
        if (value == null || value === '') return '\u2014';
        if (resolvedType === 'boolean') return value ? 'Yes' : 'No';
        if (resolvedType === 'date') return formatDateValue(value);
        if (resolvedType === 'number') {
          return value != null && value !== '' ? String(toNumber(value)) : '\u2014';
        }
        return String(value);
      })();
      return wrapShell(
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-700">{label}</label>
          <div className="text-sm text-gray-600 min-h-[1.25rem] whitespace-pre-wrap break-words">{displayText}</div>
        </div>,
      );
    }

    if (overrideType === 'Calendar' || (!overrideType && resolvedType === 'date')) {
      return wrapShell(
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-700">{label}</label>
          <Calendar
            value={value ? (value instanceof Date ? value : new Date(value)) : null}
            onChange={(e) => handleChange(e.value)}
            dateFormat="M d, yy"
            showIcon
            className="w-full text-sm"
          />
        </div>,
      );
    }
    if (overrideType === 'Checkbox' || (!overrideType && resolvedType === 'boolean')) {
      return wrapShell(
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-700">{label}</label>
          <div className="flex items-center pt-1">
            <Checkbox
              inputId={`sidebar-edit-${fieldId}`}
              checked={!!value}
              onChange={(e) => handleChange(e.checked)}
            />
            <label htmlFor={`sidebar-edit-${fieldId}`} className="ml-2 text-sm text-gray-600">{value ? 'Yes' : 'No'}</label>
          </div>
        </div>,
      );
    }
    if (overrideType === 'InputNumber' || (!overrideType && resolvedType === 'number')) {
      return wrapShell(
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-700">{label}</label>
          <InputNumber
            value={value != null && value !== '' ? toNumber(value) : null}
            onValueChange={(e) => handleChange(e.value)}
            className="w-full text-sm"
          />
        </div>,
      );
    }
    if (overrideType === 'Select') {
      let getOptions = override?.getOptions;
      if (typeof getOptions !== 'function' && typeof override?.getOptionsCode === 'string' && override.getOptionsCode.trim()) {
        try {
          getOptions = new Function('ctx', 'return (' + override.getOptionsCode + ')(ctx);');
        } catch (err) {
          console.warn('[FormInputOverride] Invalid getOptionsCode for field', fieldId, err);
          getOptions = () => [];
        }
      }
      getOptions = typeof getOptions === 'function' ? getOptions : () => [];
      const ctx = {
        columnName: fieldId,
        query: queryFunction ?? (async () => { throw new Error('Query execution not available'); }),
      };
      const cacheBucket = isObjectField ? 'object' : 'main';
      const formCachedOptions = selectOptionsCache?.[`${cacheBucket}|${fieldId}`];
      return wrapShell(
        <FormSelectOptionsField
          col={fieldId}
          value={value}
          label={label}
          handleChange={handleChange}
          getOptions={getOptions}
          ctx={ctx}
          cachedOptions={formCachedOptions}
        />,
      );
    }
    if (overrideType === 'Upload') {
      const docnameCol = override?.docname;
      const formRow = formEditingRow ?? selectedRowData;
      const resolvedDocname = docnameCol && formRow ? String(formRow[docnameCol] ?? '') : '';
      return wrapShell(
        <FormUploadField
          fieldId={fieldId}
          docname={resolvedDocname}
          value={value}
          label={label}
          onFilePending={(fid, file) => {
            pendingUploadsRef.current.set(fid, {
              file,
              getAuth: () => getEndpointAndAuthWithTokenOverride(currentQueryDoc, graphqlToken),
              params: override?.params,
              docnameCol: override?.docname,
            });
          }}
        />,
      );
    }
    if (overrideType === 'Quill') {
      const quillInnerStyle = {};
      let quillInnerClass = 'flex flex-col gap-1';
      if (!gridItemStyle) {
        if (Number.isFinite(drawerGridColumnCount) && drawerGridColumnCount > 1) {
          quillInnerStyle.gridColumn = `1 / span ${drawerGridColumnCount}`;
        } else {
          quillInnerClass = `${quillInnerClass} col-span-2`;
        }
      }
      return wrapShell(
        <div
          className={quillInnerClass}
          style={Object.keys(quillInnerStyle).length ? quillInnerStyle : undefined}
        >
          <label className="text-xs font-medium text-gray-700">{label}</label>
          <Editor
            value={value != null ? String(value) : ''}
            onTextChange={(e) => handleChange(e.htmlValue)}
            headerTemplate={quillFormToolbar}
            style={{ height: '160px' }}
            className="w-full"
          />
        </div>,
      );
    }
    return wrapShell(
      <div className="flex flex-col gap-1">
        <label className="text-xs font-medium text-gray-700">{label}</label>
        <InputText
          value={value != null ? String(value) : ''}
          onChange={(e) => handleChange(e.target.value)}
          className="w-full text-sm"
        />
      </div>,
    );
  }, [queryFunction, selectOptionsCache, formatDateValue, formEditingRow, selectedRowData, currentQueryDoc, graphqlToken]);

  // Ensure contextValue is never null/undefined (safeguard)
  if (!contextValue) {
    console.error('DataProviderNew: contextValue is null/undefined');
  }

  return (
    <>
      <TableOperationsContext.Provider value={contextValue || {}}>
        {/* Header Controls - Responsive container */}
        {(hasHeaderContent || headerSlotTop || headerSlotLeft || headerSlotRight) && (
          <div className="px-2 sm:px-3 md:px-4 lg:px-6 xl:px-8 py-2 sm:py-3 md:py-4 border-b border-gray-200 shrink-0 bg-white min-w-0 overflow-x-auto">
            {headerSlotTop ? <div className="w-full min-w-0 mb-2 sm:mb-3">{headerSlotTop}</div> : null}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-3 md:gap-4 min-w-0 w-full">
              <div className={`flex-1 min-w-0 w-full${headerSlotLeft ? ' flex flex-wrap items-center gap-2 sm:gap-3' : ''}`}>
                {headerSlotLeft}
                {hasHeaderContent ? selectorsJSX : null}
              </div>
              {headerSlotRight ? (
                <div className="shrink-0 self-end sm:self-auto">{headerSlotRight}</div>
              ) : null}
            </div>
          </div>
        )}

        {/* Render children - wrap with PlasmicDataProvider so data (slot map) is available in Plasmic Studio. */}
        <PlasmicDataProvider name="data" data={contextValue || {}}>
          {children}
        </PlasmicDataProvider>
      </TableOperationsContext.Provider>

      {/* Filter and Sort Sidebar */}
      {currentQueryDoc?.clientSave === true && (
        <FilterSortSidebar
          visible={filterSortSidebarVisible}
          sortOnly={filterSortSidebarSortOnly}
          onHide={() => {
            setFilterSortSidebarVisible(false);
          }}
          searchFields={currentQueryDoc?.searchFields || {}}
          sortFields={currentQueryDoc?.sortFields || {}}
          tableData={preFilteredData}
          columnTypes={columnTypes}
          currentSortConfig={sortConfig}
          currentFilterValues={preFilterValues}
          onApply={async (sortConfig, filterValues) => {
            setIsApplyingFilterSort(true);

            // Update state for worker computation (batch these together)
            setSortConfig(sortConfig);
            setPreFilterValues(filterValues || {});

            // Trigger worker computation immediately (don't wait for useEffect)
            // This reduces the delay between state update and worker start
            if (filterSortWorkerRef.current && tableData && !isEmpty(tableData)) {
              const computationId = ++filterSortComputationIdRef.current;

              // Start worker computation immediately
              (async () => {
                try {
                  // Convert preFilterValues to tableFilters format
                  const filtersForWorker = {};
                  Object.keys(filterValues || {}).forEach(col => {
                    filtersForWorker[col] = { value: filterValues[col] };
                  });

                  const result = await filterSortWorkerRef.current.computeFilterSortGrouped(tableData, {
                    tableFilters: filtersForWorker,
                    columns,
                    columnTypes,
                    multiselectColumns,
                    hasPercentageColumns,
                    percentageColumns,
                    percentageColumnNames,
                    enableFilter,
                    searchTerm,
                    searchFields: currentQueryDoc?.searchFields || {},
                    sortConfig,
                    sortFieldType,
                    tableSortMeta,
                    enableSort,
                    effectiveGroupFields,
                    derivedColumnNames: getDerivedColumnNames(derivedColumns || [], derivedColumnsMode ?? 'main', derivedColumnsFieldName ?? null),
                    nonAggregatableColumns: getNonAggregatableColumnNames(derivedColumns || []),
                  });

                  // Apply derived columns to grouped data (including group summary rows)
                  const groupedDataWithDerived =
                    result.groupedData && derivedColumns?.length
                      ? applyDerivedColumns(result.groupedData, derivedColumns, {
                          mode: derivedColumnsMode ?? 'main',
                          fieldName: derivedColumnsFieldName ?? null,
                          getDataValue,
                          query: queryFunction,
                        })
                      : result.groupedData;

                  // Only update if this is still the latest computation
                  if (computationId === filterSortComputationIdRef.current) {
                    setWorkerComputedData({
                      ...result,
                      groupedData: groupedDataWithDerived,
                    });
                    setIsApplyingFilterSort(false);
                  }
                } catch (error) {
                  console.error('Filter/sort worker computation error:', error);
                  if (computationId === filterSortComputationIdRef.current) {
                    setIsApplyingFilterSort(false);
                  }
                }
              })();
            }

            // Sidebar is already closed by onHide() in FilterSortSidebar
          }}
          onClear={() => {
            setIsApplyingFilterSort(true);
            setSortConfig(null);
            setPreFilterValues({});
          }}
        />
      )}

      {/* Drawer Sidebar - Render when drawer tabs configured, or enableWrite with scalar/nested content */}
      {shouldShowDrawer && (() => {
        const drawerHeaderIcons = !parentColumnName && enableCellEdit && handleDrawerSave ? (
          <>
            {handleDrawerSave && (
              <button
                type="button"
                className="p-sidebar-icon p-link mr-2"
                onClick={handleDrawerSave}
                title="Save changes in this nested table"
              >
                <span className="pi pi-save" />
              </button>
            )}
          </>
        ) : null;
        return (
        <Sidebar
          position="bottom"
          blockScroll
          visible={drawerVisible}
          onHide={() => {
            if (getHasUnsavedDrawerChanges()) {
              confirmDialog({
                header: 'Unsaved changes',
                message: 'You have unsaved changes. Discard?',
                acceptLabel: 'Discard',
                rejectLabel: 'Keep editing',
                acceptClassName: 'p-button-danger',
                accept: closeDrawer,
              });
            } else {
              closeDrawer();
            }
          }}
          style={{ height: '100dvh' }}
          className="p-sidebar-sm"
          icons={drawerHeaderIcons}
          header={
            <h2 className="text-lg font-semibold text-gray-800 m-0">
              {drawerHeaderTitle}
            </h2>
          }
        >
          <div className="flex flex-col h-full dynamic-form-container">
            {/* Scalar section - part of dynamic form (root provider only) */}
            {!parentColumnName && drawerVisible && enableCellEdit && hasDrawerFormFields && (
              <section className="shrink-0 p-3 pb-2 border-b border-gray-200 drawer-form-inputs">
                {(formEditingRow ?? selectedRowData) && (
                  (() => {
                    const formRow = formEditingRow ?? selectedRowData;
                    const drawerRootLayout = getWriteFormLayout(effectiveMainWriteForm);
                    const fieldsTree = getWriteFormFields(effectiveMainWriteForm);
                    const drawerGrid =
                      drawerRootLayout.drawerGrid && typeof drawerRootLayout.drawerGrid === 'object'
                        ? drawerRootLayout.drawerGrid
                        : {};
                    const customGridClass =
                      typeof drawerRootLayout.drawerScalarGridClass === 'string' &&
                      drawerRootLayout.drawerScalarGridClass.trim()
                        ? drawerRootLayout.drawerScalarGridClass.trim()
                        : '';
                    const drawerGridColumnCountNum = Number(drawerGrid.columns);
                    const hasExplicitColumns =
                      Number.isFinite(drawerGridColumnCountNum) && drawerGridColumnCountNum > 0;
                    let gridContainerClass = 'grid grid-cols-2 gap-x-3 gap-y-2';
                    let gridContainerStyle;
                    if (customGridClass) {
                      gridContainerClass = customGridClass;
                    } else if (hasExplicitColumns) {
                      gridContainerClass = 'grid min-w-0';
                      gridContainerStyle = {
                        display: 'grid',
                        gridTemplateColumns: `repeat(${drawerGridColumnCountNum}, minmax(0, 1fr))`,
                      };
                      if (drawerGrid.gap != null && drawerGrid.gap !== '') {
                        gridContainerStyle.gap =
                          typeof drawerGrid.gap === 'number' ? `${drawerGrid.gap}px` : String(drawerGrid.gap);
                      } else {
                        gridContainerStyle.columnGap = '0.75rem';
                        gridContainerStyle.rowGap = '0.5rem';
                      }
                      if (drawerGrid.rows != null) {
                        if (typeof drawerGrid.rows === 'number' && drawerGrid.rows > 0) {
                          gridContainerStyle.gridTemplateRows = `repeat(${drawerGrid.rows}, auto)`;
                        } else if (typeof drawerGrid.rows === 'string' && drawerGrid.rows.trim()) {
                          gridContainerStyle.gridTemplateRows = drawerGrid.rows.trim();
                        }
                      }
                    }
                    const quillColumnCount = customGridClass
                      ? null
                      : hasExplicitColumns
                        ? drawerGridColumnCountNum
                        : 2;
                    const mainOverrides = getMainOverrides(mainColumnTypesOverride);
                    let order = 0;
                    const scalarFields = scalarEditableColumns.map((col) => {
                      const node = getWriteFormFieldNode(fieldsTree, col, null);
                      const fieldLayout = node?.layout;
                      return {
                        fieldId: col,
                        value: getDataValue(formRow, col),
                        label: formatHeaderName(col),
                        resolvedType: mainOverrides[col] || columnTypes[col] || 'string',
                        override: formInputOverride?.main?.[col],
                        handleChange: (newVal) => {
                          setFormEditingRow((prev) => (prev ? { ...prev, [col]: newVal } : null));
                        },
                        isObjectField: false,
                        gridItemStyle: gridItemStyleFromFieldLayout(fieldLayout),
                        fieldLayout,
                        drawerGridColumnCount: quillColumnCount,
                        _drawerOrder: order++,
                      };
                    });
                    const objectFields = objectEditableFields.map((fieldInfo) => {
                      const objectValue = parseJsonObject(getDataValue(formRow, fieldInfo.columnName)) || {};
                      const fieldId = fieldInfo.formKey;
                      const node = getWriteFormFieldNode(fieldsTree, fieldInfo.columnName, fieldInfo.key);
                      const fieldLayout = node?.layout;
                      return {
                        fieldId,
                        value: objectValue[fieldInfo.key],
                        label: fieldInfo.label,
                        resolvedType: fieldInfo.resolvedType,
                        override: formInputOverride?.object?.[fieldInfo.columnName]?.[fieldInfo.key],
                        handleChange: (newVal) => {
                          setFormEditingRow((prev) => {
                            if (!prev) return null;
                            const prevRawValue = prev[fieldInfo.columnName];
                            const prevObject = parseJsonObject(prevRawValue) || {};
                            const nextObject = {
                              ...prevObject,
                              [fieldInfo.key]: newVal,
                            };
                            return {
                              ...prev,
                              [fieldInfo.columnName]:
                                typeof prevRawValue === 'string' ? JSON.stringify(nextObject) : nextObject,
                            };
                          });
                        },
                        isObjectField: true,
                        gridItemStyle: gridItemStyleFromFieldLayout(fieldLayout),
                        fieldLayout,
                        drawerGridColumnCount: quillColumnCount,
                        _drawerOrder: order++,
                      };
                    });
                    const noop = () => {};
                    const scalarReadOnlyFields = scalarReadOnlyDisplayColumns.map((col) => {
                      const node = getWriteFormFieldNode(fieldsTree, col, null);
                      const fieldLayout = node?.layout;
                      return {
                        fieldId: col,
                        readOnly: true,
                        value: getDataValue(formRow, col),
                        label: formatHeaderName(col),
                        resolvedType: mainOverrides[col] || columnTypes[col] || 'string',
                        override: formInputOverride?.main?.[col],
                        handleChange: noop,
                        isObjectField: false,
                        gridItemStyle: gridItemStyleFromFieldLayout(fieldLayout),
                        fieldLayout,
                        drawerGridColumnCount: quillColumnCount,
                        _drawerOrder: order++,
                      };
                    });
                    const objectReadOnlyFields = objectReadOnlyDisplayFields.map((fieldInfo) => {
                      const objectValue = parseJsonObject(getDataValue(formRow, fieldInfo.columnName)) || {};
                      const fieldId = fieldInfo.formKey;
                      const node = getWriteFormFieldNode(fieldsTree, fieldInfo.columnName, fieldInfo.key);
                      const fieldLayout = node?.layout;
                      return {
                        fieldId,
                        readOnly: true,
                        value: objectValue[fieldInfo.key],
                        label: fieldInfo.label,
                        resolvedType: fieldInfo.resolvedType,
                        override: formInputOverride?.object?.[fieldInfo.columnName]?.[fieldInfo.key],
                        handleChange: noop,
                        isObjectField: true,
                        gridItemStyle: gridItemStyleFromFieldLayout(fieldLayout),
                        fieldLayout,
                        drawerGridColumnCount: quillColumnCount,
                        _drawerOrder: order++,
                      };
                    });
                    const mergedFields = [...scalarFields, ...objectFields, ...scalarReadOnlyFields, ...objectReadOnlyFields];
                    const sortedFields = sortDrawerFieldItemsByLayout(mergedFields);
                    return (
                      <div className={gridContainerClass} style={gridContainerStyle}>
                        {sortedFields.map((fc) => renderDrawerFormField(fc))}
                      </div>
                    );
                  })()
                )}
              </section>
            )}
            {/* Nested tables section (JSON tabs) or group-based tabs - subset of dynamic form */}
            <div className="flex-1 min-h-0">
              {hasDrawerTabs ? (
                <TabView
                  activeIndex={drawerActiveIndex}
                  onTabChange={(e) => setActiveDrawerTabIndex(e.index)}
                  className="h-full flex flex-col"
                >
                  {effectiveDrawerTabs.map((tab, index) => {
                    // Ensure tab has a unique id (use index as fallback for stability)
                    const tabId = tab.id || `tab-${index}`;

                    // Base props from main table (inherit from DataProviderNew props; slot override applies)
                    const baseTableProps = {
                      rowsPerPageOptions: [5, 10, 25, 50, 100, 200], // drawer-specific default
                      defaultRows: 10, // drawer-specific default
                      scrollable: false, // drawer-specific default
                      enableSort: effectiveMainConfig.enableSort,
                      enableFilter: effectiveMainConfig.enableFilter,
                      enableSummation: effectiveMainConfig.enableSummation,
                      enableDivideBy1Lakh, // shared - pass flat to nested
                      textFilterColumns: effectiveMainConfig.textFilterColumns || [],
                      allowedColumns: tab.allowedColumns ?? (getAllowedForScope(effectiveDrawerAllowedColumns, 'nested') ?? getAllowedForScope(effectiveDrawerAllowedColumns, 'main')) ?? [], // drawer: tab override, else nested scope, else main (from slot when opened from slot)
                      onAllowedColumnsChange: onAllowedColumnsChange, // from main table
                      visibleColumns: tableVisibleColumns, // from main table - ensures drawer respects column visibility
                      onVisibleColumnsChange: onVisibleColumnsChange, // from main table
                      redFields: effectiveMainConfig.redFields || [],
                      greenFields: effectiveMainConfig.greenFields || [],
                      rowColumnStyles: effectiveMainConfig.rowColumnStyles || [],
                      groupFields: (() => {
                        // If tab.groupFields is set use it, else derive from [outerGroup, innerGroup]
                        if (tab.groupFields && Array.isArray(tab.groupFields)) {
                          return tab.groupFields;
                        }
                        const derived = [];
                        if (tab.outerGroup) derived.push(tab.outerGroup);
                        if (tab.innerGroup) derived.push(tab.innerGroup);
                        return derived.length > 0 ? derived : null;
                      })(),
                      enableCellEdit: effectiveMainConfig.enableCellEdit,
                      writeForm: { layout: {}, fields: {} },
                      percentageColumns: effectiveMainConfig.percentageColumns || [],
                      derivedColumns: effectiveMainConfig.derivedColumns || [],
                      columnTypes: columnTypes, // from main table
                      columnTypesOverride: mainColumnTypesOverride || {},
                      tableName: "sidebar",
                      // Report settings - drawer reuses parent report view without local toggle
                      enableReport: false,
                      forceBreakdown: shouldShowDrawerReport,
                      reportDataOverride: shouldShowDrawerReport ? drawerReportDataWithDerived : null,
                      showProviderHeader: false,
                      dateColumn, // shared
                      breakdownType: breakdownType, // from main table
                      columnGroupBy: columnGroupBy, // from main table
                    };

                    // Extract tab-specific overrides (any prop beyond id, name, outerGroup, innerGroup, isJsonTable, data, fieldName, parentColumnName, nestedTableFieldName)
                    const { id, name, outerGroup, innerGroup, isJsonTable, data: tabData, fieldName, parentColumnName, nestedTableFieldName, ...tabOverrides } = tab;
                    // Merge order: default (baseTableProps) → tableOptions (drawerTableOptions) → tabOverrides
                    const mergedTableProps = { ...baseTableProps, ...(drawerTableOptions || {}), ...tabOverrides };

                    const drawerOpts = drawerTableOptions || {};
                    const enableCellEditExplicitInDrawer =
                      Object.prototype.hasOwnProperty.call(tabOverrides, 'enableCellEdit') ||
                      Object.prototype.hasOwnProperty.call(drawerOpts, 'enableCellEdit');
                    let nestedProviderTableProps = mergedTableProps;
                    if (isJsonTable) {
                      const wfMerged = normalizeWriteForm(mergedTableProps.writeForm);
                      const inheritParentWriteForm = !Object.keys(getWriteFormFields(wfMerged)).length;
                      const defaultJsonEnableCellEdit =
                        effectiveMainConfig.enableCellEdit ||
                        (enableWriteEffective &&
                          (resolvedWritePermissions.update || resolvedWritePermissions.create));
                      nestedProviderTableProps = {
                        ...mergedTableProps,
                        ...(inheritParentWriteForm ? { writeForm: effectiveMainWriteForm } : {}),
                        enableCellEdit: enableCellEditExplicitInDrawer
                          ? mergedTableProps.enableCellEdit
                          : defaultJsonEnableCellEdit,
                      };
                    }

                    // Determine data source: use editing buffer for JSON table tabs, otherwise use drawerData
                    // When nested instance calls onNestedBufferChange(), parent re-renders and re-reads ref here
                    let tabDataSource;
                    if (isJsonTable) {
                      const editingData = nestedTableEditingDataRef.current.get(tab.id);
                      tabDataSource = editingData && isArray(editingData) ? editingData : (tabData && isArray(tabData) ? tabData : []);
                    } else {
                      tabDataSource = drawerData;
                    }
                    const hasTabData = isJsonTable
                      ? (tabDataSource && isArray(tabDataSource))
                      : hasDrawerData;
                    return (
                      <TabPanel
                        key={tabId}
                        header={tab.name || `Tab ${index + 1}`}
                        className="h-full flex flex-col"
                      >
                        <div className="flex-1 overflow-auto">
                          {hasTabData ? (
                            <DataProviderNew
                              config={{
                                dataSource: null,
                                drawerTabs: [],
                                enableSort: nestedProviderTableProps.enableSort,
                                enableFilter: nestedProviderTableProps.enableFilter,
                                enableSummation: nestedProviderTableProps.enableSummation,
                                enableGrouping: nestedProviderTableProps.enableGrouping,
                                textFilterColumns: nestedProviderTableProps.textFilterColumns || [],
                                percentageColumns: nestedProviderTableProps.percentageColumns || [],
                                derivedColumns: nestedProviderTableProps.derivedColumns || [],
                                groupFields: nestedProviderTableProps.groupFields,
                                redFields: nestedProviderTableProps.redFields || [],
                                greenFields: nestedProviderTableProps.greenFields || [],
                                rowColumnStyles: nestedProviderTableProps.rowColumnStyles || [],
                                enableDivideBy1Lakh: nestedProviderTableProps.enableDivideBy1Lakh || false,
                                columnTypesOverride: nestedProviderTableProps.columnTypesOverride || {},
                                allowedColumns: nestedProviderTableProps.allowedColumns || [],
                                writeForm: nestedProviderTableProps.writeForm ?? { layout: {}, fields: {} },
                                enableCellEdit:
                                  nestedProviderTableProps.enableCellEdit !== undefined
                                    ? nestedProviderTableProps.enableCellEdit
                                    : false,
                                writePermissions: resolvedWritePermissions,
                                groupDrawerAccess: nestedProviderTableProps.groupDrawerAccess ?? effectiveMainConfig.groupDrawerAccess,
                                enableReport: nestedProviderTableProps.enableReport,
                                dateColumn: nestedProviderTableProps.dateColumn,
                                breakdownType: nestedProviderTableProps.breakdownType,
                                columnGroupBy: nestedProviderTableProps.columnGroupBy,
                                chartColumns: nestedProviderTableProps.chartColumns || [],
                                chartHeight: nestedProviderTableProps.chartHeight,
                                rowsPerPageOptions: nestedProviderTableProps.rowsPerPageOptions,
                                defaultRows: nestedProviderTableProps.defaultRows,
                                scrollable: nestedProviderTableProps.scrollable,
                                enableFullscreenDialog: nestedProviderTableProps.enableFullscreenDialog,
                              }}
                              offlineData={tabDataSource}
                              overrides={overrides}
                              __internal={{
                                ...(isJsonTable && {
                                  derivedColumnsMode: 'nested',
                                  derivedColumnsFieldName: nestedTableFieldName ?? undefined,
                                }),
                                parentColumnName: isJsonTable ? parentColumnName : undefined,
                                nestedTableFieldName: isJsonTable ? nestedTableFieldName : undefined,
                                onAllowedColumnsChange: nestedProviderTableProps.onAllowedColumnsChange,
                                visibleColumns: isJsonTable ? undefined : nestedProviderTableProps.visibleColumns,
                                onVisibleColumnsChange: isJsonTable ? undefined : nestedProviderTableProps.onVisibleColumnsChange,
                                forceBreakdown: nestedProviderTableProps.forceBreakdown,
                                reportDataOverride: nestedProviderTableProps.reportDataOverride,
                                showProviderHeader: nestedProviderTableProps.showProviderHeader,
                                forceEnableWrite: isJsonTable && currentQueryDoc?.enableWrite ? true : undefined,
                                parentOriginalNestedTableDataRef: isJsonTable ? originalNestedTableDataRef : undefined,
                                parentNestedTableEditingDataRef: isJsonTable ? nestedTableEditingDataRef : undefined,
                                parentHandleDrawerSaveProp: isJsonTable ? handleDrawerSave : undefined,
                                nestedTableTabId: isJsonTable ? tabId : undefined,
                                onNestedBufferChange: isJsonTable ? handleNestedBufferChange : undefined,
                                parentHandleAddNestedRowAtZero: isJsonTable ? (() => handleAddNestedRowAtZero(tabId)) : undefined,
                                fallbackColumns: isJsonTable && tab.columns && isArray(tab.columns) && tab.columns.length > 0 ? tab.columns : undefined,
                                onTableDataChange: isJsonTable ? (data) => { updateCurrentNestedTableData(tabId, data); } : undefined,
                              }}
                            >
                              <DataTableComponent
                                tableName={nestedProviderTableProps.tableName || 'table'}
                              />
                            </DataProviderNew>
                          ) : (
                            <DrawerEmptyState
                              icon="pi-inbox"
                              title="No data available"
                              subtitle={tab.isJsonTable ? "No nested table data" : "No matching rows found"}
                            />
                          )}
                        </div>
                      </TabPanel>
                    );
                  })}
                </TabView>
              ) : !hasDrawerFormFields ? (
                <DrawerEmptyState
                  icon="pi-inbox"
                  title="No tabs configured"
                  subtitle="Please configure drawer tabs in settings"
                />
              ) : null}
            </div>
          </div>
        </Sidebar>
        );
      })()}
      {!parentColumnName && !skipConfirmDialog && <ConfirmDialog />}
      {!parentColumnName && (
        <Dialog
          header="Save – Create & Update Payloads"
          visible={saveDiffDialogVisible}
          style={{ width: '90vw', maxWidth: '720px' }}
          onHide={() => {
            setSaveDiffDialogVisible(false);
            setSavePayloadDisplayQueries({ bulkCreate: null, bulkUpdate: null });
            savePayloadElbritRef.current = null;
            // Prevent init effect from overwriting original with editing when user cancels save dialog
            skipNextInitFromSortedDataRef.current = true;
          }}
          footer={
            <Button
              label={saveDiffDialogSaving ? 'Saving...' : 'Save'}
              icon={saveDiffDialogSaving ? 'pi pi-spin pi-spinner' : undefined}
              onClick={handleSaveDiffDialogOk}
              disabled={saveDiffDialogSaving}
            />
          }
        >
          <div style={{ maxHeight: '60vh', overflow: 'auto' }} className="space-y-4">
            {savePayloadContent.doctype && (
              <p style={{ margin: 0, fontSize: '0.875rem', color: '#6b7280' }}>
                Doctype: <strong>{savePayloadContent.doctype}</strong>
              </p>
            )}
            {savePayloadContent.createPayload ? (
              <div>
                <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '0.875rem', fontWeight: 600 }}>Create (bulkCreate)</h4>
                <p style={{ margin: '0 0 0.25rem 0', fontSize: '0.75rem', color: '#6b7280' }}>Query</p>
                <pre style={{ margin: '0 0 0.5rem 0', padding: '0.75rem', background: '#f3f4f6', borderRadius: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '0.8125rem' }}>
                  {savePayloadDisplayQueries.bulkCreate?.trim() || 'Loading query...'}
                </pre>
                <p style={{ margin: '0 0 0.25rem 0', fontSize: '0.75rem', color: '#6b7280' }}>Variables</p>
                <pre style={{ margin: 0, padding: '0.75rem', background: '#f9fafb', borderRadius: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '0.875rem' }}>
                  {JSON.stringify(savePayloadContent.createPayload, null, 2)}
                </pre>
              </div>
            ) : (
              <p style={{ margin: 0, fontSize: '0.875rem', color: '#9ca3af' }}>No new rows</p>
            )}
            {savePayloadContent.updatePayload ? (
              <div>
                <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '0.875rem', fontWeight: 600 }}>Update (bulkUpdate)</h4>
                <p style={{ margin: '0 0 0.25rem 0', fontSize: '0.75rem', color: '#6b7280' }}>Query</p>
                <pre style={{ margin: '0 0 0.5rem 0', padding: '0.75rem', background: '#f3f4f6', borderRadius: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '0.8125rem' }}>
                  {savePayloadDisplayQueries.bulkUpdate?.trim() || 'Loading query...'}
                </pre>
                <p style={{ margin: '0 0 0.25rem 0', fontSize: '0.75rem', color: '#6b7280' }}>Variables</p>
                <pre style={{ margin: 0, padding: '0.75rem', background: '#f9fafb', borderRadius: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '0.875rem' }}>
                  {JSON.stringify(
                    savePayloadContent.bulkUpdateVariablesPreview ?? savePayloadContent.updatePayload,
                    null,
                    2,
                  )}
                </pre>
              </div>
            ) : (
              <p style={{ margin: 0, fontSize: '0.875rem', color: '#9ca3af' }}>No updated rows</p>
            )}
            {savePayloadContent.removedRows?.length > 0 ? (
              <div>
                <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '0.875rem', fontWeight: 600 }}>Removed rows</h4>
                <pre style={{ margin: 0, padding: '0.75rem', background: '#fef2f2', borderRadius: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '0.875rem' }}>
                  {JSON.stringify(savePayloadContent.removedRows, null, 2)}
                </pre>
              </div>
            ) : null}
            {pendingUploadsRef.current.size > 0 && (
              <div>
                <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '0.875rem', fontWeight: 600 }}>File Uploads (upload_to_field)</h4>
                <div className="space-y-2">
                  {Array.from(pendingUploadsRef.current.entries()).map(([fieldId, { file, params, docnameCol }]) => {
                    const formRow = formEditingRowRef.current ?? selectedRowData;
                    const docname = docnameCol && formRow ? String(formRow[docnameCol] ?? '') : '';
                    const doctype = currentQueryDoc?.writeDocTypeName ?? currentQueryDoc?.writeDocType ?? '';
                    const fd = { doctype, docname, fieldname: fieldId, file: file.name, ...(params || {}) };
                    return (
                      <pre key={fieldId} style={{ margin: 0, padding: '0.75rem', background: '#f0fdf4', borderRadius: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '0.875rem' }}>
                        {JSON.stringify(fd, null, 2)}
                      </pre>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </Dialog>
      )}
      {!parentColumnName && (
        <Dialog
          header={enableBreakdown ? 'Export report by group level' : 'Export grouped data'}
          visible={exportGroupSelectorVisible}
          style={{ width: '90vw', maxWidth: '480px' }}
          onHide={() => {
            setExportGroupSelectorVisible(false);
            exportGroupOverridesRef.current = null;
          }}
          footer={
            <>
              <Button
                label="Cancel"
                severity="secondary"
                onClick={() => {
                  setExportGroupSelectorVisible(false);
                  exportGroupOverridesRef.current = null;
                }}
              />
              <Button
                label="Export"
                icon="pi pi-download"
                onClick={() => {
                  if (exportGroupSelectorSelectedLevels?.length > 0) {
                    runExportToXLSX(exportGroupSelectorSelectedLevels, exportGroupOverridesRef.current);
                  }
                }}
                disabled={!exportGroupSelectorSelectedLevels?.length}
              />
            </>
          }
        >
          <p className="mb-3 text-gray-600">
            {enableBreakdown
              ? 'Select which group levels to export. Each selected level becomes a separate sheet with the same breakdown columns, rolled up to that nesting depth.'
              : 'Select which group levels to export. Each selected level becomes a separate sheet in the Excel file.'}
          </p>
          <MultiselectFilter
            value={exportGroupSelectorSelectedLevels}
            onChange={(vals) => setExportGroupSelectorSelectedLevels(vals ?? [])}
            options={exportDialogGroupFields.map((f, i) => ({ value: i, label: formatHeaderName(f) }))}
            placeholder="Select levels"
            fieldName="levels"
            itemLabel="level"
          />
        </Dialog>
      )}
    </>
  );
}

