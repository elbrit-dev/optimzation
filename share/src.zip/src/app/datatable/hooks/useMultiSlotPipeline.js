'use client';

import { isArray, isEmpty } from 'lodash';
import { useMemo } from 'react';
import { getDataValue } from '../utils/dataAccessUtils';
import { applyDerivedColumns } from '../utils/derivedColumnsUtils';
import { computeSearchSortSortedData, computeSlotPipeline } from '../utils/perSlotPipelineUtils';
import { useDataPipeline } from './useDataPipeline';

/**
 * Multi-slot data pipeline. When slotIds.length === 1, delegates to useDataPipeline.
 * When slotIds.length > 1, computes per-slot pipeline using computeSlotPipeline.
 *
 * @param {Object} options - Same as useDataPipeline, plus:
 * @param {Object} options.slots - { [slotId]: slotConfig }
 * @param {string[]} options.slotIds - Array of slot IDs
 * @param {Object} options.slotStateBySlot - { [slotId]: { tableFilters, tableSortMeta, tablePagination } }
 */
export function useMultiSlotPipeline(options) {
  const {
    slots = {},
    slotIds = [],
    slotStateBySlot = {},
    ...pipelineOptions
  } = options;

  const singlePipeline = useDataPipeline({
    ...pipelineOptions,
    tableFilters: slotStateBySlot[slotIds[0]]?.tableFilters ?? pipelineOptions.tableFilters ?? {},
    tableSortMeta: slotStateBySlot[slotIds[0]]?.tableSortMeta ?? pipelineOptions.tableSortMeta ?? [],
    tablePagination: slotStateBySlot[slotIds[0]]?.tablePagination ?? pipelineOptions.tablePagination ?? { first: 0, rows: 10 },
    groupFields: slots[slotIds[0]]?.groupFields ?? pipelineOptions.groupFields,
    derivedColumns: slots[slotIds[0]]?.derivedColumns ?? pipelineOptions.derivedColumns ?? [],
    derivedRows: slots[slotIds[0]]?.derivedRows ?? pipelineOptions.derivedRows ?? null,
    percentageColumns: slots[slotIds[0]]?.percentageColumns ?? pipelineOptions.percentageColumns ?? [],
    textFilterColumns: slots[slotIds[0]]?.textFilterColumns ?? pipelineOptions.textFilterColumns ?? [],
    enableFilter: slots[slotIds[0]]?.enableFilter ?? pipelineOptions.enableFilter ?? true,
    enableSort: slots[slotIds[0]]?.enableSort ?? pipelineOptions.enableSort ?? true,
  });

  const pipelinesBySlot = useMemo(() => {
    if (!isArray(slotIds) || slotIds.length <= 1) {
      const sid = slotIds[0] ?? 'main';
      return {
        [sid]: {
          filteredData: singlePipeline.filteredData,
          groupedData: singlePipeline.groupedData,
          sortedData: singlePipeline.sortedData,
          paginatedData: singlePipeline.paginatedData,
          pipelineColumnMeta: singlePipeline.pipelineColumnMeta,
          effectiveGroupFields: singlePipeline.effectiveGroupFields,
          filteredDataWithNestedTables: singlePipeline.filteredDataWithNestedTables,
        },
      };
    }

    const {
      currentQueryDoc,
      searchTerm,
      sortConfig,
      columnTypesOverride,
      allowedColumns,
      derivedColumnsMode,
      derivedColumnsFieldName,
      fallbackColumns,
      queryFunction,
      monthRange,
    } = pipelineOptions;
    const { preFilteredData, addEditingKeysToRows, mainTableEditingDataRefEarly } = singlePipeline;

    const baseTableData =
      preFilteredData && isArray(preFilteredData) && !isEmpty(preFilteredData)
        ? addEditingKeysToRows(preFilteredData)
        : preFilteredData ?? [];

    const sharedSearchSortOptions = {
      currentQueryDoc,
      searchTerm: searchTerm ?? '',
      sortConfig,
      columnTypesOverride: columnTypesOverride ?? {},
    };

    const sharedPipelineOptionsBase = {
      columnTypesOverride: columnTypesOverride ?? {},
      allowedColumns: allowedColumns ?? [],
      currentQueryDoc,
      sortConfig,
      fallbackColumns,
      derivedColumnsMode: derivedColumnsMode ?? 'main',
      derivedColumnsFieldName: derivedColumnsFieldName ?? null,
      queryFunction,
      monthRange,
    };

    const result = {};
    for (const slotId of slotIds) {
      const slotConfig = slots[slotId] ?? {};
      const slotState = slotStateBySlot[slotId] ?? {};
      const slotColumnTypesOverride =
        slotConfig.columnTypesOverride && typeof slotConfig.columnTypesOverride === 'object'
          ? slotConfig.columnTypesOverride
          : columnTypesOverride ?? {};
      const slotAllowedColumns = slotConfig.allowedColumns ?? sharedPipelineOptionsBase.allowedColumns;
      const slotSharedOptions = {
        ...sharedPipelineOptionsBase,
        columnTypesOverride: slotColumnTypesOverride,
        allowedColumns: slotAllowedColumns,
      };
      const slotSearchSortOptions = {
        ...sharedSearchSortOptions,
        columnTypesOverride: slotColumnTypesOverride,
      };
      const tableData = baseTableData && !isEmpty(baseTableData)
        ? applyDerivedColumns(baseTableData, slotConfig.derivedColumns ?? [], {
            mode: derivedColumnsMode ?? 'main',
            fieldName: derivedColumnsFieldName ?? null,
            getDataValue,
            query: queryFunction,
            monthRange,
          })
        : baseTableData;
      const searchSortSortedData = computeSearchSortSortedData(tableData, slotSearchSortOptions);
      const slotResult = computeSlotPipeline(searchSortSortedData, slotConfig, slotState, slotSharedOptions);
      result[slotId] = slotResult;
    }
    return result;
  }, [
    slotIds,
    slots,
    slotStateBySlot,
    singlePipeline.filteredData,
    singlePipeline.groupedData,
    singlePipeline.sortedData,
    singlePipeline.paginatedData,
    singlePipeline.pipelineColumnMeta,
    singlePipeline.effectiveGroupFields,
    singlePipeline.filteredDataWithNestedTables,
    singlePipeline.addEditingKeysToRows,
    singlePipeline.mainTableEditingDataRefEarly,
    singlePipeline.preFilteredData,
    pipelineOptions.currentQueryDoc,
    pipelineOptions.searchTerm,
    pipelineOptions.sortConfig,
    pipelineOptions.columnTypesOverride,
    pipelineOptions.allowedColumns,
    pipelineOptions.fallbackColumns,
    pipelineOptions.derivedColumnsMode,
    pipelineOptions.derivedColumnsFieldName,
    pipelineOptions.queryFunction,
    pipelineOptions.monthRange,
  ]);

  return {
    ...singlePipeline,
    pipelinesBySlot,
  };
}
